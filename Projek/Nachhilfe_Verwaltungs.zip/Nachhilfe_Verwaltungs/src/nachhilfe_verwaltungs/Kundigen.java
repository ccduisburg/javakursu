
package nachhilfe_verwaltungs;


public interface Kundigen {
    public boolean getGekundigt();     
    public void setGekundigt(boolean p);
  
    
}
