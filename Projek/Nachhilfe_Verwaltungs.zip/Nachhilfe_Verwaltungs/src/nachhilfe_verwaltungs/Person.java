package nachhilfe_verwaltungs;

import java.util.Date;

public class Person {

    protected String name;
    protected String vorname;
    protected String adress;
    protected String email;
    protected String geburstort;
    protected Date geburstdate;
    protected String geschlescht;

   
    //Methoden
    public void setName(String personName) {//public void setName(String name)
        personName = "Herr " + personName;
        name = personName;
    }

    public void setVorname(String personVorname) {//public void setName(String name)

        vorname = personVorname;
    }

    public String getName() {
        return name;
    }

    public String getVorname() {
        return vorname;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGeburstort() {
        return geburstort;
    }

    public void setGeburstort(String geburstort) {
        this.geburstort = geburstort;
    }

    public Date getGeburstdate() {
        return geburstdate;
    }

    public void setGeburstdate(Date geburstdate) {
        this.geburstdate = geburstdate;
    }

    public String getGeschlescht() {
        return geschlescht;
    }

    public void setGeschlescht(String geschlescht) {
        this.geschlescht = geschlescht;
    }

}
