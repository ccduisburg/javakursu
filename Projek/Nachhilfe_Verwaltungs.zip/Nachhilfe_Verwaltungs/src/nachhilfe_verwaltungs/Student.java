
package nachhilfe_verwaltungs;
import java.time.LocalDate;
//import nachhilfe_verwaltungs.Kundigen;

public class Student extends Person implements Kundigen{
 
    private LocalDate anmeldeDatum;
    private String schulKlasse;
    private String schulName;
    private boolean gekundigt;
    protected Kurs[] kurse;
    
    public Student(String name,LocalDate anmeldeDatum,String schulName,String schulKlasse){
    
    this.name=name;
    this.anmeldeDatum=anmeldeDatum;
    this.schulName=schulName;
    this.schulKlasse=schulKlasse;
    }
    
public void schuleAnmeldung(String name,LocalDate anmeldeDatum){
this.name=name;
this.anmeldeDatum=anmeldeDatum;
gekundigt=false;
}
        
    public String getSchulKlasse() {
        return schulKlasse;
    }
    
    public void setSchulKlasse(String SchulKlasse) {
        this.schulKlasse = SchulKlasse;
    }
   
    public String getSchulName() {
        return schulName;
    }
    
    public void setSchulName(String SchulName) {
        this.schulName = SchulName;
    }
   @Override
    public boolean getGekundigt() {
        return gekundigt;
    }
    @Override
    public void setGekundigt(boolean gekundigt) {
        this.gekundigt = gekundigt;
    }      
    
}
