

package nachhilfe_verwaltungs;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;


public class Nachhilfe_Verwaltungs {

   
    public static void main(String[] args) {
        
     
  LocalDate today= LocalDate.now();

      
        
        Person p1=new Person();
        
        Student s1=new Student("Cemil",today,"Gesamtschule","6.klasse");
        
        
        
        
        
    }
    
}
