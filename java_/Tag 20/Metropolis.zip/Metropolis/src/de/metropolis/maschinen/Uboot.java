/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.metropolis.maschinen;

import metropolis.Taucher;

/**
 *
 * @author Sanne
 */
public class Uboot implements Taucher{
    private int tiefe;
    @Override
    public void tauchen() {
        System.out.println("Blub Blub");
        tiefe+=10; // tiefe=tiefe+10;
       }

    @Override
    public void ablegen() {}

    @Override
    public void schwimmen() {}

    @Override
    public void anlegen() {}
    
    @Override
    public int wieTiefBinIch(){
        return tiefe;
    }
    
}
