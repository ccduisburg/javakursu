/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.metropolis.maschinen;

import metropolis.Schwimmer;

/**
 *
 * @author Sanne
 */
public class Schiff implements Schwimmer{

    @Override
    public void ablegen() {
        System.out.println("Ich steche in See");
    }

    @Override
    public void schwimmen() {
        System.out.println("Hier ist Wasser, überall Wasser");
    }

    @Override
    public void anlegen() {
        System.out.println("Reicht jetzt, alle Mann von Bord");
    }
    
}
