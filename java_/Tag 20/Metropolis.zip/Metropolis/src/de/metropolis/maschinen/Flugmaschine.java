/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.metropolis.maschinen;

/**
 *
 * @author Sanne
 */
public class Flugmaschine {
    public void starten(){
        System.out.println("Starten");
    }
    public void fliegen(){
        System.out.println("Fliegen");
    }
    public void landen(){
        System.out.println("Landen");
    }
}
