package de.metropolis.maschinen;

import metropolis.Flieger;

public class Flugzeug extends Flugmaschine implements Flieger{

    private double gewicht;

    @Override
    public void starten() {
        System.out.println("Ich heb ab");
    }

    @Override
    public void fliegen() {
        System.out.println("Ich mach Dreck");
    }

    @Override
    public void landen() {
        System.out.println("Ich brauch Platz, ne ganze Landebahn lang...");
    }
}
