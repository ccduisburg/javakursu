
package de.metropolis.lebewesen;

import metropolis.Flieger;

public class Vogel implements Flieger{
    public void starten(){
        System.out.println("Zwitscher");
    }
    public void fliegen(){
        System.out.println("Zwitscher");
    }
    public void landen(){
        System.out.println("Zwitscher");
    }
}
