
package de.metropolis.lebewesen;

import metropolis.Flieger;
import metropolis.Schwimmer;


public class Ente implements Schwimmer,Flieger{

    @Override
    public void ablegen() {
    }

    @Override
    public void schwimmen() {}

    @Override
    public void anlegen() {}

    @Override
    public void starten() {}

    @Override
    public void fliegen() {}

    @Override
    public void landen() { 
    }
    
}
