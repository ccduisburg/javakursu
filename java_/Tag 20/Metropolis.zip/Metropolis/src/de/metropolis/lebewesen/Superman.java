
package de.metropolis.lebewesen;

import metropolis.Flieger;

/**
 * singleton design pattern
 * @author Sanne
 */
public class Superman implements Flieger{
    private String identitaet =  "Clark Kent";
    private int weltRettungen=0;
    private static Superman superman;
    
    private Superman(){
    }
    /**
     * Soll die getInstance Mehtode aus Design Pattern umsetzen
     * @return gibt Das <h2>Superman</h2> - &gt; Objekt &lt; zurück, erstellt es, wenn es noch nicht da ist
     */
    public static Superman rufeSuperman(){
        if(superman==null){
            superman = new Superman();
        }
        return superman;
    }
    
    @Override
    public void starten()throws KryptonidException{
        boolean b =false;
        if(b){
            throw new KryptonidException();
        }
        System.out.println("Ich mach mich auf, die Welt zu retten");
    }
    @Override
    public void fliegen(){
        System.out.println("Unterwegs die Welt zu retten");
    }
    @Override
    public void landen(){
        System.out.println("Ich bin da, um die Welt zu retten");
        weltRettungen++;
    }
}
