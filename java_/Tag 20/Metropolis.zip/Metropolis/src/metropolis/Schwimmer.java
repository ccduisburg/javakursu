
package metropolis;

public interface Schwimmer {
    public void ablegen();
    public void schwimmen();
    public void anlegen();
}
