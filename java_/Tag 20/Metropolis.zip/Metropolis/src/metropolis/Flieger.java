
package metropolis;

public interface Flieger {
    void starten()throws Exception;//Alle Methoden des Interfaces sind public!
    void fliegen();
    void landen();
}
