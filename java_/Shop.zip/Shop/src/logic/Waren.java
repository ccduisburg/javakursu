package logic;

/**
 *
 * @author CC-Student
 */
public class Waren {
    protected int anzahlLager;
    public void verkaufen(){
        anzahlLager--;
    }    
    public void einkaufen(){
        anzahlLager++;
    }
 protected double preis;
 public void kostet(){
     
 }
}

  