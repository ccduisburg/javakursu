
package model;



public class Mainboards {
    
    private String hersteller;

    private String chipSatz;

    private String groesse;
    
    private String sockel;

    public Mainboards(String hersteller, String chipSatz, String groesse, String sockel) {
        this.hersteller = hersteller;
        this.chipSatz = chipSatz;
        this.groesse = groesse;
        this.sockel = sockel;
    }
    
    
    
}
