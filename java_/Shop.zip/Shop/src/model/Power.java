
package model;

import java.util.HashMap;
import java.util.Map;


public class Power {
    
    private String hersteller;
    
    private String typ;
    
    private int leistung;

    public Power(String hersteller, String typ, int leistung) {
        this.hersteller = hersteller;
        this.typ = typ;
        this.leistung = leistung;
    }
    
    
    
}
