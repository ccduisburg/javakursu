package model;



public class HDD {
    
    private String hersteller;
    private String typ;
    private String groesse;

    public HDD(String hersteller, String typ, String groesse) {
        this.hersteller = hersteller;
        this.typ = typ;
        this.groesse = groesse;
    }
    
    
    
}
