
package model;

import java.util.HashMap;
import java.util.Map;


public class RAM {
    
    private String hersteller;
    
    private String typ;
    
    private String sockel;
    
    private int takt;

    public RAM(String hersteller, String typ, String sockel, int takt) {
        this.hersteller = hersteller;
        this.typ = typ;
        this.sockel = sockel;
        this.takt = takt;
    }
    
   
    
}
