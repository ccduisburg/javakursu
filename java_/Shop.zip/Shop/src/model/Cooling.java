package model;

public class Cooling {

    private String hersteller;
    private String typ;
    private int groesse;
    private int anzahlAufLager;

    public Cooling(String hersteller, String typ, int groesse, int anzahlAufLager) {
        this.hersteller = hersteller;
        this.typ = typ;
        this.groesse = groesse;
        this.anzahlAufLager = anzahlAufLager;

    }

}
