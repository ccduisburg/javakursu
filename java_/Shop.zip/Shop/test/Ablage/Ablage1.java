/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ablage;

/**
 *
 * @author CC-Student
 */
public class Ablage1 {
    
}
        System.out.println("CPU");
        System.out.println("Cooling");
        System.out.println("HDD");
        System.out.println("Mainboard");
        System.out.println("Power");
        System.out.println("RAM");

String [][] Warengruppen = new String {{"CPU","HDD","Mainboard","RAM"};{"Intel","AMD","DDR4","HDD","SSD"};{"Ryzen","i7","128GB","256GB","8GB","16GB","32GB","300W","400W"}};    