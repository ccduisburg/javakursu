# Aufgabe 'lines'

Gegeben ist folgender Code:

	long countCommentLines = 0;
	
	// A
	try( BufferedReader in = new BufferedReader(new FileReader("build.xml")) ) {
	    String line;
	    while( (line = in.readLine()) != null ) {
	        line = line.trim();
	        if(line.startsWith("<!--")) {
	            countCommentLines++;
	        }
	    }
	}
	// B
	
	System.out.println("comment lines: " + countCommentLines);
	
Ersetzen Sie bitte die Zeilen zwischen A und B mit einer Pipeline, die auch

	- alle Zeilen der Textdatei 'build.xml' durchgeht und dabei
	- die Leerzeichen am Anfang und Ende der geladenen Strings entfernt und danach
	- die Anzahl der (getrimmten) Strings ermittelt, die mit "<!--" starten. 

> Tipp: Benutzen Sie die Methode `java.nio.file.Files.lines` 