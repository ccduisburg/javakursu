# Aufgabe 'list'

Gegeben ist der Code:

	Path root = Paths.get(".");
	DirectoryStream<Path> dirStr = Files.newDirectoryStream(root);
	
	for( Path entry : dirStr ) {
	    if( Files.isDirectory(entry) ) {
	        if( entry.getFileName().toString().length() == 4 ) {
	            System.out.println(entry);
	        }
	    }
	}

Ersetzen Sie den Code bitte mit einer Stream-Pipeline, die dieselbe Aufgabe löst.