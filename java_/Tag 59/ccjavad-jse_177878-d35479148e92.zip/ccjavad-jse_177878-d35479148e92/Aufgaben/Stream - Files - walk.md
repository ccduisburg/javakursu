# Aufgabe 'walk'

Gegeben ist folgende Klasse:

	public class Test {
	
	    public static void main(String[] args) throws IOException {
	        String rootName =  "C:\\Program Files";
	        Path root = Paths.get(rootName);
	        walk(root, System.out::println); // Zeile A
	    }
	    
	    public static void walk(Path root, Consumer<Path> dirConsumer) 
	    	throws IOException {
	        dirConsumer.accept(root);
	        
	        DirectoryStream<Path> dirStr = Files.newDirectoryStream(root);
	        
	        for( Path entry : dirStr ) {
	            if( Files.isDirectory(entry) ) {
	                myWalk(entry, dirConsumer);
	            }
	        }
	    }
	}

Die statische Methode `walk` gibt alle Verzeichnisse aus, die sich im Verzeichnis 'root' finden lassen.
Bitte erstellen Sie eine alternative Lösung, in der Sie eine Stream-Pipeline verwenden, und ersetzen Sie damit den Aufruf in der Zeile A. Ihre Lösung kann/darf aus meheren Zeilen bestehen.

> Tipp. Suchen Sie nach Hilfsmethode(n) in der Klasse `java.nio.file.Files`
