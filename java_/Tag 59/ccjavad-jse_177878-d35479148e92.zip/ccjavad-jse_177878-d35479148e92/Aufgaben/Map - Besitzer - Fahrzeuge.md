# Aufgabe 'Map - Besizter/Fahrzeuge'

1. Die Klasse `Fahrzeug` hat die Attribute `modell` und `hersteller`.
1. Die Klasse `Person` hat die Attribute `vorname` und `nachname`.
1. Erzeugen Sie 3 Instanzen der Klasse `Person`.
1. Erzeugen Sie 4 Instanzen der Klasse `Fahrzeug`.
1. Ordnen Sie in einer Map jedes Fahrzeug (Fahrzeug-Key) einem Besitzer (Person-Value) zu. Ein Besitzer Ihrer Wahl wird dabei zwei Fahrzeuge erhalten (Zwei Fahrzeuge werden demselben Besitzer zugeordnet).
1. Suchen Sie in der Map nach dem Besitzer mit einem Fahrzeug-Key.
1. Ordnen Sie in einer weiteren Map einem Besitzer alle seine Fahrzeuge zu. Überlegen Sie wie mehrere Fahrzeuge einem Person-Schlüßel zugeordnet werden können.
1. Suchen Sie in der neuen Map nach den Fahrzeugen mit einem Person-Key.
1. Optional. Definieren Sie eine Methode, mit der sich alle Elemente einer beliebigen Map untereinander auf der Console ausgeben lassen. Testen Sie die Methode mit den beiden Maps aus der Aufgabe
