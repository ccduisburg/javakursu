#Aufgabe 'Enums - Hunderassen'

- Btte definieren Sie eine Enum-Klasse 'Hunderasse' mit drei Konstanten
   
        DACKEL, COLLIE und DOGGE. 
 
- Jede Hunderasse soll eine readonly-Property 'maxGroesse' bekommen:
   
        0.5 für DACKEL, 1.0 für COLLIE und 1.5 für DOGGE.   

- Geben Sie alle statischen Konstanten der Klasse 'Hunderasse' aus. Die Ausgaben sollen folgendermaßen aussehen:

        Dackel, max. Größe: 0.5
        Collie, max. Größe: 1.0
        Dogge, max. Größe: 1.5
