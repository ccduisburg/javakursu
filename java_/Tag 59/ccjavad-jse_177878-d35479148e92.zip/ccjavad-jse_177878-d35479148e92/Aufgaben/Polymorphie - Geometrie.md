# Aufgabe 'Polymorphie - Geometrie'

- Führen Sie den Begriff "Rechteck" in einem Projekt ein. Ein Rechteck hat Breite und Höhe.


- Es soll auch Kreise geben können. Jeder Kreis soll ein Radius haben. 

 
- Sowohl ein Rechteck als auch ein Kreis hat die x und y Koordinaten.


- Sowohl ein Rechteck als auch ein Kreis hat eine Methode "bewegen", mit der sich die Koordinaten ändern lassen.


- Mit einer Instanz-Methode "getFlaeche" soll die Fläche eines Rechteckes ermittelt werden können.

 
- Mit einer Instanz-Methode "getFlaeche" soll die Fläche eines Kreises ermittelt werden können.

 
- Erzeugen Sie 100 zufällige Figuren (Kreise oder Rechtecke zufällig) und speichern Sie alle in einem Array.

 
- Erzeugen Sie eine statische Methode, an die das Array aus der vorherigen Aufgabe übergeben werden kann. Die Methode soll die Flächen aller Figuren aus dem Array berechnen und ausgeben.
