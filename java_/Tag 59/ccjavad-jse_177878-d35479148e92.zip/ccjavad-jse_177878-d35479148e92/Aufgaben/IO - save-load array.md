# Aufgabe 'save/load Array'

- Legen Sie bitte ein int-Array der Länge 'len' an und füllen Sie das Array mit Zufallswerten aus dem Bereich 0 bis 50:

		int len = new java.util.Random().nextInt(100) + 1;
		int[] arr1 = createArray(len);


- Speichern Sie das int-Array in einer Datei:

		saveArray(arr1, "array.txt");


- Laden Sie die Werte aus der Datei in ein neues int-Array:

    	int[] arr2 = loadArray("array.txt");


- Geben Sie bitte das alte und das neue Array aus. Die beiden Arrays müssen gleiche Werte beinhalten.


- Optional. Erstellen Sie eine neue Konsolenanwendung in der der User entscheiden darf ob er ein int-Array erzeugen oder laden möchte.
    - Erzeugen. Es wird ein int[] mit Zufallswerten erzeugt und in einer Datei gespeichert. Die Anwendung fragt den User, wie groß das Array sein soll. Die Anwendung fragt den User, wie die Datei heißen soll, in der das Array gespeichert wird.
    - Laden. Die Anwendung lädt ein int[] aus einer Datei und gibt es aus. Die Anwendung fragt den User, wie die Datei heißt.

> Verwenden Sie für die Lösung die Klasse 'java.io.Console'

