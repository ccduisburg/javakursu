# Aufgabe 'ExecutorService'

###### A1.
Laden sie alle englischen Wörter aus der Datei 'english_words_lowercase.zip' in eine List.

###### A2.
Definieren Sie ein `Runnable` Task, in dem die Anzahl der Wörter in der geladenen List ermittelt wird, die ein 't' haben.

###### A3.
Definieren Sie ein `Callable` Task, in dem die Anzahl der Wörter in der geladenen List ermittelt wird, die einen Unterstring 'ss' haben.

###### A4.
Übergeben Sie die beiden Tasks an einen ExecutorService, warten Sie auf die Ergebnisse und geben Sie sie in dem main-Thread aus
