# Aufgabe 'reduce/collect'

Erzeugen Sie bitte eine Klasse `Person`. Jede Person hat einen Vornamen und einen Nachnamen.
Speichern Sie bitte in einer List folgende Personen:

	Tom Katze
	Jerry Maus
	Alexander Poe 

###### A1.
Verwenden Sie bitte eine Stream-Methode `reduce` um eine Person zu erzeugen, die die (lexikographisch) größten Vornamen und Nachnamen aus allen Personen erhält (hier: Tom Poe). 


###### A2.
Verwenden Sie bitte eine Stream-Methode `collect` um alle Personen in einem TreeSet zu speichern. 