## Morgen!

# Pr�fung
- Comcave �bernimmt die Kosten f�r die OCP-Pr�fung
- Die TN, die nach dem 26.06 Comcave verlassen: sie bekommen 2 Wochen zus�tlich Zugang zum Unterricht

## Wissensvermittlung ##
* 08:00 - 09:30 Uhr 
* 09:45 - 11:15 Uhr
* 11:30 - 12:15 Uhr
* 12:20 - 13:00 Uhr

## Sprechstunden ##
* 13:30 - 15:00 Uhr (per Chat rufen)
* 15:15 - 16:45 Uhr (im Skype-Betreuungsraum)

# Aufgaben #
## 20.06
- Kapitel 10
- Deadlock, Livelock, Starvation, Race Condition

- Kapitel 11 (vgl. mit dem Projekt 'Threads', Package 'concurrency')
- AtomicInteger
- Aufgaben/Threads - ExecutorService.md

- Optional: Aufgaben/Threads - B�ckerei.md
- Optional: Aufgaben/Threads - Philosophenproblem.md


## 19.06
- Kapitel 10
- Was ist ein Deadlock? 
- Aufgaben/Threads - Printer.md
- Optional: Aufgaben/Threads - Simple.md
- Optional nachschlagen: Livelock, Starvation, Race Condition
- Optional: wait/notify


## 18.06
- Thread erzeugen und starten (Klasse Thread erweitern)
- Thread erzeugen und starten (Runnable implementieren und als Target
 dem Thread �bergeben)
- Kapitel 10 (OCP-Buch)
- Bitte die Beispiele aus dem projekt 'Thread' durchgehen

## 15.06
- Aufgabe im Projekt 'Functional' im Package 'aufgaben' in der Datei 'AufgabeStreamCollector.java' (s. dazu Bsp. B10 aus dem Package 'streams')
- s. Projekt 'Functional': terminal und intermediate Operationen
- Aufgaben/Stream - collect-Collectors.md
- Aufgaben/Stream - map-flatMap-collect.md

## 14.06
- s. das Projekt 'Functional', Package 'streams' (vgl. mit dem OCP-Buch)
- Aufgaben/Stream - bilden.md
- Aufgaben/Stream - count-min-max.md
- Aufgaben/Stream - reduce-collect.md
- Optional. Aufgaben/Stream - Files - lines.md
- Optional. Aufgaben/Stream - Files - list.md
- Optional. Aufgaben/Stream - Files - walk.md

## 13.06
- s. Projekt 'IO', Bsp. 'io.B10_mark_reset.java'
- Klasse 'Files' (s. Projekt 'IO', Package 'pfade')

- Aufgaben/Files - Dateien erstellen-verschieben-entfernen.md
- Optional: Aufgaben/Files - Verzeichnisse.md

- funktionale Streams. Streams bilden (OCP-Buch)
- Wie bildet man Streams aus einer Collection, einem Array?
- Welche Streams kann man mit der Klasse 'java.nio.file.Files' bilden?

## 12.06
- mark/reset
- Aufgaben/IO - Serialisieren - Dienste.md
- s. alle Beispiele aus dem Projekt 'IO'
- IO-Streams
- Serialisieren
- Bitte in dem OCP-Buch die Beschreibung der Klasse 'Files' durchgehen. Methoden mit den funktionalen Streams sind noch optional.

## 11.06
- s. das Projekt 'IO'
- Interface 'Path', Klasse 'Paths'
- Reader/Writer
- Aufgaben/IO - copy text file.md
- Aufgaben/IO - save-load array.md
- Optional:  Klasse 'Files'

## 08.06
- Methodenreferenzen
- https://docs.oracle.com/javase/tutorial/java/javaOO/methodreferences.html
- Aufgaben/BiFunction - MethodReference.md
- Methode forEach aus Iterable
- Methode removeIf aus Collection
- Methode replaceAll aus List (Achten Sie auf den Parameter-Typ). Bitte testen.
- Suchen Sie nach den Methoden mit funktionalen Parameter im Interface Map (bitte testen)

	
## 07.06
- Generics (OCP Java SE 8 - PII.pdf in den Skype-Anlagen, Projekt 'Generics')
- Aufgabe in dem Projekt 'Generics', Datei 'B10_generische_Methoden.java'
- Aufgaben/Generics - Garage.md
- Optional: Aufgaben/Generics - Platzhalter.md (Achtung! Das PNG-Bild mit dem Klassendiagramm beachten)
- Optional: Aufgaben/Generics - Zoo.md

## 06.06
- Diagramme/Collections-API.md
- Aufgabe im Projekt 'Collections', Package 'aufgaben.deque', Datei 'AufgabePalindrom.java'
- Queue, Deque, ArrayDeque
- Aufgaben/Deque - BrowserHistory.md
- Interface Map und die Klassen HashMap und TreeMap
- Aufgaben/Map - Besitzer - Fahrzeuge.md
- Optional. Generics. s. die Klasse Auto in der L�sung der Aufgabe 'Collections-Autos.md'
- Optional. Aufgaben/Map - FileTypes.md

## 05.06
- Aufgaben/Set - Abfahrtzeiten.md
- Set, TreeSet (SCJP-Buch)
- Selbst�ndig: Queue, PriorityQueue (SCJP-Buch)
- Aufgaben/Collections-Autos.md mit TreeSet und PriorityQueue
- Selbst�ndig: Map, HashMap, LinkedHashMap, TreeMap und Hashtable (SCJP-Buch)
- Optional: Deque, ArrayDeque

## 04.06
- Aufgaben/ExceptionBuilder - Function.md
- Collections (s. das Projekt 'Collections' und Diagramme/Collections - API.uxf)
- List, ArrayList, LinkedList (SCJP-Buch, Diagramme/Collections - List.uxf)
- Set, HashSet (SCJP-Buch)
- Aufgaben/Collections-Autos.md
- Optional: Aufgaben/List - Benchmark.md
- Optional: Aufgaben/Set - FileTypes.md

## 01.06
- s. das Projekt 'ErrorHandling'
- SCJP-Buch: F�nf Beispiele der sinvollen Verwendung von Assertions
- Vier funktionale Interfaces auswendig lernen (abstrakte Methoden daraus):
    - Predicate
    - Consumer
    - Supplier
    - Function
- Optional: Was sind Methodenreferenzen? Welche vier Arten davon gibt es in Java?
- Optional: statische Initialisierungsbl�cke. Wann werden Sie ausgef�hrt?

## 30.05
- Aufgaben/Exceptions - Vererbungshierarchie.md
- Wdh. Wrapperklassen 
- s. Package 'entwurfsmuster' aus dem Projekt 'OOP'
- s. das Projekt 'ErrorHandling'
- try-with-resources (Insel-Buch)
- Multicatch
- Optional: statische Initialisierungsbl�cke. Wann werden Sie ausgef�hrt
- Optional: Aufgaben/Exceptions - IntMatrix.md

## 29.05
- Aufgaben/Interfaces - Comparable - Comparator.md
- Aufgaben/Enums - Hunderassen.md
- s. die Beispiele aus dem Projekt 'OOP'

## 28.05
- Aufgaben/Klassen - Geometrie.md
- Aufgaben/Vererbung - Geometrie.md
- Aufgaben/Polymorphie - Geometrie.md
- Diagramme/Stack und Heap.pptx
- Wdh. Klassen, Vererbung


# Git mit Netbeans #
* Repo clonen: Team->Git->Clone (oder Team->Remote->Clone)
* Repository Browser �ffnen: Team -> Repository -> Repository Browser
* Repo aktualisieren: Im Repository Browser Rechtsklick auf das Repo -> Remote -> Pull


# Allgemein #
- Kursinhalte:  https://bitbucket.org/ccjavad/jse_177878.git
- UML-Tool: http://www.umlet.com/
- Klausur:      18.06. 08:15 Uhr, Multiple-Choice, 90 Min, alle Hilfsmitteln erlaubt
- Pr�fung:      ??.??
