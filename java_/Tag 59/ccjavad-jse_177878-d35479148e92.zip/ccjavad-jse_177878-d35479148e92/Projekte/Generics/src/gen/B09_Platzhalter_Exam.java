package gen;

import java.util.*;

public class B09_Platzhalter_Exam {

    public static void main(String[] args) {
        
        List listA = null;
        
        List<?> listB = listA;  // ? steht für ? extends Object

        listA = listB;
        
        // List<> listC = listA;    // Compilerfehler
        
        List<Integer> listD = new ArrayList<>();
        
        listB = listD;
        
        List<Integer> listE = new ArrayList<?>();
        
        
    }
    
}
