package gen;

import java.util.*;

public class B06_ZuweisungenKontrollieren {

    public static void main(String[] args) {
        
        Object x = "Hallo";
        /*
            Referenzenzuweisung. Immer:
                1. IS-A-Beziehung
        */
        
        /*
            1. String <- IS-KEIN <- Object     : Compilerfehler
        */
        String y = x; // Compilerfehler
        
        
        /*
            Referenzenzuweisung von generischen Variablen:
                1. IS-A-Beziehung
                2. Parametrisierungen
        */
        Collection<Integer> collInt = null;
        List<Integer> listInt = new ArrayList<>();
        
        
        /*
            1. Collection <- IS-A <- List       : OK
            2. <Integer> beinhaltet <Integer>   : OK
        */
        collInt = listInt;
        
        /*
            1. List <- IST-KEINE <- Collection  : Compilerfehler bereits bei der 1. Kontrolle
        */
        listInt = collInt;
        
        
        /*
            1. List <-IS-A<- List                       : OK
            2. <Double> beinhaltet NICHT <Integer>      : Compilerfehler
        */
        List<Double> listDouble = listInt;
        listDouble.add(22.3);
        
        
        
        Collection<Number> collNumber = null;
        List<Integer> list = new ArrayList<>();
        
        /*
            Achtung!!! bei der 2. Kontrolle wird die
            Vererbung nicht berücksichtigt!!!
        
            1. Collection <- IS-A <- List           : OK
            2. <Number> beinhaltet NICHT <Integer>  : Compilerfehler
        */
        collNumber = list;
        collNumber.add(22.3);
    }
    
}
