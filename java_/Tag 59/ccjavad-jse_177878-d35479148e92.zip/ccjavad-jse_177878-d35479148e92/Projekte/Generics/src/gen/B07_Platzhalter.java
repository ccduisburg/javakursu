package gen;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class B07_Platzhalter {
    
    public static void main(String[] args) {
        
        List<Integer> listInt = new ArrayList<>();
        listInt.add(12);
        listInt.add(13);
        listInt.add(14);
        
        // 1. Collection < IS-A < List
        // 2. <? extends Number> beinhaltet <Integer>
        print(listInt);
    
        Set<Integer> setInt = new HashSet<>();
        setInt.add(3);
        setInt.add(4);
        
        // 1. Collection < IS-A < Set
        // 2. <? extends Number> beinhaltet <Integer>
        print(setInt); 
        
        List<Double> listDouble = Arrays.asList(22.3, 33.4);

        // 1. Collection < IS-A < List
        // 2. <? extends Number> beinhaltet <Double>
        print(listDouble);
        
        
        /*
            Noch ein Test
        */
        System.out.println( exists(listInt, 22) );
        System.out.println( exists(setInt, 22) );
        System.out.println( exists(listDouble, 22) );
        
    } // end of main


    /*
        Keine Methode mit dem generischen Parameter
        lässt sich mit der Variable aufrufen,
        die mit ? extends parametrisiert war!
    */
    static void print(Collection<? extends Number> values) {
//        values.add(5F);
//        values.add(22.3);
        
        System.out.println(values);
    }
     
    static boolean exists(Collection<? extends Number> coll, Number n) {
                    // coll.add(22);    // add(E)
        return coll.contains(n);        // contains(Object)
    }
}
