package gen;

import java.util.ArrayList;
import java.util.List;

public class B03_Erasing {

    /*
        alte Methode, die ohne Generics realisiert war
    */
    static void legacyMethod(List list) {
        list.add("Moin!");
        list.add(true);
    }
    
    
    public static void main(String[] args) {
        
        List<Integer> list = new ArrayList<>(); // die Parametrisierung ist nach 
                                                // dem Kompilieren gelöscht!
        list.add(12);
        list.add(13);
//        list.add("Hallo");
//        list.add(false);
        
        legacyMethod(list); // geht. zur Laufzeit keine generischen Angaben
        
        System.out.println(list); // [12, 13, Moin!, true]
    }
    
}
