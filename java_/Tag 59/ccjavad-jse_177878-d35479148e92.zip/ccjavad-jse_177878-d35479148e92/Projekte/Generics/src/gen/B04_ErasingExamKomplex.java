package gen;

import java.util.Arrays;

/*
... class Integer implements Comparable<Integer> ...

    public int compareTo(Integer anotherInteger) {
        ...
    }

BEIM ERASING:


... class Integer implements Comparable ...

    public int compareTo(Integer anotherInteger) {
        ...
    }

    //generiert vom Compiler:
    public int compareTo(Object param) {
        Integer x = (Integer)param;
        return compareTo(x);
    }

*/

public class B04_ErasingExamKomplex {

    public static void main(String[] args) {
        
        // Arrays.stream( Integer.class.getMethods() ).forEach(System.out::println);
        
        Object[] arr = {
            "a", "c", "b", 22
        };
        
//        Comparable c0 = (Comparable)arr[0];
//        Comparable c3 = (Comparable)arr[3];
//        c0.compareTo(c3); // java.lang.Integer cannot be cast to java.lang.String
//        c3.compareTo(c0); // java.lang.String cannot be cast to java.lang.Integer
        
        Arrays.sort(arr); // ClassCastException!

//        System.out.println(Arrays.toString(arr)); // [a, b, c]
    }
    
}
