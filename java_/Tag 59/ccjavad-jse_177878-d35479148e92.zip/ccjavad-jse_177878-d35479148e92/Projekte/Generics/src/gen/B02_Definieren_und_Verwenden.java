package gen;

interface Tv {}
class TvDe implements Tv {}
class TvUk implements Tv {}

/*
    Hier wird der generische Typ definiert:
*/
class Steckdose <T extends Tv> { // extends steht hier für IS-A
    private T tv;
    
    void anschliessen(T tv) {
        this.tv = tv;
    }
    
    T getTv() {
        return tv;
    }
}

//class SteckdoseUk {
//    private TvUk tv;
//    
//    void anschliessen(TvUk tv) {
//        this.tv = tv;
//    }
//    
//    TvUk getTv() {
//        return tv;
//    }
//}

public class B02_Definieren_und_Verwenden {
    public static void main(String[] args) {
        /*
            Hier wird der generische Typ verwendet:
        */
        Steckdose<TvDe> sdDe = new Steckdose<>();
        sdDe.anschliessen(new TvDe()); // soll kompilieren und laufen
        sdDe.anschliessen(new TvUk()); // darf nicht kompilieren!!!
        
        Steckdose<TvUk> sdUk = new Steckdose<>();
        sdUk.anschliessen(new TvDe()); // darf nicht kompilieren!!!
        sdUk.anschliessen(new TvUk()); // soll kompilieren und laufen
     
        sdDe = sdUk; // darf nicht kompilieren
        
        Steckdose<String> sdSinnlos = new Steckdose<>(); // soll nicht kompilieren
        sdSinnlos.anschliessen("Bin kein Fernseher!");
        
        Steckdose<?> sdAll;   // hier ? heißt ? extends Tv
        sdAll = sdDe;
        sdAll = sdUk;
        
        sdAll.anschliessen(new TvDe()); // da sdAll ? extends hat
        sdAll.anschliessen(new TvUk()); // da sdAll ? extends hat
    }
}
