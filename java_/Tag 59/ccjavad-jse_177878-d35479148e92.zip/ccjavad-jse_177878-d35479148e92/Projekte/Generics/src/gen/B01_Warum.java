package gen;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class B01_Warum {
    
    static class Person {}

    public static void main(String[] args) {
        
        /*
            Ohne Generics: Fehler erst zur Laufzeit (wenn überhaupt)
        */
        
        Person[] arr = { new Person(), new Person() };
        if(new Random().nextBoolean()) {
            Arrays.sort(arr);
        }
        
        /*
            Mit Generics: Fehler bereits zur Compilerzeit erkannt
        */
        List<Person> list = Arrays.asList(arr);
        // Collections.sort(list);  // Compilerfehler: Person soll Comparable sein
        
    }
    
}
