package gen;

import java.util.List;

public class B05_ErasingExampleSimple {
    
    void print(List<Integer> x) {}
    void print(List<Double> y) {}

    // BEIM ERASING:
    // void print(List x) {}
    // void print(List y) {}
}
