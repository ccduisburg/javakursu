package gen;

import java.util.Collections;

class Auto implements Comparable<Auto> {
    public int compareTo(Auto o) {
        return 0;
    }
}

class VW extends Auto {}

// public static <T extends Comparable<? super T>> void sort(List<T> list)
public class B10_generische_Methoden {

    /* Bitte die getMax definieren */
    
    static <T extends Comparable<T>> T getMax(T x, T y) {
        if( x.compareTo(y) > 0 ) {
            return x;
        }
        
        return y;
    }
    
    public static void main(String[] args) {
        Integer i1 = 22;
        Integer i2 = 33;
        Integer i3 = getMax(i1, i2);
        System.out.println("i3 = " + i3); // i3 = 33
        
        Double d1 = 22.0;
        Double d2 = 33.0;
        Double d3 = getMax(d1, d2);
        System.out.println("d3 = " + d3); // d3 = 33.0
        
        getMax(i1, d2); //es darf nicht kompilieren
        
        String s1 = "a";
        String s2 = "b";
        String s3 = getMax(s1, s2); // soll gehen
        System.out.println("s3 = " + s3); // s3 = b
        
        
        VW a1 = new VW();
        VW a2 = new VW();
        
        VW a3 = getMax(a1, a2);
    }
}
