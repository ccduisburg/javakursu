package gen;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;

public class B08_Platzhalter_wahrscheinlich_nicht_in_der_Exam {

    public static void main(String[] args) {
        HashSet<Integer> setInt = new HashSet<>();
        addInteger(setInt);
        System.out.println("setInt = " + setInt);
        
        PriorityQueue<Double> queueDouble = new PriorityQueue<>();
        // addInteger(queueDouble);
        
        List<Number> listInt = new ArrayList<>();
        addInteger(listInt);
        
        Collection<Object> collObj = new LinkedList<>();
        addInteger(collObj);
    }
    
    // universell und typsicher soll die Methode
    // 2 neue Integer einer Collection hinzufügen
    static void addInteger(Collection<? super Integer> coll) {
        coll.add(22);
        coll.add(33);
    }
    
}
