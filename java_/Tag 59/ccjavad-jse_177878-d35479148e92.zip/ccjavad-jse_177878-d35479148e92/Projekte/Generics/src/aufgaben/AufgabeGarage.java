package aufgaben;

interface Fahrzeug {}
class PKW implements Fahrzeug {}
class LKW implements Fahrzeug {}

class Garage <T extends Fahrzeug> {
    private T fahrzeug;
    
    void reinfahren(T fahrzeug) {
        this.fahrzeug = fahrzeug;
    }
}

public class AufgabeGarage {

    public static void main(String[] args) {
        
        Garage<PKW> g1 = new Garage<>();
        g1.reinfahren(new PKW());
        g1.reinfahren(new LKW());
        
        Garage<LKW> g2 = new Garage<>();
        g2.reinfahren(new PKW());
        g2.reinfahren(new LKW());
        
        // g1 = g2;
        
        Garage<String> g3 = new Garage<>();
        
    }
    
}
