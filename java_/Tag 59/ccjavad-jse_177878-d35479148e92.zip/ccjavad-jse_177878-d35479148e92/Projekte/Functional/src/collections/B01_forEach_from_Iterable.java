package collections;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class B01_forEach_from_Iterable {
    
    static class Counter {
        int count;
        
        void incrementIfNotNull(Integer i) {
            if(i!=0) {
                count++;
            }
        }
    }

    public static void main(String[] args) {
        
        List<Integer> listInt = Arrays.asList(1, 0, 3, 0);

        Counter countNotNull = new Counter();
        Consumer<Integer> c1 = new Consumer<Integer>() {
            @Override
            public void accept(Integer t) {
                if(t!=0) {
                    countNotNull.count++;
                }
            }
        };
        listInt.forEach(c1);
        System.out.println("1. counter: " + countNotNull.count);
        
        /*
            Lambda
        */
        countNotNull.count = 0; // reset
        Consumer<Integer> c2 = i -> { 
            if(i!=0) {
                countNotNull.count++;
            }
        };
        listInt.forEach(c2);
        System.out.println("2. counter: " + countNotNull.count);
        
        /*
            Mit einer Methodenreferenz
        */
        countNotNull.count = 0; // reset
        listInt.forEach( countNotNull::incrementIfNotNull );
        System.out.println("3. counter: " + countNotNull.count);
        
    }
    
}
