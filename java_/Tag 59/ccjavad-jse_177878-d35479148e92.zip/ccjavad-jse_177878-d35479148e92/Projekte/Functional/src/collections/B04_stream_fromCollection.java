package collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Stream;

public class B04_stream_fromCollection {

    public static void main(String[] args) {
        
        Collection<String> coll = Arrays.asList("mo", "di", "mi");
        
        //Stream<String> s = coll.stream();
        
        coll.stream()
            .filter( str -> str.startsWith("m") )  // intermediate operation, returns Stream
            .forEach( str -> System.out.println(str)  ); // terminal operation
        
    }
    
}
