package collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.function.Predicate;

public class B02_removeIf_fromCollection {
    public static void main(String[] args) {
        Collection<String> coll = new ArrayList<>();
        coll.add("a");
        coll.add("moin");
        coll.add("ahorn");
        coll.add("tmp");
        
        Predicate<String> filter = s -> s.startsWith("a");
        
        //Removes all of the elements of this collection that 
        //satisfy the given predicate
        coll.removeIf(filter);
        System.out.println("coll: " + coll); // [moin, tmp]
        
        
    }
}
