package collections;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.function.UnaryOperator;

public class B03_replaceAll_fromList {

    public static void main(String[] args) {
        
        List<Integer> list = Arrays.asList( 1, 2, 3, 4, 5, 6 );
        System.out.println("1. list: " + list);
        
        UnaryOperator<Integer> operator = i -> i * 2;
        list.replaceAll(operator);
        System.out.println("2. list: " + list); //  [2, 4, 6, 8, 10, 12]
    }
    
}
