package collections;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;

public class B05_functional_Map_API {

    public static void main(String[] args) {
        
        // Map ist NICHT Iterable, hat dafür forEach-Methode
        
        Map<Integer, String> map = new HashMap<>();
        map.put(1, "Java");
        map.put(2, "C++");
        map.put(3, "Kotlin");
        
        
        System.out.println("******* forEach: ");
        
        BiConsumer<Integer, String> action = new BiConsumer<Integer, String>() {
            @Override
            public void accept(Integer key, String value) {
                System.out.println(key + " = " + value);
            }
        };
        
        map.forEach(action);
        
        
        System.out.println("******* computeIfAbsent/Present: ");
        
        // V computeIfPresent(K key, BiFunction<K, V, V> remappingFunction)
        BiFunction<Integer, String, String> remappingFunction 
                = (k, currentValue) -> currentValue + " ist auch toll";
        Integer key = 2;
        map.computeIfPresent(key, remappingFunction);
        
        System.out.println( map );
        
        // falls es den key2 nicht gibt, function anwenden 
        Function<Integer, String> remappingFunction2 = k -> "Scala";
        Integer key2 = 4;
        map.computeIfAbsent(key2, remappingFunction2);

        System.out.println( map );
        
        
        System.out.println("******* replaceAll: ");
        
        remappingFunction = (k, currentValue) -> currentValue.toUpperCase();
        map.replaceAll(remappingFunction);
        System.out.println( map );        
        
        
        System.out.println("******* Optional. merge: ");
        // falls nicht 1=JAVA gibt (genauso, kein anderer Wert) -> erzeuge 1=JAVA,
        // sonst: remapping Function anwenden (also wenn es 1=JAVA es doch gibt).
        map.merge(1, "JAVA", (k,currentValue) -> currentValue.concat(" rules!") );
        System.out.println( map );
        
        System.out.println("******* Optional. compute: ");

        // currentValue kann null sein, z.B. wenn es kein key 5 gibt.
        map.compute(5, (k,currentValue) -> currentValue!=null ? currentValue : "Groovy" );
        System.out.println( map );
    }
}
