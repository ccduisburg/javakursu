package func;

import java.util.function.Predicate;

/*
    1.  Lambdas:

        - Es soll ein funktionales Interface realisiert werden.
        - Es soll kompakt erfolgen (keine neue Klasse definieren)

    2.  Methodenreferenz

        - Es soll ein funktionales Interface realisiert werden.
        - Es soll kompakt erfolgen (keine neue Klasse definieren)
        - Es gibt bereits eine Methode, die die Logik bereits realisiert,
            die die Lambda-Funktion realisieren würde
        
*/

class MyMath {
    static boolean isKleinerAlsNull(Integer x) {
        return x < 0;
    }
}

public class B08_Method_Reference {
    
    public static void main(String[] args) {
        
        Predicate<Integer> var = new Predicate<Integer>() {
            @Override
            public boolean test(Integer t) {
                return MyMath.isKleinerAlsNull(t);
            }
        };
        
        Predicate<Integer> isNegative1 = i -> i < 0;
        Predicate<Integer> isNegative2 = i -> MyMath.isKleinerAlsNull(i);
        
        Predicate<Integer> isNegative3 = MyMath::isKleinerAlsNull;
     
        System.out.println( isNegative1.test(-3) );
        System.out.println( isNegative2.test(-3) );
        System.out.println( isNegative3.test(-3) );
    }
    
}
