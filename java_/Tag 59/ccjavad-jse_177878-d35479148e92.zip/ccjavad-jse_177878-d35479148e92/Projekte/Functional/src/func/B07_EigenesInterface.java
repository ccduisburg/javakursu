package func;

interface Computer <P1, P2, R> {
    R compute(P1 a, P2 b);
}

public class B07_EigenesInterface {

    static Integer getMax(Integer i1, Integer i2) {
        return i1 > i2 ? i1 : i2;
    }
    
    public static void main(String[] args) {
        
        Computer<Integer, Integer, Integer> c1 = (p1, p2) -> getMax(p1, p2);
        
    }
    
}
