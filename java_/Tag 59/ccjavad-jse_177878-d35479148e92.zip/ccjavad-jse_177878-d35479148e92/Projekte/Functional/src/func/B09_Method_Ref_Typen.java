package func;

import java.util.ArrayList;
import java.util.function.Function;
import java.util.function.Supplier;

public class B09_Method_Ref_Typen {
    
    static class Auto {}


    /*
        
    */
    public static void main(String[] args) {

        //-------------------------------------------------
        Integer i_ = Integer.valueOf("123");
        Function<String, Integer> f0 = s -> Integer.valueOf(s); // Lambda
        Integer i0 = f0.apply("123");
        
        /*
            1. Referenz auf eine statische Methode:
        */
        Function<String, Integer> f1 = Integer::valueOf;
        Integer i1 = f1.apply("123");
        
        
        
        //-------------------------------------------------
        Supplier<Auto> s0 = () -> new Auto(); // Lambda
        Auto a0 = s0.get();
        /*
            2. Referenz auf Constructor:
        */
        Supplier<Auto> s1 = Auto::new; 
        Auto a1 = s1.get();


        
        //-------------------------------------------------
        Object obj = "Hallo Welt";
        
        Function<Object, Boolean> po0 = param -> obj.equals(param);
        /*
            3. Referenz auf eine Instanz-Methode eines speziellen Objektes:
        */
        Function<Object, Boolean> po1 = obj::equals;
        
        
        
        //-------------------------------------------------
        Integer y = 22;
        Double z = y.doubleValue();
        
        Function<Integer, Double> intToDouble0 = i -> i.doubleValue();
        Double z0 = intToDouble0.apply(22);
        
        /*
            Sehr unwahrscheinlich in der Prüfung.
            
            4. Referenz auf eine Instanz-Methode eines unbestimmten Objektes
                vom speziellen Typ:
        
                (Der Parameter der apply ist vom Typ Integer
                und hat die Instanz-Methode doubleValue,
                die die Logik realisiert.)
        */
        Function<Integer, Double> intToDouble1 = Integer::doubleValue;
        Double z1 = intToDouble1.apply(22);
        
    }
    
}
