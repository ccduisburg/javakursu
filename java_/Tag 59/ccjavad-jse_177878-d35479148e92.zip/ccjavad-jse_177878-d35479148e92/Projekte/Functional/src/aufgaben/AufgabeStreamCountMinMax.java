package aufgaben;

import java.text.NumberFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class AufgabeStreamCountMinMax {

    public static void main(String[] args) {
        Locale loc = Locale.GERMANY;
        String land = loc.getDisplayCountry();
        System.out.println("land: " + land);
        
//        Locale loc = Locale.US;
//        Locale loc = Locale.CHINA;
//        Locale loc = new Locale("ru", "RU");
        NumberFormat waehrungFormat = NumberFormat.getCurrencyInstance(loc);
        String betragAlsString = waehrungFormat.format(23.3785);
        System.out.println(betragAlsString);
        
        /*
            A1
        */
        Locale[] locales = Locale.getAvailableLocales();
        
        Function<Locale, String> keyExtractor = locale -> locale.getDisplayCountry();
//        Comparator<Locale> tmp = new Comparator<Locale>() {
//            @Override
//            public int compare(Locale o1, Locale o2) {
//                Comparable c1 = keyExtractor.apply(o1);
//                return c1.compareTo(o2);
//            }
//        };
        
        Comparator<Locale> comparator = Comparator.comparing(keyExtractor);
        Optional<Locale> opMax = Arrays.stream(locales).max(comparator);
        Locale max = opMax.orElseThrow(() -> new RuntimeException("max locale nicht gefunden"));
        System.out.println("max: " + max 
                + ", display country: " +  max.getDisplayCountry());
        
        /*
            A2
        */
        System.out.println("-------- A2. ");
        Predicate<Locale> predicate = locale -> locale.getLanguage().equals("de");
        long count_de = Arrays.stream(locales)
                .filter(predicate)
//                .peek(locale -> System.out.println(locale.getDisplayCountry()))
                .count();
        System.out.println("count Locales mit 'de': " + count_de);

        /*
            A3
        */
        System.out.println("-------- A3. ");
        Stream.of(locales)
                .filter(locale -> locale.getDisplayCountry().contains("t"))
                .min(Comparator.comparing(Locale::getDisplayLanguage))
                .ifPresent( locale -> {
                    System.out.println( locale.getDisplayCountry() );
                    System.out.println( locale.getDisplayLanguage() );
                } );
                
    }
    
    
}
