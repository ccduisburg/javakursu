package aufgaben;

import java.util.function.BiFunction;

class Aussage {
    Bewertung createForSelf(Boolean b) { return new Bewertung(this, b); }
}
class Bewertung {
    static Bewertung create(Aussage a, Boolean b) { return new Bewertung(a, b); }
    
    Bewertung(Aussage a, Boolean b) { /*...*/ }
}
class BewertungBuilder {
    Bewertung build(Aussage a, Boolean b) { return new Bewertung(a, b); }
}

public class AufgabeMethodReference {

    public static void main(String[] args) {
        
        /*
            mit der anonymen Klasse
        */
        BiFunction<Aussage, Boolean, Bewertung> f1 
                = new BiFunction<Aussage, Boolean, Bewertung>() {
                    public Bewertung apply(Aussage a, Boolean b) {
                        return new Bewertung(a, b);
//                        return Bewertung.create(a, b);
//                        return builder.build(a, b);
//                        return a.createForSelf(b);
                    }
                };
        Bewertung b1 = f1.apply(new Aussage(), true);
        
        /*
            mit Lambda
        */
        BiFunction<Aussage, Boolean, Bewertung> f2 
                = (a, b) -> new Bewertung(a, b);
        Bewertung b2 = f2.apply(new Aussage(), true);
        
        
        /*
            mit Referenz auf einen Konstruktor
        */
        BiFunction<Aussage, Boolean, Bewertung> f3 = Bewertung::new;
        Bewertung b3 = f3.apply(new Aussage(), true);
        
        
        /*
            mit Referenz auf eine statische Methode
        */
        BiFunction<Aussage, Boolean, Bewertung> f4 = Bewertung::create;
        Bewertung b4 = f4.apply(new Aussage(), true);
        
        /*
            mit Referenz auf eine Instanzmethode eines bestimmten Objektes
        */
        BewertungBuilder builder = new BewertungBuilder();
        BiFunction<Aussage, Boolean, Bewertung> f5 = builder::build;
        Bewertung b5 = f5.apply(new Aussage(), true);
        
        
        /*
            mit Referenz auf eine Instanzmethode eines unbestimmten Objektes
            eines speziellen Types
        */
        BiFunction<Aussage, Boolean, Bewertung> f6 = Aussage::createForSelf;
        Bewertung b6 = f6.apply(new Aussage(), true);
        
    }
    
}
