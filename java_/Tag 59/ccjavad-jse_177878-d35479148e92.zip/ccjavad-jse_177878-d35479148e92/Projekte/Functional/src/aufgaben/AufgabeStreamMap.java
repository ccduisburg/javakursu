package aufgaben;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AufgabeStreamMap {

    public static void main(String[] args) {
        
        
        String[] arr = {
			"1,2,3,4,5",
			"7,6,5,4,3",
			"123,456",
		};
        
//        Stream<String> stringStream = Arrays.asList(arr).stream();
//        
//        Function<String, String[]> mapper = s -> s.split(",");
//        Stream<String[]> arraysStream = stringStream.map(mapper);
//        
//        Function<String[], Stream<String>> mapperSimple 
//                = arrStrings -> Arrays.stream(arrStrings);
//        
//        Stream<String> concatStream = arraysStream.flatMap(mapperSimple);
//        
//        Function<String, Integer> mapperToInt = s -> Integer.valueOf(s);
//        Stream<Integer> intStream = concatStream.map(mapperToInt);
//        
//        List<Integer> collectedList = intStream.collect(Collectors.toList());
        
        List<Integer> list = Arrays.asList(arr).stream()
                .map( s -> s.split(",") )
                .flatMap( arrStrings -> Arrays.stream(arrStrings) )
                .map( s -> Integer.valueOf(s) )
//                .filter( i -> i % 2 == 0 ) // Aufgabe 2
                .collect( Collectors.toList() );
        
        System.out.println(list); // [1, 2, 3, 4, 5, 7, 6, 5, 4, 3, 123, 456]
    }
    
}
