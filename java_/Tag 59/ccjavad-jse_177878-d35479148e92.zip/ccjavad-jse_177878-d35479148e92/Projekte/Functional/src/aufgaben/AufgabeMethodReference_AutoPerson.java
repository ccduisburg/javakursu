package aufgaben;

import java.util.function.BiFunction;

class Auto {
    Person create(Integer i) {
        return new Person(this, i);
    }
}

class Person {
    static Person create(Auto a, Integer i) {
        return new Person(a, i);
    }
    
    Person(Auto a, Integer i) {}
}

class PersonBuilder {
    Person build(Auto a, Integer i) {
        return new Person(a, i);
    }
}

public class AufgabeMethodReference_AutoPerson {

    public static void main(String[] args) {
        
        // A1
        BiFunction<Auto, Integer, Person> f1 
                = new BiFunction<Auto, Integer, Person> () {
                    public Person apply(Auto a, Integer i) {
                        return new Person(a, i);
                    }
                };
        
        // A2
        BiFunction<Auto, Integer, Person> f2 = (a, i) -> new Person(a, i);
        
        // A3
        BiFunction<Auto, Integer, Person> f3 = Person::create;
        Person p3 = f3.apply(new Auto(), 22);
        
        // A4
        BiFunction<Auto, Integer, Person> f4 = Person::new;
        
        // A5
        PersonBuilder b = new PersonBuilder();
        BiFunction<Auto, Integer, Person> f5 = b::build;
        
        // A6
        BiFunction<Auto, Integer, Person> f6 = Auto::create;
        System.out.println(f6.apply(new Auto(), 7));
        
        
    }
    
}
