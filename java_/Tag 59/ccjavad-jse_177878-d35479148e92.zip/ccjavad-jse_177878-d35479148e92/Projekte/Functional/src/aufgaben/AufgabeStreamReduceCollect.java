package aufgaben;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.function.Supplier;

public class AufgabeStreamReduceCollect {

    private static class Person implements Comparable<Person> {
        private String vorname, nachname;

        public Person(String vorname, String nachname) {
            this.vorname = vorname;
            this.nachname = nachname;
        }

        public String getVorname() {
            return vorname;
        }

        public String getNachname() {
            return nachname;
        }

        @Override
        public String toString() {
            return vorname + " " + nachname;
        }

        @Override
        public int compareTo(Person p2) {
            int erg = nachname.compareTo(p2.nachname);
            return erg != 0 ? erg : vorname.compareTo(p2.vorname);
        }
    }

    private static final List<Person> personen = Arrays.asList(
            new Person("Tom", "Katze"),
            new Person("Jerry", "Maus"),
            new Person("Alexander", "Poe")
    );
    
    private static String max(String s1, String s2) {
        return s1.compareTo(s2) > 0 ? s1 : s2;
    }
    
    public static void main(String[] args) {
        
        /*
            A1
        */
        Person identity = new Person("", "");
        BinaryOperator<Person> accumulator = (p1, p2) -> {
            String vorname = max(p1.getVorname(), p2.getVorname());
            String nachname = max(p1.getNachname(), p2.getNachname());
            return new Person(vorname, nachname);
        };
        Person result = personen.stream().reduce(identity, accumulator);
        System.out.println("result: " + result);
        
        /*
            A2
        */
        Supplier<TreeSet<Person>> supplier = TreeSet::new;
        BiConsumer<TreeSet<Person>, Person> accu = TreeSet::add;
        BiConsumer<TreeSet<Person>, TreeSet<Person>> combiner = TreeSet::addAll;
        
        TreeSet<Person> treeSet = personen.stream().collect(supplier, accu, combiner);
        System.out.println("treeSet: " + treeSet);
    }
    
}
