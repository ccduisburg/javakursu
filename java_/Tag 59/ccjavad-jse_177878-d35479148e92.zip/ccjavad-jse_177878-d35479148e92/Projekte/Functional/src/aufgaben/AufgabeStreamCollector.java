package aufgaben;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class AufgabeStreamCollector {

    static class OS {
        String name;
        int version;

        public OS(String name, int version) {
            this.name = name;
            this.version = version;
        }

        @Override
        public String toString() {
            return name;
        }
    }
    
    public static void main(String[] args) {
        
        OS[] systeme = {
            new OS("Linux Special", 2),
            new OS("Linux Mint", 1),
            new OS("Linux Redhat", 2),
            new OS("Linux Fedora", 1),
        };
        
        Function<OS, Integer> classifier = os -> os.version;
        Collector<OS,?,Map<Integer, List<OS>>> collector 
                = Collectors.groupingBy(classifier);
        
        //Bitte folgende Map mit Stream.collect und Collectors.groupingBy
        // erzeugen.
        Map<Integer, List<OS>> map = Arrays.stream(systeme).collect(collector);
        /*
            Key: 1       List: [Linux Mint, Linux Fedora]
            Key: 2       List: [Linux Special, Linux Redhat]
        */
        for (Integer key : map.keySet()) {
            List<OS> value = map.get(key);
            System.out.println(key + " -> " + value);
        }
        
    }
    
}
