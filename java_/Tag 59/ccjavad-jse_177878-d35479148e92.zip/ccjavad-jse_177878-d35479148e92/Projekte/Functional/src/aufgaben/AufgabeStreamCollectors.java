package aufgaben;

import java.util.*;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class AufgabeStreamCollectors {

    static class Auto {

        String hersteller, modell;
        int baujahr;

        public Auto(String hersteller, String modell) {
            this.hersteller = hersteller;
            this.modell = modell;
        }

        public String getHersteller() {
            return hersteller;
        }

        public String getModell() {
            return modell;
        }

        public String toString() {
            return hersteller + "/" + modell;
        }
    }
    
    static List<Auto> autos = Arrays.asList(
					new Auto("VW", "Golf"),
					new Auto("VW", "Polo"),
					new Auto("Opel", "Corsa"),
					new Auto("Opel", "Astra")
				);
    
    public static void main(String[] args) {
        
        aufgabeMapping();
        aufgabeGroupingBy01();
        aufgabeGroupingBy02();
        aufgabeGroupingBy03();
    }
    
    static void aufgabeGroupingBy03() {
        System.out.println("--- groupingBy 03. ");

        Function<Auto, String> classifier = Auto::getHersteller;
        
        Collector<Auto, ?, List<Auto>> downstream = Collectors.toList();
        
//        Supplier<Map<String, List<Auto>>> mapFactory = () -> new TreeMap<>();
        Supplier<Map<String, List<Auto>>> mapFactory = TreeMap::new;
        
        Collector<Auto, ?, Map<String, List<Auto>> > collector 
                = Collectors.groupingBy(classifier, mapFactory, downstream);
        
        // String-Keys müssen in der Map sortiert sein
        Map<String, List<Auto>> map = autos.stream().collect(collector);
	System.out.println(map);
    }
    
    static void aufgabeGroupingBy02() {
        System.out.println("--- groupingBy 02. ");
        
        Collector<Auto, ?, List<String>> downstream 
                = Collectors.mapping(Auto::getModell, Collectors.toList());
        
        Function<Auto, String> classifier = Auto::getHersteller;
        
        Collector<Auto, ?, Map<String, List<String>>> collector 
                = Collectors.groupingBy(classifier, downstream);
        
        Map<String, List<String>> map = autos.stream().collect(collector);
	System.out.println(map); 
	// mögliche Ausgabe: {VW=[Golf, Polo], Opel=[Corsa, Astra]}
    }
    
    static void aufgabeGroupingBy01() {
        System.out.println("--- groupingBy 01. ");
        
        Function<Auto, String> classifier = a -> a.getHersteller();
        
        Collector<Auto, ?, Map<String, List<Auto>>> collector 
                = Collectors.groupingBy(classifier);
        
        Map<String, List<Auto>> map = autos.stream().collect(collector);
	System.out.println(map); 
	// mögliche Ausgabe: {VW=[VW/Golf, VW/Polo], Opel=[Opel/Corsa, Opel/Astra]}
    }
    
    static void aufgabeMapping() {
        Collector<String, ?, Set<String>> downstream = Collectors.toSet();
        
//        Function<Auto, String> mapper = auto -> auto.getHersteller(); // OK
        Function<Auto, String> mapper = Auto::getHersteller;
        
        Collector<Auto, ?, Set<String>> collector 
			= Collectors.mapping(mapper, downstream);
        
        Set<String> alleHersteller = autos.stream().collect(collector);
        
        System.out.println("--- mapping. ");
        System.out.println(alleHersteller); // [VW, Opel]
    }

}
