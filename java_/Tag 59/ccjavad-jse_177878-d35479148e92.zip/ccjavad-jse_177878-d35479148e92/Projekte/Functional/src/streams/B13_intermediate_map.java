package streams;

import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class B13_intermediate_map {
    
    static class Tier {
        private String name;

        public Tier(String name) {
            this.name = name;
        }

        public String toString() {
            return "Tier (" + name + ")";
        }
    }

    public static void main(String[] args) {
        
//        Function<String, Tier> mapper = name -> new Tier(name); // OK
        Function<String, Tier> mapper = Tier::new;
        
        Set<Tier> set = Stream.of("Tom", "Jerry", "Rex", "Molly")
                .map(mapper)
                .collect(Collectors.toSet());
        System.out.println("set: " + set);
    }
    
}
