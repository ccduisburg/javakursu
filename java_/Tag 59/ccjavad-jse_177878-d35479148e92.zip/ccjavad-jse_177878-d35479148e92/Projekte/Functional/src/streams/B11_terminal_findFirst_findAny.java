package streams;

import java.util.Optional;
import java.util.stream.Stream;

public class B11_terminal_findFirst_findAny {

    public static void main(String[] args) {
        
        /*
            findFirst
         */
        Optional<Integer> opFirst = Stream.of(-1, 2, -3, 4)
                .peek(System.out::println) // -1
                .findFirst();
        
        if( opFirst.isPresent() ) {
            System.out.println("first: " + opFirst.get());
        }
     
        /*
            findAny        
        */
        Optional<Integer> opAny = Stream.of(-1, 2, -3, 4).findAny();
        opAny.ifPresent(i -> System.out.println("any = " + i));
        
    }
    
}
