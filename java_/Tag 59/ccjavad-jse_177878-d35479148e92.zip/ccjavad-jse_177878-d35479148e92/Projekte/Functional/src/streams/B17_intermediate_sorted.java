package streams;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class B17_intermediate_sorted {
    
    static class Person {
        String vorname, nachname;

        public Person(String vorname, String nachname) {
            this.vorname = vorname;
            this.nachname = nachname;
        }

        public String getNachname() {
            return nachname;
        }

        @Override
        public String toString() {
            return vorname + " " + nachname;
        }
    }

    public static void main(String[] args) {
        
        Comparator<Integer> comparator = Comparator.naturalOrder();
        
        List<Integer> listInt = Stream.of(33, -2, 12, 7000)
                // .sorted() // gibt es auch
                .sorted( comparator )
                .collect( Collectors.toList() );
        System.out.println("listInt: " + listInt);
        
        /*
            
        */
        Person[] arr = {
           new Person("Tom", "Katze"),
           new Person("Jerry", "Maus"),
           new Person("Rex", "Hund"),
        };
        
        List<Person> listPersonen = Stream.of( arr )
                .sorted( Comparator.comparing(Person::getNachname) )
                .collect(Collectors.toList());
        
        listPersonen.forEach(System.out::println);
    }
    
}
