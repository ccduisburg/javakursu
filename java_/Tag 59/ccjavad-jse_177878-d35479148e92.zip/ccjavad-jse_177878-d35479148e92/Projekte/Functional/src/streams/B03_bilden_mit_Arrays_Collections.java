package streams;

import java.util.Arrays;
import java.util.List;

public class B03_bilden_mit_Arrays_Collections {

    public static void main(String[] args) {
        
        /*
            mit der Klasse Arrays
        */
        String[] arr = { "mo", "di", "mi" };
        Arrays.stream(arr).forEach( System.out::println );
        // Arrays.stream("a", "b"); // keine varargs
        
        
        System.out.println("---------------------");
        
        /*
            mit einer Collection
        */
        List<String> list = Arrays.asList("mo", "di", "mi");
        
        list.stream().forEach(System.out::println);
    }
}
