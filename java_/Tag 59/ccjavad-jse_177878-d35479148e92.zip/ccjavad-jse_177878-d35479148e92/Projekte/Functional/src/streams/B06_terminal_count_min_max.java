package streams;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class B06_terminal_count_min_max {

    public static void main(String[] args) {
        
        List<Integer> listInt = Arrays.asList( 44, -3, 55, 13, -101 );
        
        /*
            long count()
        */
        long count = listInt.stream().count();
        System.out.println("count: " + count); // 5
        
        count = listInt.stream().filter(i -> i > 0).count();
        System.out.println("count: " + count); // 3
        
        
        /*
            Optional<T> min(Comparator<? super T> comparator)
        */
        Comparator<Integer> cmp = Comparator.naturalOrder() ;
        Optional<Integer> opMin = listInt.stream().min(cmp);
        
        if(opMin.isPresent()) {
            int x = opMin.get(); // int <= Integer (Autounboxing - mit null kommt zur NullPointerException)
            System.out.println("min = " + x); // -101
        }
        
        /*
            Optional<T> max(Comparator<? super T> comparator)
        */
        Optional<Integer> opMax = listInt.stream().max(cmp);
        
        opMax.ifPresent( System.out::println ); // 55
        
    }
    
}
