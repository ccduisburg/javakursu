package streams;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;

/*
    Statische Methoden aus dem Stream-Interface
*/
public class B02_bilden {
    
    public static void main(String[] args) {
        
        // of mit varargs:
        Stream<Integer> s1 = Stream.of( 1, 2, 3, 4 );
        s1.forEach(System.out::print);
        System.out.println();
        
        //die generate, iterate und concat sind unwahrscheinlich in der Prüfung
        
        // generate:
        Supplier<Integer> s = () -> 1;
        // Stream.generate(s).forEach(System.out::println); // endlos die 1 ausgeben
        
        // iterate:
        Integer seed = 1;
        UnaryOperator<Integer> operator = i -> i+1;
        //Stream.iterate(seed, operator).forEach( System.out::println ); // 1 2 3 ... endlos
        
        
        // concat:
        Stream<Integer> sA = Stream.of(1, 2);
        Stream<Integer> sB = Stream.of(3, 4);
        Stream.concat(sA, sB).forEach(System.out::print);
        
        
        System.out.println();
        
    } // end of main
    
    static void e1() {
        List<String> list1 = Arrays.asList( "a", "b", "c" );
        List<String> list2 = Arrays.asList( "d", "e", "f" );
        List<List<String>> list3 = Arrays.asList(list1, list2);
        
        // Bitte ersetzen Sie die foreach-Schleife mit einer Pipeline
        
        // A
//        for(List<String> e : list3) {
//            System.out.println("size = " + e.size() + ". elements = " + e);
//        }
        // B
        
        Consumer<List<String>> c = e -> System.out.println("size = " + e.size() + ". elements = " + e);
//        list3.stream().forEach(c); // OK
        Stream.of(list1, list2).forEach(c);
    }
}
