package streams;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class B10_terminal_collect_Collector {
    
    static class Tier {
        private String name;
        private String art;

        public Tier(String name, String art) {
            this.name = name;
            this.art = art;
        }

        public String getArt() {
            return art;
        }

        public String getName() {
            return name;
        }

        @Override
        public String toString() {
            return name + " " + art;
        }
    }
    
    private static final Tier[] tiere = {
       new Tier("Tom", "Raubtier"),
       new Tier("Jerry", "Opfer"),
       new Tier("Rex", "Raubtier"),
       new Tier("Molly", "Opfer"),
    };

    
    public static void main(String[] args) {
        
        /*
            Die zweite collect-Methode aus Stream:
                <R, A> R collect(Collector<? super T, A, R> collector);
        */

//        e1();
//        e2();
        e3();
//        e4();

    } // end of main

    
    /*
        Collectors.mapping
    */
    static void e4() {
        
        // vorhanden:
        Collector<String, ?, List<String>> downstream = Collectors.toList();
        
        Function<Tier, String> mapper = t -> t.name;
        
        // benötigt:
        Collector<Tier, ?, List<String>> collector 
                = Collectors.mapping(mapper, downstream);
        
        List<String> tierNamen = Stream.of(tiere).collect(collector);
        System.out.println("tierNamen: " + tierNamen);
    }
    
    /*
        Collectors.groupingBy(Function, Collector)
    */
    static void e3() {
        
        Collector<Tier, ?, List<String>> downstream 
                = Collectors.mapping(Tier::getName, Collectors.toList());
        
        Function<Tier, String> classifier = Tier::getArt;
        
        Collector<Tier,?,Map<String, List<String>>> collector 
                = Collectors.groupingBy(classifier, downstream);
        
        // Ziel ist einer Tierart (String) die Tiernamen (List<String>) zu zuordnen
        Map<String, List<String>> map = Stream.of(tiere).collect(collector);
        
        map.forEach((art, listNamen) -> System.out.println(art + " -> " + listNamen));
    }
    
    
    /*
        Collectors.groupingBy(Function)
    */
    static void e2() {
        
        // Der classifier sagt dem Collector,
        // wie er aus einem Element (hier Tier) einer Pipeline
        // den Key (hier String) ermitteln soll
        Function<Tier, String> classifier = t -> t.getArt();
        
        //Der Collector sammelt alle Elemente (hier Tier) in einer Map.
        // Der Collector kann mehrere Elemente (hier Tier) einem Key (hier String)
        // zuordnen (alle Elemente mit demselben Key kommen in eine List).
        Collector<Tier, ?, Map<String, List<Tier>>> collector 
                = Collectors.groupingBy(classifier);
        
        // collect verwendet den Collector
        Map<String, List<Tier>> map = Stream.of(tiere).collect(collector);
        
        map.forEach( (k, v) -> System.out.println( k + " -> " + v) );
    }
    
    
    /*
        Collectors.toList()
        Collectors.toSet()
    */
    static void e1() {
        String[] arr = { "aa", "bb", "cc" };
        
        Collector<String, ?, List<String>> collector = Collectors.toList();
        List<String> list = Stream.of(arr).collect(collector);
        System.out.println("list: " + list);
        
        Set<String> set = Stream.of(arr).collect( Collectors.toSet() );
        System.out.println("set: " + set);
    }
    
}
