package streams;

import java.util.Arrays;
import java.util.Collection;
import java.util.function.Predicate;

public class B07_terminal_allMatch_anyMatch_noneMatch {

    public static void main(String[] args) {
        
        
        Collection<Integer> numbers = Arrays.asList(1, 2, 3, -7);
        
        /*
            boolean allMatch(Predicate<? super T> predicate)
        */
        boolean allePositiv = numbers.stream().allMatch( x -> x > 0 );
        System.out.println("allePositiv: " + allePositiv);
        
        
        /*
            boolean anyMatch(Predicate<? super T> predicate)
        */
        Predicate<Integer> pTestGerade = x -> x%2==0;
        boolean istEineGerade = numbers.stream().anyMatch(pTestGerade);
        System.out.println("ist eine Zahl gerade: " + istEineGerade);
     
        
        /*
            boolean noneMatch(Predicate<? super T> predicate)
        */
        Predicate<Integer> pTestZero = x -> x == 0;
        boolean noZero = numbers.stream().noneMatch(pTestZero);
        System.out.println("no zero: " + noZero); // true (keine Null gefunden)
        
        // noneMatch nachgebildet:
//        for (Integer number : numbers) {
//            if( pTestZero.test(number) ) {
//                return false;
//            }
//        }
//        return true;
        
    }
    
}
