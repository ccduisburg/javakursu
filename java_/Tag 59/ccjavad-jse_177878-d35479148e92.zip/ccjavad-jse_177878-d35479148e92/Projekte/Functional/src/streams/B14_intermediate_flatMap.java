package streams;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Stream;

public class B14_intermediate_flatMap {

    public static void main(String[] args) {
        
        List< List<Integer> > source = Arrays.asList(
           Arrays.asList(1, 2), // -> stream
           Arrays.asList(3, 4, 5), // -> stream
           Arrays.asList(6, 7) // -> stream
        );
        
//        Function< List<Integer>, Stream<Integer> > mapper = list -> list.stream(); // OK
        Function< List<Integer>, Stream<Integer> > mapper = List::stream;
        
        source.stream()
                .flatMap(mapper) // konkateniert sie Streams, die sie mit dem mapper bekommt
                .forEach(System.out::println);
        
        
        System.out.println("end of main");
    }
    
}
