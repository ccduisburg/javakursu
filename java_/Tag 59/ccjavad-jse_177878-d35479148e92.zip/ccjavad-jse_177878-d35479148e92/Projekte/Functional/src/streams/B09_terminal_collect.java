package streams;

import java.util.Arrays;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

public class B09_terminal_collect {
    
    public static void main(String[] args) {
        
        List<String> list = Arrays.asList("Java", " ", "ist", " ", "toll");
        
        /*
            <R> R collect(Supplier<R> supplier,
                      BiConsumer<R, ? super T> accumulator,
                      BiConsumer<R, R> combiner);
        
            R steht für den Zielcontainer.
            Der supplier liefert den Zielcontainer an die collect.
        
            Wie jedes Element von Typ T (hier String) in dem Container 
            von Typ R (hier StringBuilder) gespeichert wird, wird der
            accumulator definieren.
        
            Bei parallelen Streams:
            Mit dem combiner werden zwei parallel gefülten Container
            zu einem kombiniert
        */
        
        Supplier<StringBuilder> supplier = () -> new StringBuilder(); // T get()
        BiConsumer<StringBuilder, String> accumulator = (sb, s) -> sb.append(s); // void accept(T t, U u)
        BiConsumer<StringBuilder, StringBuilder> combiner = (sb1, sb2) -> sb1.append(sb2);
        
        StringBuilder result = list.stream()
                .collect(supplier, accumulator, combiner);

        System.out.println("result: " + result);
        
        // Dasselbe bitte nochmal.
        // Diesmal aber supplier, accumulator und combiner 
        // mit Methodenreferenzen realisieren
        
        supplier = StringBuilder::new; // T get()
        accumulator = StringBuilder::append; // void accept(T t, U u)
        combiner = StringBuilder::append;
        
        result = list.stream()
                .collect(supplier, accumulator, combiner);
        System.out.println("result: " + result);
    }

}
