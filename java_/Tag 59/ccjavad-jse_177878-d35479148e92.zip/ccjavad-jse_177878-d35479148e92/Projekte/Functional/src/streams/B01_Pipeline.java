package streams;

// Streams:

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

// https://docs.oracle.com/javase/8/docs/api/java/util/stream/package-summary.html


public class B01_Pipeline {

    public static void main(String[] args) {
        
        // 1. Daten-Quelle:
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        
        // 2. Stream für die Daten-Quelle:
        Stream<Integer> s1 = list.stream();
        
        // 3. 0 bis N lazy intermediate operations:
        Stream<Integer> s2 = s1.filter(i -> true);
        Stream<Integer> s3 = s2.peek(System.out::println);
        
        // 4. Nur eine terminal Operation
        long c = s3.count();
        System.out.println("count = " + c);
        
        /*
            Besser (und kompakter) ist 'chained'
        */
        long c2 = list.stream()
                .filter(i -> true)
                .peek(System.out::println)
                .count();
        System.out.println("count2 = " + c2);
    }
    
}
