package streams;

import java.util.stream.Stream;

public class B05_terminal_forEach {

    public static void main(String[] args) {
        
        Stream.of(1, 2, 3).forEach( System.out::println );
        
    }
    
}
