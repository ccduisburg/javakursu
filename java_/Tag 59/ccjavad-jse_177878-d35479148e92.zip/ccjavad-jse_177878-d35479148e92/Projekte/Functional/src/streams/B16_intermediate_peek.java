package streams;

import java.util.stream.Stream;

public class B16_intermediate_peek {

    public static void main(String[] args) {
        
        /*
            peek ist intermediate!
        */
        Stream.of(1, 2, 3)
                .peek(System.out::println); // Achtung! Keine Ausgaben!
        
        
        System.out.println("--------------------");
        
        long count = Stream.of(1, 2, 3)
                .peek(System.out::println)
                .count();
        
        System.out.println("count = " + count);
    }
    
}
