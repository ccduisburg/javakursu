package streams;

import java.util.stream.Stream;

public class B15_intermediate_skip_limit_distinct {

    public static void main(String[] args) {
        
        System.out.println("-------- skip ");
        Stream.of(1, 2, 3, 4, 5, 6, 7, 8)
                .skip(3)
                .forEach(System.out::println);
        
        
        System.out.println("-------- limit ");
        Stream.of(1, 2, 3, 4, 5, 6, 7, 8)
                .limit(3)
                .forEach(System.out::println);

        
        System.out.println("-------- distinct ");
        Stream.of(1, 8, 3, 8, 5, 8, 7, 8)
                .distinct()
                .forEach(System.out::println);
        
        
    }
    
}
