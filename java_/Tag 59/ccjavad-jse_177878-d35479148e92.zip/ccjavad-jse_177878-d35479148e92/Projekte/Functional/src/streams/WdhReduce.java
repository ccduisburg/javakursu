package streams;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.BinaryOperator;

public class WdhReduce {

    public static void main(String[] args) {
        
        List<String> list = Arrays.asList("Java", " ", "ist", " ", "toll");
        
        // Bitte verwenden Sie die 'reduce' um alle Strings aus der Liste
        // zu einem String zu konkatenieren. (Versuchen Sie es)
        
        BinaryOperator<String> accumulator = (s1, s2) -> s1 + s2;
        Optional<String> opResult = list.stream().reduce(accumulator);
        System.out.println("result: " + opResult.get());
        
        //Dasselbe mit einer Method-Reference
        // auf eine Instanzmethode von einem unbestimmten Objekt
        // vom bestimmten Typ.
        
        // String apply(String, String) -> param1.concat(param2)
        opResult = list.stream().reduce( String::concat );
        System.out.println("result: " + opResult.get());
        
        // Diese Aufgabe sollte man NICHT parallel lösen!
    }
    
}
