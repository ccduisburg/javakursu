package streams;

import java.util.Optional;

public class UsingOptional {

//    static String getString() {
//        return null; // komplexe ermittlung von einem String, könnte auch null sein
//    }
    
    static Optional<String> getString() {
        // komplexe ermittlung von einem String, könnte auch null sein:
        String back = null;
        
        return Optional.ofNullable(back);
    }
    
    
    public static void main(String[] args) {
        // String str = getString();
        
        // 
        Optional<String> opStr = getString();
        
        if( !opStr.isPresent() ) {
            //wenn es kein String aus der getString kam,
            // sollte man es nicht versuchen zu holen und damit zu arbeiten
            return;
        }
        
        String s = opStr.get(); // würde eine Exception werfen, 
                                // wenn der String im Optional null ist
                
        System.out.println( s.toLowerCase() );
    }
    
}
