package streams;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;

public class B08_terminal_reduce {
    
    public static void main(String[] args) {
        testReduce1();
        testReduce2();
        testReduce3();
    }
    
    public static void testReduce1() {
        
        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        
        /*
            Optional<T> reduce(BinaryOperator<T> accumulator)
        */
        BinaryOperator<Integer> accumulator = new BinaryOperator<Integer>() {
            @Override
            public Integer apply(Integer i1, Integer i2) {
                return i1 + i2;
            }
        };
        
        Optional<Integer> opSum = list.stream().reduce(accumulator);
        
        /*
            1,  2, 3, 4
            |   |  |  |
            1 + 2  |  |
      =       3    |  |
              |    |  |
              3 +  3  |
                 6    |
                 |    |
                 6 +  4 = 10
              
        */
        
        Integer sum = opSum.get();
        System.out.println( "1. sum = " + sum ); // 10
        
    }
    
    public static void testReduce2() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        
        /*
            T reduce(T identity, BinaryOperator<T> accumulator)
        */
        
        BinaryOperator<Integer> accumulator = (i1, i2) -> i1+i2;
        Integer identity = 0; 
        Integer sum = list.stream().reduce(identity, accumulator);
        System.out.println("2. sum = " + sum);
    }

    public static void testReduce3() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        
        /*
            <U> U reduce(U identity,
                 BiFunction<U, ? super T, U> accumulator,
                 BinaryOperator<U> combiner);
        */
        Integer identity = 0;
        BiFunction<Integer, Integer, Integer> accumulator = (i1, i2) -> i1+i2;
        BinaryOperator<Integer> combiner = (i1, i2) -> {
            System.out.println("i1 = " + i1 + ", i2 = " + i2);
            return i1+i2;
        };
        //unwahrscheinlich in der prüfung:
        Integer sum = list.stream().reduce(identity, accumulator, combiner);
        System.out.println("3. sum = " + sum);
    }
        
}
