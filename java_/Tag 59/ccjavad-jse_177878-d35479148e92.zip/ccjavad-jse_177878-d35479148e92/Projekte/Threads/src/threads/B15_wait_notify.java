package threads;

/*
    wait/notify unwahrscheinlich in der Prüfung
*/

class BigJob {
    static void doJob() {
        try {
            Thread.sleep(2000);
        } catch(InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}

class Hersteller extends Thread {
    private String daten;
    
    public void run() {
        while(true) {
            System.out.println("Hersteller produziert...");
            BigJob.doJob();
            synchronized(this) {
                daten = "Neue Daten vom Hersteller";
                this.notifyAll();
            }
        }
    }
    
    boolean hatDaten() {
        return daten != null;
    }
    String getDaten() {
        String back = daten;
        daten = null;
        return back;
    }
}

class Abnehmer extends Thread {
    private Hersteller hersteller;

    public Abnehmer(Hersteller hersteller) {
        this.hersteller = hersteller;
    }
    
    public void run() {
        while(true) {
            synchronized(hersteller) {
                System.out.println("Abnehmer fragt nach Daten");
                if(hersteller.hatDaten()) {
                    hersteller.getDaten();
                    System.out.println("Abnehmer verbraucht die Daten");
                } else {
                    System.out.println("Abnehmer hat keine Daten gefunden");

                    try {
                        hersteller.wait(); // wait gibt den Monitor frei
                    } catch(InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }
    }
}

public class B15_wait_notify {

    public static void main(String[] args) {
        
        Hersteller hersteller = new Hersteller();
        hersteller.start();
        
        Abnehmer a1 = new Abnehmer(hersteller);
        a1.start();
        
    }
    
}
