package threads;

/*
        Race Condition ohne Synchronisieren:

                    count = 0

        count++;                    count++;

        count = count + 1           count = count + 1
        
        1: cpuA = count (0)         1: cpuB = count (0)
        2: cpuA + 1     (1)         2: cpuB + 1     (1)
        3: count = cpuA (1)
                                    3: count = 1


        Synchronisiert:

                            monitor 

        synchronized( monitor ) { // Thread links hat den Lock auf den Monitor.
            count++; //           // Thread rechts kann den Block nicht betreten
        }

*/

public class B10_synchronized {
    
    static int count;

    static Runnable incrementTask = () -> {
        for (int i = 0; i < 1_000_000; i++) {
            synchronized(B10_synchronized.class) { // Monitor hier: das Klassenobjekt
                count++;
            }
        }
    };

    public static void main(String[] args) throws InterruptedException {
      
        Thread t1 = new Thread(incrementTask);
        Thread t2 = new Thread(incrementTask);
        
        t1.start();
        t2.start();
        
        t1.join();
        t2.join();
        
        System.out.println("count: " + count);
    }
    
}
