package threads;

class MyRunnable implements Runnable {

    @Override
    public void run() {
        System.out.println("run");
    }
    
}

public class B03_MyRunnable {
    public static void main(String[] args) {
        
        Runnable target = new MyRunnable();
        Thread th = new Thread( target );
        th.start();
        
        /*
            Die run der Klasse Thread:
        
            public void run() {
                if (target != null) {
                    target.run();       // die run der Klasse MyRunnable
                }
            }
        */
        
        System.out.println("main");
    }
}
