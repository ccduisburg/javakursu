package threads;

/*
                    count = 0

        Inc:                        Dec:
        count++;                    count--;

        count = count + 1           count = count - 1
        
        1: cpuA = count (0)         1: cpuB = count (0)
        2: cpuA + 1     (1)         2: cpuB - 1     (-1)
        3: count = cpuA (1)
                                    3: count = -1
*/

class MyNumber {
    volatile static int count;
    static final int ITERATIONS = 1_000_000;
}

class Inc extends Thread { // 1 Mio. mal count inkrementieren (in einer Schleife)
    @Override
    public void run() {
        for (int i = 0; i < MyNumber.ITERATIONS; i++) {
            MyNumber.count++;
        }
    }
}

class Dec extends Thread { // 1 Mio. mal count dekrementieren (in einer Schleife)
    @Override
    public void run() {
        for (int i = 0; i < MyNumber.ITERATIONS; i++) {
            MyNumber.count--;
        }
    }
}

public class B09_Race_Condition {

    public static void main(String[] args) throws InterruptedException {
        
        Thread t1 = new Inc();
        Thread t2 = new Dec();
        
        // bitte die beiden Threads starten.
        t1.start();
        t2.start();
        
        // dann abwarten bis sie fertig sind.
        t1.join();
        t2.join();
        
        // dann count ausgeben (in der main)
        System.out.println("count: " + MyNumber.count);
    }
    
}
