package threads;

/*
    run-Methode der Kklasse Thread überschreiben.
*/

class Settings {
    public static final int ITERATIONS = 10_000;
}

class MyThread extends Thread {
    @Override
    public void run() {
        for (int i = 0; i < Settings.ITERATIONS; i++) {
            System.out.println("in der run");
        }
    }
}

public class B02_MyThread {

    public static void main(String[] args) {
        
        Thread th = new MyThread(); // als NEW anmelden
        th.start(); // als RUNNABLE anmelden
        
        
        for (int i = 0; i < Settings.ITERATIONS; i++) {
            System.out.println("main");
        }
        
    }
    
}
