package threads;

class CountHolder {
    volatile static int count;
}

class Increment extends Thread {
    @Override
    public void run() {
        for (int i = 0; i < 1_000_000; i++) {
            CountHolder.count++;
        }
        System.out.println("end of run");
    }
}

public class B08_join {

    public static void main(String[] args) throws InterruptedException {
        
        Thread th = new Increment();
        th.start();

        // join hält den main-Thread an,
        // solange der Thread th nicht DEAD ist.
        System.out.println("main ruft join auf");
        th.join();
        
        System.out.println("count: " + CountHolder.count);
    }
    
}
