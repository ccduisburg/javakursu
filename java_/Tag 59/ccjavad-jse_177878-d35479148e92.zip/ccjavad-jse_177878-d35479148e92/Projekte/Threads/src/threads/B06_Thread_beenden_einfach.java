package threads;

class ThreadToStop extends Thread {
    /*
        volatile sollte man einsetzen,
        wenn mehrere Threads UNSYNCHRONISIERT
        dieselbe Variable lesen/schreiben.
    */
    volatile boolean beendet = false; // volatile nicht in der Prüfung
    
    @Override
    public void run() {
        while(!beendet) {
            System.out.println("Thread " + getId());
            try{ Thread.sleep(500); } catch(InterruptedException e) { e.printStackTrace(); }
        }
    }
}

public class B06_Thread_beenden_einfach {

    public static void main(String[] args) {
        
        ThreadToStop th = new ThreadToStop();
        th.start();
        
        try{ Thread.sleep(5000); } catch(InterruptedException e) { e.printStackTrace(); }
        //Der main-Thread soll den Thread th beenden

        System.out.println("main beendet den extra-Thread");
        th.beendet = true;
        
    }
    
}
