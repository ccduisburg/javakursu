package threads;

class StaticLogger {
    private static StringBuilder sb = new StringBuilder();
//    private static StringBuffer sb = new StringBuffer();
    
//    public static void log(String caller, String message) {
//        synchronized(StaticLogger.class) {
//            sb.append(caller);
//            sb.append(" - ");
//            sb.append(message);
//            sb.append("\n");
//        }
//    }
    
    // static synchronized Methoden verwenden das Klassenobjekt 
    // ihrer Klasse als Monitor
    public synchronized static void log(String caller, String message) {
        sb.append(caller);
        sb.append(" - ");
        sb.append(message);
        sb.append("\n");
    }
    
    public static String getLog() {
        return sb.toString();
    }
}

public class B11_synchronized_static_methoden {
    
    public static void main(String[] args) throws InterruptedException {
       Runnable task = () -> {
            for (int i = 0; i < 100; i++) {
                Thread th = Thread.currentThread();
                StaticLogger.log(th.getName(), "Nachricht vom Thread " + th.getId());
            }
        };
        
        Thread t1 = new Thread(task);
        Thread t2 = new Thread(task);
        
        t1.start();
        t2.start();
        
        t1.join();
        t2.join();
        
        System.out.println("static log: ");
        System.out.println(StaticLogger.getLog());
        System.out.println("end of main");
    }
}
