package threads;

public class WdhThreadStarten {

    public static void main(String[] args) {
        
        Runnable target = () -> {
            System.out.println("Katze");
        };
        
        new Thread(target) {
            public void run() {
                System.out.println("Hund");
            }
        }.start();
        
        // Ausgabe: Hund
    }
    
}
