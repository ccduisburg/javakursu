package threads;

import java.util.Hashtable;
import java.util.Vector;

public class B13_synchronized_Standardbibliothek {

    public static void main(String[] args) {
        
        // PrintStream
        System.out.println("abc");
        
        StringBuffer sb = new StringBuffer();
        sb.append("abc");
        
        Vector<Integer> v = new Vector<>();
        v.add(12);
        
        Hashtable<Integer, String> ht = new Hashtable<>();
        ht.put(1, "Mo");
    }
    
}
