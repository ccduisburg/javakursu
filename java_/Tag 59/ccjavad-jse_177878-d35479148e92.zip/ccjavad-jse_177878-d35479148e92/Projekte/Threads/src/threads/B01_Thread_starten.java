package threads;

public class B01_Thread_starten {

    /*
        Der main-Thread wird mit dem Konsolenbefehl gestartet
            > java MyClassWithMain
    */
    public static void main(String[] args) {
        
        // 1. Thread-Objekt erzeugen (beim Scheduler als NEW registrieren):
        Thread th = new Thread();
        
        // 2. Als RUNNABLE bei dem Scheduler anmelden:
        th.start();
        // th.start(); IllegalThreadStateException (Thread ist nicht NEW)
        
        // ab der Zeile 15:
        //
        // zwei gleichberechtigte Threads.
        //
        //  - main-Thread mit der Zeile 22 
        //  - Exatra-Thread mit seiner run-Methode:
        //      public void run() {
        //          if (target != null) {
        //              target.run();
        //          }
        //      }
        
        System.out.println("in der main");
        /*
            public void println(String x) {
                synchronized (this) {
                    print(x);
                    newLine();
                }
            }
        */
    }
}
