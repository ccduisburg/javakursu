package threads;

public class B04_Thread_SimpleAPI {

    public static void main(String[] args) {
        
        /*
            Konstruktoren
        */
        Thread t1 = new Thread();
        Thread t2 = new Thread("der neue Name");
        
        Runnable target = () -> {};
        Thread t3 = new Thread(target);
        
        
        /*
            get/setName
        */
        System.out.println("t1.getName(): " + t1.getName());
        System.out.println("t2.getName(): " + t2.getName());
        t2.setName("noch besserer Name");
        System.out.println("t2.getName(): " + t2.getName());
        
        /*
            getId
        */
        System.out.println("t1.getId(): " + t1.getId());
        
        
        /*
            get/setPriority (unwahrscheinlich)
        */
        int priority = t1.getPriority();
        System.out.println("t1.getPriority(): " + t1.getPriority());
        
        t1.setPriority(Thread.MAX_PRIORITY);
        System.out.println("t1.getPriority(): " + t1.getPriority());
        
        
        /*
        static!!!
        static!!!
        static!!!
         */
        
        System.out.println("------------------------------------");
        Thread currentThread = Thread.currentThread(); // akt. Thread ermitteln
        System.out.println("currentThread: " + currentThread);
        
        Thread.yield(); // akt. Thread versucht die CPU-Zeit abzugeben
        
    }
    
}
