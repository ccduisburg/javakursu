package threads;

class ThreadToInterrupt extends Thread {

    @Override
    public void run() {
        
         while(true) {
            System.out.println("Thread " + getId());
            try{ 
                //falls der Thread auf 'interrupted' gesetzt wird,
                //(vor oder währen des sleep-Aufrufes)
                //wirft die sleep InterruptedException.
                //Dabei wird der Zustand 'interrupted' zurück gesetzt.
                Thread.sleep(100_000); 
            } catch(InterruptedException e) { 
                System.out.println("Thread " + getId() + " wurde interrupted");
                break; // den thread auf beenden programmiert
            }
        }
    }
}

public class B07_Thread_beenden_interrupt {

    public static void main(String[] args) {

        Thread th = new ThreadToInterrupt();
        th.start();
        
        try{ Thread.sleep(5000); } catch(InterruptedException e) { e.printStackTrace(); }
        //Der main-Thread soll den Thread th beenden

        System.out.println("main beendet (interrupted) den extra-Thread");
        th.interrupt(); // th auf 'interrupted' setzen
        
    }
    
}
