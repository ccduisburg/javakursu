package threads;

class MyLogger {
    private StringBuilder sb = new StringBuilder();
    
//    public void log(String caller, String message) {
//        synchronized(this) {
//            sb.append(caller);
//            sb.append(" - ");
//            sb.append(message);
//            sb.append("\n");
//        }
//    }
    
    // hier als Monitor: this
    public synchronized void log(String caller, String message) {
        sb.append(caller);
        sb.append(" - ");
        sb.append(message);
        sb.append("\n");
    }
    
    public String getLog() {
        return sb.toString();
    }
}


public class B12_synchronized_instance_Methoden {

    public static void main(String[] args) throws InterruptedException {
        
        MyLogger logger = new MyLogger();
        
        Runnable target = new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 100; i++) {
                    Thread th = Thread.currentThread();
                    logger.log(th.getName(), "Nachricht von dem Thread " + th.getId());
                }
            }
        };
        
        Thread t1 = new Thread(target);
        Thread t2 = new Thread(target);
        
        t1.start();
        t2.start();
        
        t1.join();
        t2.join();
        
        
        MyLogger loggerB = new MyLogger();
        new Thread() {
            @Override
            public void run() {
                loggerB.log("Tom", "Hallo aus Tom-Thread");
            }
        }.start();
        
        System.out.println("*** logger:");
        System.out.println(logger.getLog());
    }
    
}
