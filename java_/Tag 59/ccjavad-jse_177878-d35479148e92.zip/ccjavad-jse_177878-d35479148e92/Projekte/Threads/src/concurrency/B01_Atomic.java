package concurrency;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntBinaryOperator;

public class B01_Atomic {
    
    // static int count;
    static AtomicInteger count = new AtomicInteger();
    
    public static void main(String[] args) throws InterruptedException {
        
        Runnable taskIncrement = () -> {
            for (int i = 0; i < 1_000_000; i++) {
                count.incrementAndGet();
            }
        };

        Thread t1 = new Thread(taskIncrement);
        Thread t2 = new Thread(taskIncrement);
        
        t1.start();
        t2.start();
        
        t1.join();
        t2.join();
        
        System.out.println("count: " + count.get());
        
        // ---------------------------------
        methodenAtomicInteger();
    }
    
    static void methodenAtomicInteger() {
        System.out.println(" -- API -- ");
        AtomicInteger var = new AtomicInteger(20);
        
        System.out.println("1. get: " + var.get());
        
        int x = var.incrementAndGet();
        x = var.getAndIncrement();
        
        System.out.println("2. get: " + var.get());
        
        IntBinaryOperator op = new IntBinaryOperator() {
            @Override
            public int applyAsInt(int currentValue, int givenValue) {
                return currentValue * givenValue;
            }
        };
        x = var.accumulateAndGet(3, op);
        System.out.println("3. x = " + x);
        System.out.println("3. get: " + var.get());
        
    }

}
