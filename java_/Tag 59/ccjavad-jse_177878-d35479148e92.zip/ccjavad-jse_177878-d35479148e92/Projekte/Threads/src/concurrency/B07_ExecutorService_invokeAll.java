package concurrency;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class B07_ExecutorService_invokeAll {

    public static void main(String[] args) throws InterruptedException {
        
        
        ExecutorService es = Executors.newCachedThreadPool();
        
        Collection<Callable<String>> tasks = Arrays.asList(
                () -> "a",
                () -> "b",
                () -> "c"
        );
        
        // invokeAll (und invokeAny) ist synchron (wie join())
        List<Future<String>> futures = es.invokeAll(tasks);
        
        // futures.stream().forEach(f -> System.out.println(f.get()));
        
        for (Future<String> f : futures) {
            try {
                System.out.println(f.get());
            } catch(InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }
        
        es.shutdown();
        
    }
    
}
