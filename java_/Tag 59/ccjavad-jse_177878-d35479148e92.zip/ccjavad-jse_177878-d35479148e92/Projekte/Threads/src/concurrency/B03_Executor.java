package concurrency;

import java.util.concurrent.Executor;

public class B03_Executor {

    public static void main(String[] args) {
        
        Executor executor = null;
        
        Runnable command = () -> System.out.println("in der run");
        
        executor.execute(command);
        
    }
    
}
