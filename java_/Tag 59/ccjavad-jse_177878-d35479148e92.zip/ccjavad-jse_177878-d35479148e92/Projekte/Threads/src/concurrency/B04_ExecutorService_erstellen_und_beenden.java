package concurrency;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class B04_ExecutorService_erstellen_und_beenden {

    public static void main(String[] args) {
        
        ExecutorService es = Executors.newSingleThreadExecutor();
        
        Runnable command = () -> System.out.println("a");
        es.execute(command);
        
        es.execute(() -> System.out.println("b"));
        es.execute(() -> System.out.println("c"));
        es.execute(() -> System.out.println("d"));
        
        es.shutdown(); // ohne shutdown läuft VM weiter
        // es.shutdownNow(); // versucht die laufenden Tasks mit interrupt zu beenden
        
        System.out.println("end of main");
    }
    
}
