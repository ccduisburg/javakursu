package concurrency;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;

    /*
        Aufgabe. Setzen Sie bitte einen ExecutorService ein
        um ein Runnable-Task auszuführen, in dem 
        ein funktionaler Stream 10 zufällige double-Werte 
        generiert und ausgibt.
    */
public class B05_ExecutorService_execute {

    public static void main(String[] args) {
        
        ExecutorService es = Executors.newSingleThreadExecutor();
        
        Runnable task = () -> {
            Stream.generate(Math::random)
                    .limit(10)
                    .forEach(System.out::println);
        };
        
        es.execute(task);
        
        es.shutdown();
    }
}
