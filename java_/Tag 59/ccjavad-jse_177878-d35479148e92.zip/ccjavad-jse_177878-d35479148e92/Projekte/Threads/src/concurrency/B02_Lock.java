package concurrency;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/*
    unwahrscheinlich in der Prüfung
*/
public class B02_Lock {

    public static void main(String[] args) {
        
        Object monitor = "hallo";
        synchronized(monitor) {
            // ...
        }
        
        //Ersatz mit Lock:
        Lock lock = new ReentrantLock();
        lock.lock();
        // ...
        lock.unlock();
        
        // auch mit Lock möglich:
        boolean locked = lock.tryLock();
        if( locked ) {
            // ...
            lock.unlock();
        }
        
    }
}
