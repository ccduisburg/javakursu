package concurrency;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class B09_CyclicBarrier {

    public static void main(String[] args) {
        
        Runnable barrierAction = () -> {
            System.out.println("Barriere durchbrochen!");  
        };
        
        /*
            CyclicBarrier lässt sich wiederverwenden
        */
        CyclicBarrier barrier = new CyclicBarrier(3, barrierAction);

        for(int i=0; i<6; i++) { 
            
            new Thread() {
                public void run() {
                    System.out.println("Thread " + getId() + " erreicht die Barriere");
                    try {
                        barrier.await();
                    } catch(InterruptedException | BrokenBarrierException e) {
                        e.printStackTrace();
                    }

                    System.out.println("Thread " + getId() + " läuft weiter");
                }
            }.start();
            
        } // end for
        
    } // end of main
}

// Bitte verwenden Sie CyclicBarrier um zwei Threads zu sammeln, 
// die dieselbe count-Variable inkrementieren.
// Die Barrier Action soll das Ergebnis (count) ausgeben
