package concurrency;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

public class B06_ExecutorService_submit {

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        
        ExecutorService es = Executors.newCachedThreadPool();

        /*
             submit(Callable) :  Future 
        */
        System.out.println("-------------- submit(Callable)");
        Callable<Integer> task1 = new Callable<Integer>() {
            public Integer call() throws Exception {
                return 1;
            }
        };
        
        // submit ist asynchron
        Future<Integer> future1 = es.submit(task1); 
        
        // get ist synchron
        Integer result1 = future1.get(); // Ersatz für join()
        System.out.println("result 1: " + result1);
        
        
        /*
            submit(Runnable) : Future<?>
        */
        System.out.println("-------------- submit(Runnable)");
        
        AtomicInteger result2 = new AtomicInteger();
        
        Runnable task2 = () -> {
            result2.set(2);
        };
        
        Future<?> future2 = es.submit(task2);
        System.out.println("future2.get(): " + future2.get()); // null
        System.out.println("result 2: " + result2.get());
        

        /*
            submit(Runnable, T) : Future<T>
        */
        System.out.println("-------------- submit(Runnable, T)");
        
        AtomicInteger resultToReturn3 = new AtomicInteger();
        Runnable task3 = () -> {
            resultToReturn3.set(3);
        };
        
        Future<AtomicInteger> future3 = es.submit(task3, resultToReturn3);
        AtomicInteger result3 = future3.get();
        System.out.println("result 3: " + result3.get());
        
        es.shutdown();
        
    }
    
}
