package concurrency;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.RecursiveTask;

public class B10_Fork_Join {

    public static void main(String[] args) {
        
        /*
            RecursiveAction
        */
        RecursiveAction action = new RecursiveAction() {
            @Override
            protected void compute() {
                System.out.println("Action / compute");
            }
        };
        
        ForkJoinPool poolA = new ForkJoinPool();
        Void nichtsInteressantes = poolA.invoke(action);
        System.out.println("nichtsInteressantes: " + nichtsInteressantes);
        
        
        /*
            RecursiveTask
        */
        RecursiveTask<Integer> task = new RecursiveTask<Integer>() {
            @Override
            protected Integer compute() {
                System.out.println("Task / compute");
                return -1;
            }
        };
        
        ForkJoinPool poolB = new ForkJoinPool();
        Integer result = poolB.invoke(task);
        System.out.println("result: " + result);
        
    }
    
}
