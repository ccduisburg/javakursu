package concurrency;

import java.util.Arrays;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.atomic.AtomicInteger;

public class B11_Fork_Join_RecursiveAction {

//    static AtomicInteger max = new AtomicInteger();
    
    static final int MAX_VALUES_NUMBER = 3;
    
    static class ActionFindMax extends RecursiveAction {
        private int from, to;        
        private int[] arr;

        public ActionFindMax(int[] arr, int from, int to) {
            this.from = from;
            this.to = to;
            this.arr = arr;
        }
        
        @Override
        protected void compute() {
            
            if(to - from <= MAX_VALUES_NUMBER) {
                int max = Arrays.stream(arr).max().getAsInt();
                System.out.printf("Max = %d. Gefunden im dem Teilarray: %d .. %d %n", max, to, from);
            } else {
                System.out.println("Array teilen und an neue rekursive Actions die Teile weitergeben");
                int middle = (to - from) / 2 + from;

                ActionFindMax leftAction = new ActionFindMax(arr, from, middle);
                ActionFindMax rightAction = new ActionFindMax(arr, middle, to);
                
//                leftAction.fork(); // asynchron
//                rightAction.compute(); // synchron
//                leftAction.join(); //synchron

                invokeAll(leftAction, rightAction);
            }
        }
    }
    
    public static void main(String[] args) {
        
        int[] arr = { 1, -3, 7, -5, 9, - 7 };
        
        ForkJoinPool pool = new ForkJoinPool();
        pool.invoke(new ActionFindMax(arr, 0, arr.length));
        
    }
    
}
