package aufgaben;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class EnglishWords {

    public static List<String> loadFromZipResource() {
        
        List<String> list = new LinkedList<>();
        
        String resourcePath = "/aufgaben/english_words_lowercase.zip";
        
        try {
            InputStream is = EnglishWords.class.getResourceAsStream(resourcePath);

            ZipInputStream zis = new ZipInputStream(is);
            ZipEntry fileEntry = zis.getNextEntry();
            
            InputStreamReader isr = new InputStreamReader(zis);

            try( BufferedReader in = new BufferedReader(isr) ) {

                String line;
                while( (line = in.readLine()) != null ) {
                    list.add(line);
                }
            }
        
        } catch(IOException e) {
            throw new RuntimeException(e);
        }
        
        list.remove(0); // Quelle
        return list;
    }
    
    
    public static void main(String[] args) {
        
        List<String> words = loadFromZipResource();
        System.out.println(words.size());
        
    }
}
