package aufgaben.concurrency;

import aufgaben.EnglishWords;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

public class AufgabeExecutorService {

    static List<String> words = EnglishWords.loadFromZipResource();
//    static ExecutorService service = Executors.newSingleThreadExecutor();
//    static ExecutorService service = Executors.newCachedThreadPool();
    static ExecutorService service = Executors.newFixedThreadPool(4);

    public static void main(String[] args) throws ExecutionException, InterruptedException{
        
        System.out.println("Liste geladen. size: " + words.size());
        
        long start = System.currentTimeMillis();

        List<Future<?>> listFutures = new ArrayList<>();
        for (char i = 'a'; i <= 'z'; i++) {
//            Future<?> f = countWithRunnable(String.valueOf(i));
            Future<?> f = countWithCallable(String.valueOf(i));
            listFutures.add(f);
        }
        
        for (Future<?> f : listFutures) {
            f.get();
        }
        
        long end = System.currentTimeMillis();
        long diff = end - start;
        System.out.println("Dauer: " + diff + " Millis");
        
        service.shutdown();
    } // end of main
    
    static Future<Integer> countWithCallable(String textToFind) {
        Callable<Integer> command = () -> countWithPipeline(textToFind);
        return service.submit(command);
    }
    
    static Future<AtomicInteger> countWithRunnable(String textToFind) {
        AtomicInteger count = new AtomicInteger();
        Runnable command = () -> {
            int c = countWithPipeline(textToFind);
            count.set(c);
        };
        
        return service.submit(command, count);
    }
    
    static int countWithPipeline(String textToFind) {
        return (int)words.stream()
                .filter(s -> s.contains(textToFind))
                .count();
    }
    
    static int countWithForeach(String textToFind) {
        int count = 0;
        for (String word : words) {
            if(word.contains(textToFind)) {
                count++;
            }
        }
        return count;
    }
    
}
