package aufgaben.threads;

public class AufgabeSleep {

    static class MyThread extends Thread {
        @Override
        public void run() {
            
            while(true) {
                try {
                    System.out.println(getName() + " " + getId());
                    sleep(1000);
                } catch(InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    public static void main(String[] args) {
        
        // Bitte starten Sie einen endlosen extra-Thread, 
        // der ca. jede Sekunde seine ID und seinen Namen auf 
        // der Konsole ausgibt. Der endlose Thread soll mit 
        // einer Klasse realisiert werden, die von der Klasse `Thread` erbt.
        new MyThread().start();
        
        // Bitte starten Sie einen endlosen extra-Thread, 
        // der ca. jede Sekunde seine ID und seinen Namen auf der 
        // Konsole ausgibt. Für die Realisierung implementieren Sie 
        // bitte das Interface `Runnable`
     
        Runnable target = () -> {
            while(true) {
                Thread th = Thread.currentThread();
                System.out.println(th.getName() + " " + th.getId());
                try{
                    Thread.sleep(1000);
                } catch(InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        
        new Thread(target).start();
    }
    
}
