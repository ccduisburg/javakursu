package aufgaben.concurrency;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

class CountHolder {
    static AtomicInteger count = new AtomicInteger();
}

public class AufgabeCyclicBarrier {
    public static void main(String[] args) {
        
                
        CyclicBarrier barrier = new CyclicBarrier(2, () -> {
            System.out.println("count = " + CountHolder.count);
        });
        
        ExecutorService es = Executors.newFixedThreadPool(2);
        
        Runnable command = () -> {
            for (int i = 0; i < 1_000_000; i++) {
                CountHolder.count.incrementAndGet();
            }
            try {
                barrier.await();
            } catch(InterruptedException | BrokenBarrierException e) {
                e.printStackTrace();
            }
        };
        
        es.execute(command);
        es.execute(command);
        
        es.shutdown();
        
        
    }
}
