package aufgaben;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileUtils {
    
    public static class TargetFileExistsException extends RuntimeException {
        public TargetFileExistsException(String message) {
            super(message);
        }
    }
    
    /**
     * 
     * @param sourceFileName
     * @param targetFileName
     * @throws aufgaben.FileUtils.TargetFileExistsException 
     */
    public static void copyTextFile(String sourceFileName, String targetFileName) 
            throws TargetFileExistsException, IOException {

        Path targetFile = Paths.get(targetFileName);
        
        if( Files.exists(targetFile, LinkOption.NOFOLLOW_LINKS) ) {
            throw new TargetFileExistsException("Target file: " + targetFileName);
        }

        try( BufferedReader in = new BufferedReader(new FileReader(sourceFileName));
                BufferedWriter out = new BufferedWriter(new FileWriter(targetFileName))) {
            
            String line;
            while( (line = in.readLine()) != null ) {
                out.write(line);
                out.newLine();
            }
        }
        
    }
}
