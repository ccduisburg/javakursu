package aufgaben;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class AufgabeSaveLoadArray {

    public static void main(String[] args) throws IOException {
        int len = new java.util.Random().nextInt(100) + 1;
        int[] arr1 = ArrayUtils.createRandomArray(len, -30, 30);
        
        System.out.println( "arr1: " + Arrays.toString(arr1) );
        
        saveArray(arr1, "array.txt");
        
        int[] arr2 = loadArray("array.txt");
        
        System.out.println( "arr2: " + Arrays.toString(arr2) );
    }
    
    public static int[] loadArray(String fileName) throws IOException {
        int len = countRows(fileName);
        
        int[] arr = new int[len];
        
        try(BufferedReader in = new BufferedReader(new FileReader(fileName))) {
            String line;
            int index = 0;
            while( (line = in.readLine()) != null ) {
                int value = Integer.valueOf(line);
                arr[index++] = value;
            }
        }
        
        return arr;
    }
    
    private static int countRows(String fileName) throws IOException {
        try( BufferedReader in = new BufferedReader(new FileReader(fileName)) ) {
            int count = 0;
            
            while( in.readLine() !=  null ) {
                count++;
            }
            
            return count;
        }
    }

    public static void saveArray(int[] arr, String fileName) throws IOException {
        try(BufferedWriter out = new BufferedWriter(new FileWriter(fileName))) {
            for (int value : arr) {
                out.write( String.valueOf(value) );
                out.newLine();
            }
        }
    }
}
