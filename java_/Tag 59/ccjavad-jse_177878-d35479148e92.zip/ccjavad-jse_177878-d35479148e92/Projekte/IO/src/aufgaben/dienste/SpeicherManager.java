package aufgaben.dienste;

import java.io.Serializable;

public class SpeicherManager extends Dienst implements Serializable {

    private int size;
    private Defragmentierung defrag;

    public SpeicherManager(int size, Defragmentierung defrag) {
        super("Speicher-Manager");
        this.size = size;
        this.defrag = defrag;
    }

    public String toString() {
        return "Manager. Size: " + size + ". Defrag-Dienst: " + defrag;
    }

}
