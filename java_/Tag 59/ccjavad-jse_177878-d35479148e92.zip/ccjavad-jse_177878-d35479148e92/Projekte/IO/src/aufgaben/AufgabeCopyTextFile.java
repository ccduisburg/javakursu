package aufgaben;

import java.io.IOException;

public class AufgabeCopyTextFile {
    public static void main(String[] args) throws IOException {
        
        FileUtils.copyTextFile("autos.txt", "autos.aufgabe.copy.txt");
        
    }
}
