package aufgaben.dienste;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Test {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        
        SpeicherManager sManager 
                = new SpeicherManager(2000, new Defragmentierung (3000, "C:\\"));

        String fileName = "sManager.bin"; 

        try(ObjectOutputStream oos = 
                new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(sManager);
        }
        
        System.out.println("Serialisiert:");
        System.out.println(sManager);
        
        
        try(ObjectInputStream ois 
                = new ObjectInputStream(new FileInputStream(fileName))) {
            SpeicherManager sManager2 = (SpeicherManager)ois.readObject();
            System.out.println("Deserialisiert:");
            System.out.println(sManager2);
        }
    }
}
