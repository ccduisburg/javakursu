package aufgaben.dienste;


public class Dienst {
    private String name;

    /*
        Muss existieren, wenn Diens nicht Serialisable sein darf,
        aber Objekte vom abgeleiteten Typ deserialisiert werden müssen
    */
    public Dienst() {
    }

    public Dienst(String name) {
        this.name = name;
    }
}
