package aufgaben;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class AufgabeDateienErstellen {

    public static void main(String[] args) throws IOException {
        String root = "myfiles/textfiles";
	createFiles(root, "file", "txt", 30);
        
        moveFiles(root, "myfiles/newdir", "txt");
        
        deleteFiles("myfiles/newdir", "txt");
        
        System.out.println("end of main");
    }
    
    static void deleteFiles(String rootName, String extension) throws IOException {
        Path root = Paths.get(rootName);
        
        // filter würde(n) forEach einfacher gestalten lassen
        Files.list(root).forEach(p -> {
            if(Files.isRegularFile(p) && hasExtension(p, extension)) {
                try {
                    Files.delete(p);
                } catch(IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }
 
    static void moveFiles(String sourceRootName, String targetRootName, String extension) 
        throws IOException {
        
        Path sourceRoot = Paths.get(sourceRootName);
        Path targetRoot = Paths.get(targetRootName);
        Files.createDirectories(targetRoot);
        
        // Stream<Path> entries = Files.list(sourceRoot);

        // filter würde(n) forEach einfacher gestalten lassen
        Files.list(sourceRoot).forEach( p -> {
        
            if( Files.isRegularFile(p) && hasExtension(p, extension) ) {
                Path targetFile = targetRoot.resolve( p.getFileName() );
                try {
                    Files.move(p, targetFile, StandardCopyOption.REPLACE_EXISTING);
                } catch(IOException e) {
                    throw new RuntimeException(e);
                }
            }
        } );
    }
    
    private static boolean hasExtension(Path file, String extension) {
        return file.toString().endsWith("." + extension);
    }
    
    static void createFiles(String rootName, String prefix, String extension, int count) 
            throws IOException {
        
        Path root = Paths.get(rootName);
        Files.createDirectories(root);
        
        for (int i = 1; i <= count; i++) {
            String fileName = String.format("%s%03d.%s", prefix, i, extension);
            Path file = Paths.get(fileName);
            
            file = root.resolve(file); // file in root
            
            if(!Files.exists(file)) {
                Files.createFile(file);
            }
        }
    }
}
