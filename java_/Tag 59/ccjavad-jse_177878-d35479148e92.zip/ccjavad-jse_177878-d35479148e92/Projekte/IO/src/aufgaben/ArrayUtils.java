package aufgaben;

import java.util.Random;

public class ArrayUtils {

    /**
     * 
     * @param len
     * @param min (inclusive)
     * @param max (inclusive)
     * @return 
     */
    public static int[] createRandomArray(int len, int min, int max) {
        
        int[] arr = new int[len];
        
        Random r = new Random();

        // z.B.
        // min = 2
        // max = 5
        // nextInt(5 - 2 + 1) -> nextInt(4) -> 0 | 1 | 2 | 3
        // nextInt(4) + 2       -> 2 | 3 | 4 | 5
        
        for (int i = 0; i < len; i++) {
            arr[i] = r.nextInt(max - min + 1) + min;
        }
        
        return arr;
    }
    
}
