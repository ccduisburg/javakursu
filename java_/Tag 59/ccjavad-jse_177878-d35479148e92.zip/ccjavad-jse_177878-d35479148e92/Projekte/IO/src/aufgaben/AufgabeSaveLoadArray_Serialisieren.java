package aufgaben;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;

public class AufgabeSaveLoadArray_Serialisieren {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        int len = new java.util.Random().nextInt(100) + 1;
        int[] arr1 = ArrayUtils.createRandomArray(len, -30, 30);
        
         System.out.println( "arr1: " + Arrays.toString(arr1) );
        
        saveArray(arr1, "array.txt");
        
        int[] arr2 = loadArray("array.txt");
        
        System.out.println( "arr2: " + Arrays.toString(arr2) );
    }

    public static void saveArray(int[] arr, String fileName) throws IOException {
        try( ObjectOutputStream oos 
                = new ObjectOutputStream(new FileOutputStream(fileName)) ) {
            oos.writeObject(arr);
        }
    }
    
    public static int[] loadArray(String fileName) throws IOException, ClassNotFoundException {
        try( ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName)) ) {
            return (int[])ois.readObject();
        }
    }
    
    
}
