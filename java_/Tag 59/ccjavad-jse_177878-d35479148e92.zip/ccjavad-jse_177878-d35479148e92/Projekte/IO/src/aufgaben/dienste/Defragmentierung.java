package aufgaben.dienste;

import java.io.Serializable;

public class Defragmentierung extends Dienst implements Serializable {
    private int zeitabstand;
    private String laufwerk;

    public Defragmentierung(int zeitabstand, String laufwerk) {
        super("Defrag");
        this.zeitabstand = zeitabstand;
        this.laufwerk = laufwerk;
    }

    @Override
    public String toString() {
        return String.format("Zeitabstand: (%d), LW(%s)", zeitabstand, laufwerk);
    }
    
}
