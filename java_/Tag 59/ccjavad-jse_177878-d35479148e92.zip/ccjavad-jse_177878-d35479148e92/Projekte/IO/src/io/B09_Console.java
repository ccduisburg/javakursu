package io;

import java.io.Console;

public class B09_Console {

    // zum Start bitte die Datei test-console.bat ausführen aus dem Projekt-Verzeichnis
    public static void main(String[] args) {
        
        // Das Console-Objekt ist nur mit System.console() zu bekommen:
        Console c = System.console();
        
        c.printf("Der %d. Tag der Woche ist %s %n", 1, "Mo");
        c.format("Der %d. Tag der Woche ist %s %n", 2, "Di");
     
        /*
            Strings Lesen
        */
        c.format("Bitte die 1. Eingabe: ");
        String line = c.readLine();         // String lesen
        
        c.format("Eingabe 1: %s %n", line);
        
        line = c.readLine("Bitte die 2. Eingabe: "); // String lesen mit Eingabeaufforderung davor
        
        c.format("Eingabe 2: %s %n", line);
        
        
        /*
            Passwort Lesen
            Bei der Eingabe werden die Zeichen auf der Console nicht gezeigt.
        */
        // char[] pwdArray = c.readPassword(); // Passwort Lesen
        
        char[] pwdArray = c.readPassword("Passwort eingeben: "); // Passwort Lesen, davor Eingabeaufforderung
        
        // String s = c.readPassword("Passwort eingeben: "); // Compilerfehler
        c.format("Passwort empfangen");
    }
    
}
