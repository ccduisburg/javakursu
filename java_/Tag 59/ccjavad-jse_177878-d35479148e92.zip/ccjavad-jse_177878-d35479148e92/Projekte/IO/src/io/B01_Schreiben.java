package io;

import java.io.FileWriter;
import java.io.IOException;

public class B01_Schreiben {

    public static void main(String[] args) {
        
        /*
            Vor Java 7:
        */

        FileWriter out = null;
        try {
            out = new FileWriter("abc"); // erzeugt eine neue Datei, 
                                         // oder ersetzt die vorhandene.
        
        // new FileWriter("abc", true); // erzeugt eine neue Datei, 
                                        // oder öffnet die bereits vorhandene,
                                        // um dazu zu schreiben.
                                                
        out.write('a'); // diese write(int) ist LANGSAM
        out.write('b');
        out.write('c');
        
        // out.flush(); // schiebt die im internen Puffer gesammelten 
                        // Zeichen an das Ziel.

        } catch(IOException e) {
            System.out.println("Fehler beim Öffnen/Schreiben");
        } finally {
            if(out!=null) {
                try {
                    out.close(); // close wird auch flush aufrufen
                } catch(IOException e) {
                    System.out.println("Fehler beim Schliessen");
                }
            }
        }
        
        /*
            Ab Java 7: try-with-resources
        */
        try( FileWriter fw = new FileWriter("def") ) {
            fw.write('d');
            fw.write('e');
            fw.write('f');
        } catch(IOException e) {
            System.out.println("Fehler bei der Arbeit mit der Datei");
        } // die Ressource wird hier implizit korrekt gschlossen
        
        
        System.out.println("end of main");
        
    }
    
}
