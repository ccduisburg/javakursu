package io;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class B03_LesenSchreiben_mit_array_Puffer {

    //Achtung! Nur weil es ein Lernbeispiel zum Thema 'Array-Puffer' 
    // ist wird die main hier die Exceptions ignorieren.
    public static void main(String[] args) throws IOException {
        
        try( FileReader in = new FileReader("autos.txt");
                FileWriter out = new FileWriter("autos.copy.txt") ) {

            char[] cbuf = new char[6]; // Array-Puffer
            int len;
            
            while( (len = in.read(cbuf)) != -1 ) {
//                String charsAsString = String.valueOf(cbuf); // falsch. nicht immer sind alle zeichen gültig
                String charsAsString = String.valueOf(cbuf, 0, len);
                System.out.println("gelesen: " + charsAsString);
                
                out.write(cbuf, 0, len);
            }
        }
    }
}
