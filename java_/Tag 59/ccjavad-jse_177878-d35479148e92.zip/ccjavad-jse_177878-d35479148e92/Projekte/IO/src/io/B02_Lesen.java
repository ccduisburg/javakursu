package io;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class B02_Lesen {

    public static void main(String[] args) {
        
        try( FileReader in = new FileReader("def") ) {
            
            int ch;
            while( (ch = in.read()) != -1 ) { // diese read() ist LANGSAM
                System.out.println("Zeichen: " + (char)ch + " = " + ch);
            }
            
        } catch( FileNotFoundException e ) {
            System.out.println("Fehler beim Öffnen der Datei");
            
        } catch( IOException e ) {
            System.out.println("Fehler bei dem Lesen/Schliessen der Datei");
        }
        
    }
    
}
