package io;

import java.io.IOException;
import java.io.PrintStream;

public class B08_default_System_Streams {

    public static void main(String[] args) throws IOException {
        
        System.out.println("Mit System.out");
        System.err.println("1. Mit System.err"); // auf die Console
        
        PrintStream myErrStream = new PrintStream("errors.txt");
        System.setErr(myErrStream); // System.err umleiten
        
        System.err.println("2. Mit System.err"); // in die Datei
        
        System.out.println("end of main");
    }
    
}
