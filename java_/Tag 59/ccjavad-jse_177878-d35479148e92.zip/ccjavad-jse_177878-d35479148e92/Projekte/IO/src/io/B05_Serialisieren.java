package io;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/*
    Serialisiert werden können:
        - primitive
        - Arrays (wenn die Elemente diese Regeln erfüllen)
        - Objekte, die 'Serializable' implementieren, (wenn die Attribute diese Regeln erfüllen)

    Beim Serialisieren werden übersprungen:
        - Attribute aus der nicht-Serializable Basisklasse
        - transient-Attribute 
*/

public class B05_Serialisieren {
    
    static class Motor {
    }

    static class Auto {
        int baujahr; // wird nicht serialisiert
    }
    
    static class PKW extends Auto implements Serializable {
        String hersteller;
        transient int id; // wird nicht serialisiert
        Motor motor;

        public String toString() {
            return hersteller + ". Baujahr: " + baujahr + ". id = " + id;
        }
    }
    
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        
        String fileName = "serialisiertes objekt.txt";
        
        PKW pkw1 = new PKW();
        pkw1.baujahr = 2003;
        pkw1.hersteller = "Opel";
        pkw1.id = 22;
        // pkw1.motor = new Motor(); // Motor ist NICHT Serializable.
                                     // Würde zum Fehler beim Serialisieren
                                     // von diesem PKW führen
        
        try( ObjectOutputStream oos 
                = new ObjectOutputStream(new FileOutputStream(fileName)) ) {
            oos.writeObject(pkw1);
        }
        System.out.println("Serialisiert: " + pkw1);
        
        
        PKW pkw2;
        try( ObjectInputStream ois 
                = new ObjectInputStream(new FileInputStream(fileName))) {
         
            pkw2 = (PKW)ois.readObject();
        }
        System.out.println("Deserialisiert: " + pkw2); // Opel. Baujahr: 0. id = 0
        
    }
    
}
