package io;

import java.io.IOException;
import java.io.PrintWriter;

public class B07_PrintWriter {

    public static void main(String[] args) throws IOException {
        
        // PrintStream
        System.out.println("Hallo Welt");
        
        // PrintWriter hat auch die Methoden für die formatierte Ausgabe wie System.out
        try( PrintWriter out = new PrintWriter("file.txt") ) {
            out.println("println hat PrintWriter auch");
        }
        
    }
    
    
}
