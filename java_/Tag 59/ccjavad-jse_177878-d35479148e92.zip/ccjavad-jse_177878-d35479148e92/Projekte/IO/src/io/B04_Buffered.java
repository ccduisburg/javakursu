package io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class B04_Buffered {

    public static void main(String[] args) throws IOException {
        
        // mit BufferedReader(Reader, int) kann man eigene Puffergröße festlegen
        // new BufferedWriter(Writer, int) kann man eigene Puffergröße festlegen
        
        try( BufferedReader in = new BufferedReader(new FileReader("autos.txt"));
                BufferedWriter out = new BufferedWriter(new FileWriter("autos.copy2.txt"))) {
            
            String line;
            while( (line = in.readLine()) != null ) {
                System.out.println(line);
                
                out.write(line);
                out.newLine();
            }
            
        }
        
    }
    
}
