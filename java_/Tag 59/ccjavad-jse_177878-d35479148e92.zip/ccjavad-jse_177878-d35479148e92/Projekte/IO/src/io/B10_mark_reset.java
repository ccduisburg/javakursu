package io;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

public class B10_mark_reset {

    public static void main(String[] args) throws IOException {
        
        Reader in = new StringReader("abcdef");
        
        // Vor dem Lesen:
        //  |-cursor
        //  abcdef
        
        
        char ch = (char)in.read();
        System.out.println(ch);       // a
        // nach dem read:
        //   |-cursor
        //  abcdef
        
        int readAheadLimit = 3; // 3 nächste gelesene chars wird die Markierung erhalten
        in.mark(readAheadLimit);
        // nach dem mark:
        //   |-cursor
        //  abcdef
        //   |-mark
        
        
        ch = (char)in.read();
        System.out.println(ch);       // b
        // nach dem read:
        //    |-cursor
        //  abcdef
        //   |-mark

        
        ch = (char)in.read();
        System.out.println(ch);       // c
        // nach dem read:
        //     |-cursor
        //  abcdef
        //   |-mark

        in.reset(); // cursor zu mark bewegen
        // nach dem reset:
        //   |-cursor
        //  abcdef
        //   |-mark
        
        
        ch = (char)in.read();
        System.out.println(ch);       // b
        // nach dem read:
        //    |-cursor
        //  abcdef
        //   |-mark
}
    
}
