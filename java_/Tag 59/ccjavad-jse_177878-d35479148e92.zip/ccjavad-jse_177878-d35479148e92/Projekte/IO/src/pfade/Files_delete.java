package pfade;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Files_delete {


    public static void main(String[] args) throws IOException {
    
        Path file = createTestFile();
       
        System.out.println("VOR delete. file exists: " + Files.exists(file));
        Files.delete(file);
        System.out.println("NACH delete. file exists: " + Files.exists(file));

        try {
            Files.delete(file);
        } catch(NoSuchFileException e) {
            System.out.println("Fehler! Die Datei wurde nicht gefunden");
        }
        
        boolean result = Files.deleteIfExists(file);
        System.out.println("Datei gelöscht: " + result);
    }

    static Path createTestFile() throws IOException {
        Path file = Paths.get("testfile.txt");
        
        try( PrintWriter out = new PrintWriter( file.toFile() ) ) {
            out.println("Zeile 1");
            out.println("Zeile 2");
            out.println("Zeile 3");
        } 
        
        return file;
    }
}
