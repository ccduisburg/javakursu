package pfade;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.function.Consumer;
import java.util.stream.Stream;


class MyFileVisitor implements FileVisitor<Path> {
    @Override
    public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
        System.out.println(dir);
        return FileVisitResult.CONTINUE;
    }

    @Override
    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
        return FileVisitResult.CONTINUE;
    }

    @Override
    public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
        return FileVisitResult.CONTINUE;
    }

    @Override
    public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
        return FileVisitResult.CONTINUE;
    }
}

public class Files_walk_und_Co {

    public static void main(String[] args) throws IOException {
        
//        String rootName =  "C:\\Program Files\\7-Zip";
        String rootName =  "C:\\Program Files\\GIMP 2";
        Path root = Paths.get(rootName);
        
        // myWalk(root, System.out::println); // Eigene Lösung nur für Verzeichnisse
        
        // Stream<Path> walk = Files.walk(root); // Lösung mit einem funkt. Stream
        
        // Eine weitere Lösung (walkFileTree):
//        FileVisitor<Path> visitor = new MyFileVisitor();
        FileVisitor<Path> visitor = new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                System.out.println(dir);
                return FileVisitResult.CONTINUE;
            }
        };
        Files.walkFileTree(root, visitor);
    }
    
    // Langsam!
    static void myWalk(Path root, Consumer<Path> dirConsumer) throws IOException {
        // System.out.println(root);
        dirConsumer.accept(root);
        
        // Stream<Path> entries = Files.list(root);
        
        DirectoryStream<Path> dirStr = Files.newDirectoryStream(root);
        
        for( Path entry : dirStr ) {
            if( Files.isDirectory(entry) ) {
                myWalk(entry, dirConsumer);
            }
        }
    }
}
