package pfade;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Stream;

public class Files_Zeilen_einer_Textdatei {

    public static void main(String[] args) throws IOException {

        Path file = createTestFile();
        
        // Exam: readAllLines liefert die List<String>
        List<String> readAllLines = Files.readAllLines(file);
        readAllLines.forEach(System.out::println);
        
        // Exam: lines liefert einen Stream<String>
        Stream<String> lines = Files.lines(file);
        lines.forEach(System.out::println);
        
    } // 

    static Path createTestFile() throws IOException {
        Path file = Paths.get("testfile.txt");

        try (PrintWriter out = new PrintWriter(file.toFile())) {
            out.println("Zeile 1");
            out.println("Zeile 2");
            out.println("Zeile 3");
        }

        return file;
    }
}
