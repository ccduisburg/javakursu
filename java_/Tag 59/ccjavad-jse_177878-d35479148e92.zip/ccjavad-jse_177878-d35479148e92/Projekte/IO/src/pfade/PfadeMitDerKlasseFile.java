package pfade;

import java.io.File;

public class PfadeMitDerKlasseFile {

    public static void main(String[] args) {
        
        /*
            - File-Objekt beschreibt ein Pfad (vorhandenen oder auch nicht)
        
            - es sind relative und absolute Pfadangaben möglich
        */
        
        // Pfad relativ zum aktuellen Arbeitsverzeichnis
        File f1 = new File("hallo"); 
        System.out.println("exists hallo? -> " + f1.exists());
        
        // absolute Pfad (UNIX)
        File f2 = new File("/a/b/c"); 

        // absolute Pfad (Windows)
        File f3 = new File("C:\\a\\b\\c"); 
        

        // Datei aus dem Netbeans-Projektverzeichnis
        File f4 = new File("build.xml"); 
        System.out.println("exists build.xml? -> " + f4.exists());
        System.out.println("build.xml eine Datei? -> " + f4.isFile());
        System.out.println("build.xml eine Verzeichnis? -> " + f4.isDirectory());
        
        
    }
    
}
