package pfade;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.CopyOption;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class Files_copy_move {

    public static void main(String[] args) throws IOException {
        // testCopy();
        // testMove();
        moveThrowsExceptionIfTargetIsDirectory();
    }
    
    static void moveThrowsExceptionIfTargetIsDirectory() throws IOException {
        Path sourceFile = createTestFile();
        
        Path dir = Paths.get("dir");
        
        try {
            Files.move(sourceFile, dir, StandardCopyOption.REPLACE_EXISTING);
        } catch(DirectoryNotEmptyException e) {
            System.out.println("Fehler! Es gibt ein Verzeichnis, das so heißt wie die gewünschte Datei");
        }
        
        Path fileName = sourceFile.getFileName();
        Path targetFile = dir.resolve(fileName);

        Files.move(sourceFile, targetFile, StandardCopyOption.REPLACE_EXISTING);        
        System.out.println("NACH move. targetFile exists: " + Files.exists(targetFile));
    }
    
    static void testMove() throws IOException {
        Path sourceFile = createTestFile();
        Path targetFile = Paths.get("movedfile.txt");
        
        CopyOption[] options = {
            StandardCopyOption.REPLACE_EXISTING,
//            StandardCopyOption.COPY_ATTRIBUTES // für move nicht erlaubt
//            StandardCopyOption.ATOMIC_MOVE,   // geht auch
        };
        
        System.out.println("VOR move. sourceFile exists: " + Files.exists(sourceFile));
        System.out.println("VOR move. targetFile exists: " + Files.exists(targetFile));
        Files.move(sourceFile, targetFile, options);
        System.out.println("NACH move. sourceFile exists: " + Files.exists(sourceFile));
        System.out.println("NACH move. targetFile exists: " + Files.exists(targetFile));
    }
    
     
    static void testCopy() throws IOException {
        Path sourceFile = createTestFile();
        Path targetFile = Paths.get("testfile.copy.txt");
        
        CopyOption[] options = {
            StandardCopyOption.REPLACE_EXISTING,
            StandardCopyOption.COPY_ATTRIBUTES
        };
        
        System.out.println("testfile.copy.txt exists: " + Files.exists(targetFile));
        Files.copy(sourceFile, targetFile, options);
        System.out.println("testfile.copy.txt exists: " + Files.exists(targetFile));
        
        try {
            Files.copy(sourceFile, targetFile); // keine Option REPLACE_EXISTING:
                                                // FileAlreadyExistsException
                                                // wird geworfen
            
        } catch (FileAlreadyExistsException e) {
            System.out.println("Die Zieldatei existiert bereits!");
        }
    }


    static Path createTestFile() throws IOException {
        Path file = Paths.get("testfile.txt");
        
        try( PrintWriter out = new PrintWriter( file.toFile() ) ) {
            out.println("Zeile 1");
            out.println("Zeile 2");
            out.println("Zeile 3");
        } 
        
        return file;
    }
    
}
