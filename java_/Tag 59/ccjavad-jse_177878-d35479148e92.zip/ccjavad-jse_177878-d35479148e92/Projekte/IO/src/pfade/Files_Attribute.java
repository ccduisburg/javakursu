package pfade;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;

public class Files_Attribute {

    public static void main(String[] args) throws IOException {
        testGetFileAttributeView();
        testReadAttributes();
    }
    
    // Wichtig für die Prüfung: es gibt keine setter-Methode, 
    // die nur ein Datei-Attribut als Argument hat (s. setTimes).
    static void testGetFileAttributeView() throws IOException {
        Path file = Paths.get("array.txt");
        
        BasicFileAttributeView view = Files.getFileAttributeView(file, BasicFileAttributeView.class);
        
        BasicFileAttributes atts = view.readAttributes();
        FileTime creationTime;// = atts.creationTime();
        
        // long millis = System.currentTimeMillis();  // Millisekunden seit dem 1.1.1970
        //creationTime = FileTime.fromMillis( millis );
        creationTime = FileTime.fromMillis( 0 ); // 1.1.1970
        
        FileTime lastAccessTime = atts.lastAccessTime();
        FileTime lastModifiedTime = atts.lastModifiedTime();
                
        view.setTimes(lastModifiedTime, lastAccessTime, creationTime);
    }

    // Wichtig für die Prüfung: Es ist möglich einige Datei-Attribute zu lesen
    static void testReadAttributes() throws IOException {
        Path file = Paths.get("array.txt");
        
        BasicFileAttributes atts 
                = Files.readAttributes(file, BasicFileAttributes.class);
        
        FileTime creationTime = atts.creationTime();
        System.out.println("creationTime: " + creationTime);
        FileTime lastModifiedTime = atts.lastModifiedTime();
        System.out.println("lastModifiedTime: " + lastModifiedTime);
        
    }
    
    
}
