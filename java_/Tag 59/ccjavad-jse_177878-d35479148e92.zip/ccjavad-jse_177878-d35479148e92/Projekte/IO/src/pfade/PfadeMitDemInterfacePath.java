package pfade;

import java.nio.file.Path;
import java.nio.file.Paths;

public class PfadeMitDemInterfacePath {

    public static void main(String[] args) {
        
        /*
            - Path beschreibt einen Pfad (vorhanden oder auch nicht)
        */
        
        // Pfad relativ zum aktuellen Arbeitsverzeichnis
        Path p1 = Paths.get("hallo");
        Path p2 = Paths.get("a/b/c"); // UNIX
        Path p3 = Paths.get("a\\b\\c"); // Windows
        
        // Absolute Pfadangaben (UNIX)
        Path p4 = Paths.get("/a/b/c");
        Path p5 = Paths.get("C:\\a\\b\\c");
        
        // 
//        Path parent = Paths.get( "C:\\" );
//        Path myPath = Paths.get( parent, "a", "b", "c" );
        
        String parent = "C:\\";
        Path myPath = Paths.get( parent, "a", "b", "c" );
        System.out.println("myPath = " + myPath); // C:\a\b\c
        
    }
    
}
