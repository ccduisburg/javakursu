package pfade;

import java.nio.file.Path;
import java.nio.file.Paths;

public class PathAPI_resolve_relativize {

    public static void main(String[] args) {
        
        Path path = Paths.get("a", "b", "c");
        System.out.println("path: " + path); // a\b\c
        
        Path resolvedPath = path.resolve("d"); // auch mit Path-Parameter
        System.out.println("resolvedPath: " + resolvedPath); // a\b\c\d
        
        // System.out.println( path.resolve("C:\\m") ); // C:\m
        

        System.out.println("-------------------");
        
        Path p1 = Paths.get("C:\\java\\projects");
        Path p2 = Paths.get("C:\\cpp\\examples");
        
        Path p3 = p1.relativize(p2);
        System.out.println("p3: " + p3); // ..\..\cpp\examples
    }
    
}
