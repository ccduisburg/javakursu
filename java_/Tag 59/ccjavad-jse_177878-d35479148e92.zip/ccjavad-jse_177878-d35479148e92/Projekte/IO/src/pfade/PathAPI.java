package pfade;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

public class PathAPI {

    public static void main(String[] args) {
        Path buildFile = Paths.get("build.xml");
        
        /*
            Path to File to Path
        */
        File f1 = buildFile.toFile();
        Path p1 = f1.toPath();
        /*
            infos mit dem relativen Pfad
         */
        printInfos(buildFile);
        
        Path buildPathAbsolute = buildFile.toAbsolutePath();
        
        /*
            infos mit dem absolutem Pfad
         */
        printInfos(buildPathAbsolute);
        
    } // end of main
    
    static void printInfos(Path path) {
        System.out.println("***************************************");
        System.out.println("Infos (toString) zu: " + path);
        
        /*
            Elemente im Path
        */
        Path root = path.getRoot();
        System.out.println("getRoot: " + root);
        
        int nameCount = path.getNameCount();
        System.out.println("getNameCount (ohne root): " + nameCount);
        
        // Für:
        // C:\Users\apatrin\Documents\NetBeansProjects\jse_177878\Projekte\IO\build.xml
        // name = Users
        Path name = path.getName(0);
        System.out.println("getName(0): " + name);
        
        
        Path fileName = path.getFileName();
        System.out.println("Path getFileName(): " + fileName);
    }
    
}
