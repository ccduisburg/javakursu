package entwurfsmuster;

public class Enums {

    // s. aufgaben.enums.AufgabeHunderassen
    
}
