package entwurfsmuster;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;

public class Factory {

    public static void main(String[] args) {
        
        // Exam: Beispiele vom Factory-Pattern aus der Standardbibliothek
        
        DateFormat df = DateFormat.getDateInstance();
        NumberFormat nf = NumberFormat.getCurrencyInstance();
        
    }
    
}
