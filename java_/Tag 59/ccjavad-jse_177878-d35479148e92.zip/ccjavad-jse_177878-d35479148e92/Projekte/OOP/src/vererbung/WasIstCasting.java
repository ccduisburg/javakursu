package vererbung;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class WasIstCasting {

    public static void main(String[] args) {
        
        // Zur Compilerzeit: Typen von Operanden existieren.
        //      IS-A Beziehung wird vom Compiler kontrolliert.
        
        // Zur Laufzeit:
        // 1. 32 bit auf dem Stack reservieren (für var)
        // 2. Integer-Objekt auf dem Heap bilden
        // 3. Die Adresse vom Objekt auf dem Stack kopieren
        Object var = new Integer(22);
        
        
        
        // Zur Compilerzeit: Typen von Operanden existieren.
        //      IS-A Beziehung wird vom Compiler kontrolliert:
        //          Integer IS-A Integer (Zuweisung)
        //          Object und Integer haben Vererbungsbeziehung (Casting)
        
        // Zur Laufzeit:
        // 1. 32 bit auf dem Stack reservieren (für i)
        // 2. if( !(var instanceof Integer) ) throw new ClassCastException();
        // 3. Die Adresse aus var(Stack) in i (Stack) kopieren
        Integer i = (Integer) var;
        
        Character[] arr = { 'a', 'n', 'n', 'a' };
        List<Character> list = Arrays.asList(arr);
        
         // 2. if( !(list instanceof Collection) ) throw new ClassCastException();
        Collection<Character> coll = (Collection)list; // OK
        
        // if( !(coll instanceof ArrayDeque) ) throw new ClassCastException();
        // ArrayDeque d = (ArrayDeque)coll;  // Exception
        
        
        // new ArrayDeque<>(list);
    }
    
}
