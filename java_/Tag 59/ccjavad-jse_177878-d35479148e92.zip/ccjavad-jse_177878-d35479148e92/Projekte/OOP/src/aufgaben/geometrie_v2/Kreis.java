package aufgaben.geometrie_v2;

public class Kreis extends Figur {
    int radius;
    
    
}
