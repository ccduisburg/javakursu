package aufgaben.geometrie_v2;

public class Rechteck extends Figur {
    int breite, hoehe;
}
