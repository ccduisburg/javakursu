package aufgaben.geometrie_v2;

public class Figur {
    int x, y;
    
    void bewegen(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
