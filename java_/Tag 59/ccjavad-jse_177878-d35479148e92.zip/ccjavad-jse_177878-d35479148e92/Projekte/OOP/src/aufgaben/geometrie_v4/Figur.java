package aufgaben.geometrie_v4;

public abstract interface  Figur {
    abstract double getFlaeche();
//    double getFlaeche() {
//        return -1;
//    }
}
