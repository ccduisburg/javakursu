package aufgaben.deque;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.List;

public class AufgabePalindrom {
    
    // Speichern Sie bitte die Zeichen aus dem arr in einem ArrayDeque.
    // Entfernen Sie Zeichen nacheinander von beiden Enden der ArrayDeque
    // und überprüfen Sie dabei, ob sie identisch sind. Auf diese Weise
    // ermitteln Sie, ob die Zeichen in dem übergebenen Array 
    // ein Palindrom ergeben.
    static boolean isPalindrome(Character... arr) {
        
        List<Character> list = Arrays.asList(arr);
        ArrayDeque<Character> deck = new ArrayDeque<>(list);
        
        while( deck.size() > 1 ) {
            Character c1 = deck.removeFirst();
            Character c2 = deck.removeLast();
            
            if(!c1.equals(c2)) {
                return false;
            }
        }
        
        return true;
    }
    
    static boolean isPalindrome(String s) {
        Character[] arr = s.chars()
                .mapToObj( c -> (char)c )
                .toArray(Character[]::new);

        return isPalindrome(arr);
    }
    
    public static void main(String[] args) {
        
        Character[] arr = { 'a', 'n', 'n', 'a' };
        
        boolean erg = isPalindrome(arr);
        System.out.println("erg: " + erg);
        
        System.out.println( isPalindrome('r', 'o', 't', 'o', 'r') );
        System.out.println( isPalindrome('m', 'o', 't', 'o', 'r') );
        
        System.out.println( isPalindrome("motor") );
        System.out.println( isPalindrome("rotor") );
    }
}
