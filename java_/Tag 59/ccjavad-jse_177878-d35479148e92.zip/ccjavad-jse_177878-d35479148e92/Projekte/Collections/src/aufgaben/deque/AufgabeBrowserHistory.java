package aufgaben.deque;

import java.util.ArrayDeque;
import java.util.Deque;

class BrowserHistory {
    private final int maxPreviousSize = 5;
    
    private Deque<String> previousAndCurrent = new ArrayDeque<>();
    private Deque<String> next = new ArrayDeque<>();
    
    public void open(String url) {
        previousAndCurrent.offerFirst(url);
        
        if(previousAndCurrent.size() > maxPreviousSize) {
            previousAndCurrent.pollLast();
        }
    }
    
    public String getCurrent() {
        return previousAndCurrent.peekFirst();
    }

    public void openPrevious() {
        if(previousAndCurrent.size()<=1) {
            throw new IllegalStateException("previous history is empty");
        }
        
        String removed = previousAndCurrent.pollFirst();
        
        next.push(removed);
    }
    
    public void openNext() {
        if(next.isEmpty()) {
            throw new IllegalStateException("next history is empty");
        }
        
        String url = next.pop();
        open(url);
    }
    
    @Override
    public String toString() {
        return previousAndCurrent.toString();
    }
}

public class AufgabeBrowserHistory {

    public static void main(String[] args) {
        
        BrowserHistory h = new BrowserHistory();
        
        h.open("u1.com"); // HEAD u1 TAIL
        System.out.println( h.getCurrent() ); 	// u1.com
        
        h.open("u2.com"); // HEAD u2 u1 TAIL
        System.out.println( h.getCurrent() ); 	// u2.com
        
        h.open("u3.com");
        h.open("u4.com");
        h.open("u5.com"); // HEAD u5 u4 u3 u2 u1 TAIL
        System.out.println( h.getCurrent() ); 	// u5.com
        
        h.open("u6.com"); // HEAD u6 u5 u4 u3 u2 TAIL
        System.out.println( h.getCurrent() );	// u6.com
     
        System.out.println("history: " + h);
        
        h.openPrevious(); // HEAD u5 u4 u3 u2 TAIL
        System.out.println( h.getCurrent() );	// u5.com

        h.openPrevious(); // HEAD u4 u3 u2 TAIL
        h.openPrevious(); // HEAD u3 u2 TAIL
        h.openPrevious(); // HEAD u2 TAIL
        System.out.println( h.getCurrent() );	// u2.com

        try {
            h.openPrevious();
        } catch (IllegalStateException e) {
            System.out.println( e.getMessage() ); // previous history is empty
        }
        System.out.println( h.getCurrent() );	// u2.com
        
        System.out.println("4 mal openNext");
        h.openNext();
        h.openNext();
        h.openNext();
        h.openNext();
        System.out.println( h.getCurrent() );	// u6.com
        
        try {
            h.openNext();
        } catch (IllegalStateException e) {
            System.out.println( e.getMessage() ); // next history is empty
        }

        System.out.println( h.getCurrent() );	// u6.com
    }
    
}
