package aufgaben.set;

import java.util.TreeSet;

public class AufgabeAbfahrtzeiten {

    public static void main(String[] args) {
        
        TreeSet<String> abfahrtzeiten = getAbfahrtzeiten();
        System.out.println(abfahrtzeiten);
        
//    - suchen Sie die erste Abfahrtzeit nach 12:03
        System.out.println("suchen Sie die erste Abfahrtzeit nach 12:03: ");
        System.out.println(abfahrtzeiten.higher("12:03"));
        
//    - suchen Sie nach der ersten Abfahrtzeit vor 12:03
        System.out.println("suchen Sie nach der ersten Abfahrtzeit vor 12:03");
        System.out.println(abfahrtzeiten.lower("12:03"));

//    - suchen Sie nach der ersten Abfahrtzeit nach 17:12 inklusive
        System.out.println("Suchen Sie nach der ersten Abfahrtzeit nach 17:12 inklusive");
        System.out.println(abfahrtzeiten.ceiling("17:12"));

//    - suchen Sie nach der ersten Abfahrtzeit nach 17:12 exklusive
        System.out.println("Suchen Sie nach der ersten Abfahrtzeit nach 17:12 exklusive");
        System.out.println(abfahrtzeiten.higher("17:12"));


//    - suchen Sie nach allen Abfahrtzeiten zwischen 12:00 bis 13:00
        System.out.println("suchen Sie nach allen Abfahrtzeiten zwischen 12:00 bis 13:00");
        System.out.println(abfahrtzeiten.subSet("12:00", "13:00"));

//    - suchen Sie nach allen Abfahrtzeiten zwischen 11:52 exklusive bis 13:12 inklusive
        System.out.println("suchen Sie nach allen Abfahrtzeiten zwischen 11:52 exklusive bis 13:12 inklusive");
        System.out.println(abfahrtzeiten.subSet("11:52", false, "13:12", true));

//    - suchen Sie nach der erstmöglichen Abfahrtzeit
        System.out.println("erstmögliche Abfahrtzeit: " + abfahrtzeiten.first());
//    - suchen Sie nach der letztmöglichen Abfahrtzeit
        System.out.println("letztmöglichen Abfahrtzeit: " + abfahrtzeiten.last());
        
    }
    
    private static TreeSet<String> getAbfahrtzeiten() {
        TreeSet<String> set = new TreeSet<>();
        
        for (int stunde = 6; stunde < 24; stunde++) {
            for (int minute = 12; minute < 60; minute += 20) {
                
                String zeit = String.format("%02d:%d", stunde, minute);
                set.add(zeit);
            }
        }
        
        return set;
    }
}
