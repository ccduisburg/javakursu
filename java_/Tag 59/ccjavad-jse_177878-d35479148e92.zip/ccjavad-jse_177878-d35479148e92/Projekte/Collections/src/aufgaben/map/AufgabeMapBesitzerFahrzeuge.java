package aufgaben.map;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class AufgabeMapBesitzerFahrzeuge {

    public static void main(String[] args) {
        Person p1 = new Person("Tom", "K.");
        Person p2 = new Person("Jerry", "M.");
        Person p3 = new Person("Paul", "Smith");

        Fahrzeug f1 = new Fahrzeug("VW", "Golf");
        Fahrzeug f2 = new Fahrzeug("VW", "Polo");
        Fahrzeug f3 = new Fahrzeug("Opel", "Corsa");
        Fahrzeug f4 = new Fahrzeug("Fiat", "Panda");

        Map<Fahrzeug, Person> fahrzeugToPerson = new HashMap<>();

        fahrzeugToPerson.put(f1, p1);
        fahrzeugToPerson.put(f2, p2);
        fahrzeugToPerson.put(f3, p3);
        fahrzeugToPerson.put(f4, p1); // Tom K.
        
        System.out.println("******* Farzeug-to-Person ********");
        for( Fahrzeug f : fahrzeugToPerson.keySet() ) {
            System.out.println("***");
            System.out.println(f);
            Person p = fahrzeugToPerson.get(f);
            System.out.println(p);
        }
        
        System.out.println("--- suchen mit de Fahrzeug-Key");
        //- Suchen Sie in der Map nach dem Besitzer mit einem Fahrzeug-Key.
        Person p = fahrzeugToPerson.get(new Fahrzeug("Fiat", "Panda"));
        System.out.println("p = " + p);

        System.out.println("****** Person-to-FahrzeugCollection *********");
        //Ordnen Sie in einer weiteren Map einem Besitzer alle seine Fahrzeuge zu. Überlegen Sie wie mehrere Fahrzeuge einem Person-Schlüßel zugeordnet werden können.
        Map<Person, Collection<Fahrzeug>> personToFahrzeugColl = 
                new TreeMap<>();
        
        personToFahrzeugColl.put(p1, Arrays.asList(f1, f4) );
        personToFahrzeugColl.put(p2, Arrays.asList(f2) );
        personToFahrzeugColl.put(p3, Arrays.asList(f3) );
        
        System.out.println("size: " + personToFahrzeugColl.size());
        
        //Suchen Sie in der neuen Map nach den Fahrzeugen mit einem Person-Key.
        System.out.println("Suche mit Person-Key");
        
        // V get(Object)
        Collection<Fahrzeug> fahrzeuge 
                = personToFahrzeugColl.get(new Person("Tom", "K."));
        
        System.out.println("fahrzeuge: " + fahrzeuge);
    } // end of main
}
