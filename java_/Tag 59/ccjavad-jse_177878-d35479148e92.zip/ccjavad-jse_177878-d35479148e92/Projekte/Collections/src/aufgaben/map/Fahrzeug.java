package aufgaben.map;

public class Fahrzeug {
    private String hersteller, modell;

    public Fahrzeug(String hersteller, String modell) {
        this.modell = modell;
        this.hersteller = hersteller;
    }

    @Override
    public String toString() {
        return "Fahrzeug{" + "hersteller=" + hersteller + ", modell=" + modell + '}';
    }

    @Override
    public int hashCode() {
        return hersteller.hashCode() + modell.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if( !(obj instanceof Fahrzeug) ) {
            return false;
        }
        
        Fahrzeug f2 = (Fahrzeug) obj;
        return hersteller.equals(f2.hersteller) && modell.equals(f2.modell);
    }
    
}
