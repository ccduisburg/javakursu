package map;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class MapIterieren {

    public static void main(String[] args) {
        
        Map<String, Double> map = new TreeMap<>();
        
        map.put("PI", 3.14);
        map.put("E", 2.7);
        map.put("A", 7.5);
        
        System.out.println("------ keySet -------");
        
        Set<String> allKeys = map.keySet();
        for(String key : allKeys) {
            Double value = map.get(key);
            System.out.println(key + " = " + value);
        }
        
        System.out.println("------ values -------");
        
        Collection<Double> allValues = map.values();
        
        for (Double value : allValues) {
            System.out.println(value);
        }
        
        System.out.println("------ entrySet -------");
        
        //Elemente in der aktuellen map haben diesen Typ:
        // Map.Entry<String,Double>
        
        Set<Map.Entry<String,Double>> allEntries = map.entrySet();
        
        for( Map.Entry<String,Double> entry : allEntries ) {
            System.out.println("toString: " + entry);
            System.out.println( "  einzeln: " + entry.getKey() + " = " + entry.getValue());
        }
        
    }
    
}
