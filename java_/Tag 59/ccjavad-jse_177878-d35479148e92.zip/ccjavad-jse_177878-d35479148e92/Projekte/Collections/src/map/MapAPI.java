package map;

import java.util.HashMap;
import java.util.Map;

public class MapAPI {

    public static void main(String[] args) {
        
        Map<Integer, String> map = new HashMap<>();
        
        String v = null;
        
        v = map.put(1, "Mo");       // v = null
        System.out.println("v = " + v);
        
        v = map.put(1, "Montag");   // v = Mo     (alter Wert)
        System.out.println("v = " + v);
        
        map.put(2, "Di");
        map.put(3, "Mi");
        
        
        v = map.get(1);
        System.out.println("get(1): " + v); // Montag

        v = map.get(3000);
        System.out.println("get(3000): " + v); // null
        
        
        v = map.remove(1);
        System.out.println("remove(1): " + v); // Montag
        
        System.out.println("map: " + map); // {2=Di, 3=Mi}
    }
    
}
