package set;

import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.SortedSet;
import java.util.TreeSet;

public class UsingTreeSetAsNavigableSet {

    public static void main(String[] args) {
        
        TreeSet<Integer> basisSet = new TreeSet<>();
        
        basisSet.add(202);
        basisSet.add(33);
        basisSet.add(-5);

        System.out.println("basisSet: " + basisSet); // [-5, 33, 202]
        
        /*
            Zu einzelnen Elementen navigieren
        */
        
        Integer x = basisSet.ceiling(10);           // >= 10
        System.out.println("ceiling(10): " + x);    // 33
        
        x = basisSet.ceiling(33);                   // >= 33
        System.out.println("ceiling(33): " + x);    // 33
        
        x = basisSet.higher(10);                    // > 10
        System.out.println("higher(10): " + x);     // 33
        
        x = basisSet.higher(33);                    // > 10
        System.out.println("higher(33): " + x);     // 202
        
        x = basisSet.higher(1000);                  // > 1000
        System.out.println("higher(1000): " + x);   // null
        
        
        System.out.println("basisSet: " + basisSet); // [-5, 33, 202]
        
        x = basisSet.floor(1000);                  // <= 1000
        System.out.println("floor(1000): " + x);   // 202
        
        x = basisSet.floor(33);                    // <= 33
        System.out.println("floor(33): " + x);     // 33
        
        x = basisSet.lower(33);                    // < 33
        System.out.println("lower(33): " + x);     // -5
        
        
        System.out.println("basisSet: " + basisSet); // [-5, 33, 202]
        System.out.println("first(): " + basisSet.first());
        System.out.println("last(): " + basisSet.last());
        
        
        System.out.println("********************************");
        /*
            Methoden, die gekoppelten Teilsets liefern
        */
        
        System.out.println("basisSet: " + basisSet);            // [-5, 33, 202]
        
        SortedSet<Integer> headSet1 = basisSet.headSet(202); // alles < 202
        System.out.println("headSet1: " + headSet1);            // [-5, 33]
        
        NavigableSet<Integer> headSet2 = basisSet.headSet(202, true); // alles <= 202
        System.out.println("headSet2: " + headSet2);                  // [-5, 33, 202]
        
        
        SortedSet<Integer> tailSet1 = basisSet.tailSet(-5);     // alles >= -5
        System.out.println("tailSet1: " + tailSet1);            // [-5, 33, 200]
        
        NavigableSet<Integer> tailSet2 = basisSet.tailSet(-5, false);  // alles > -5
        System.out.println("tailSet2: " + tailSet2);                   // [33, 200]
        
        
        SortedSet<Integer> subSet1 = basisSet.subSet(-5, 202); // >= -5 und < 202
        System.out.println("subSet1: " + subSet1);             // [-5, 33]
        
        NavigableSet<Integer> subSet2 = basisSet.subSet(-5, false, 202, true);
        System.out.println("subSet2: " + subSet2); // [33, 202]
        
        /*
            Gekoppelt!
        */
        System.out.println("**********************************************");
        System.out.println("basisSet: " + basisSet);            // [-5, 33, 202]
        System.out.println("subSet2: " + subSet2);              // [33, 202]
        
        System.out.println("-- basisSet.add(100)");
        basisSet.add(100);
        
        System.out.println("basisSet: " + basisSet);            // [-5, 33, 100, 202]
        System.out.println("subSet2: " + subSet2);              // [33, 100, 202]
        
        System.out.println("-- subSet2.add(111)");
        subSet2.add(111);
        
        System.out.println("basisSet: " + basisSet);            // [-5, 33, 100, 111, 202]
        System.out.println("subSet2: " + subSet2);              // [33, 100, 111, 202]
        
        
        basisSet.add(3000); // OK
        subSet2.add(2000);  // Achtung! IllegalArgumentException: key out of range
    }
    
}
