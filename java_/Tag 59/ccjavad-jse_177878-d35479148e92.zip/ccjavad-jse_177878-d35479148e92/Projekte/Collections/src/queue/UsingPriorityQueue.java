package queue;

import java.util.*;

public class UsingPriorityQueue {
    
    public static void main(String[] args) {
//        mitComparable();
        mitComparator();
    }

    static void mitComparable() {
        PriorityQueue<String> queue = new PriorityQueue<>();
        
        queue.add("aa");
        queue.offer("mm");
        queue.add("dd");
        queue.offer("aa");
        
        System.out.println("queue: " + queue);
        
        /*
            Das kleinste Element hat die höchste Priorität
        */
        System.out.println("element: " + queue.element());  // aa
        System.out.println("peek: " + queue.peek());        // aa
        
        System.out.println("remove(): " + queue.remove());  // aa
        System.out.println("poll(): " + queue.poll());      // aa
        
        System.out.println("remove(): " + queue.remove());  // dd
        System.out.println("poll(): " + queue.poll());      // mm
        
        //System.out.println("remove(): " + queue.remove());  // java.util.NoSuchElementException
        System.out.println("poll(): " + queue.poll());      // null
    }
    
    static void mitComparator() {
        
        // ------------
        class OS {
            String name;
            OS(String name) {
                this.name = name;
            }
            public String toString() { return name; }
        }
        // ------------
        
        PriorityQueue<OS> queue = new PriorityQueue<>( new Comparator<OS>(){
            public int compare(OS os1, OS os2) {
                return os1.name.compareTo(os2.name);
            }
        } );
        
        queue.offer(new OS("Windows"));
        queue.offer(new OS("Mac"));
        queue.offer(new OS("Linux"));
        
        System.out.println("queue: " + queue); // [Linux, Windows, Mac]
        
        while( !queue.isEmpty() ) {
            System.out.println( queue.poll() );
        }
        
        
    } // 
    
}
