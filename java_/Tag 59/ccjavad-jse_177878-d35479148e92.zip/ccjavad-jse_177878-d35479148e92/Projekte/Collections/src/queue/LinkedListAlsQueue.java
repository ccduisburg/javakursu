package queue;

import java.util.LinkedList;
import java.util.Queue;

public class LinkedListAlsQueue {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>(); // FIFO
        
        queue.add(10);
        queue.add(77);
        queue.add(-1);
        /*
            Queue: 10 77 -1
        */
        
        System.out.println("element: " + queue.element());  // 10
        System.out.println("peek: " + queue.peek());        // 10
        
        System.out.println("remove: " + queue.remove());    // 10
        System.out.println("poll: " + queue.poll());        // 77
        System.out.println("remove: " + queue.remove());    // -1
        System.out.println("poll: " + queue.poll());        // null
        System.out.println("remove: " + queue.remove());    // NoSuchElementException
    }
}
