
package meinspiel;

import com.myGames.figuren.Charakter;
import com.myGames.figuren.Hexer;
import com.myGames.figuren.GespielterCharakter;
import com.myGames.figuren.Krieger;
import ki.Oger;


public class Start {

    public static void main(String[] args) {
        Oger hauDrauf = new Oger();
        Krieger ichRetteDieWelt = new Krieger("Justus Jonas");
        System.out.println("Oger: "+hauDrauf);
        System.out.println("Krieger: "+ichRetteDieWelt);
        hauDrauf.verwunden(ichRetteDieWelt);
        ichRetteDieWelt.verwunden(hauDrauf); 
        System.out.println(hauDrauf);
        System.out.println("Krieger: "+ichRetteDieWelt);
        
        Charakter figur = new Krieger("Peter Shaw");
        Object nurSo = new Krieger("Bob Andrews");
        Charakter refFuerNurSo = (Charakter)nurSo;
        System.out.println("Objekt:" + nurSo.toString());
        //nurSo.verwunden(hauDrauf);
        System.out.println("Das selbe Objekt mit neuer Referenz: " + refFuerNurSo);
        refFuerNurSo.verwunden(hauDrauf); 
        System.out.println(hauDrauf);
    }
    
}
