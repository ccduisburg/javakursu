
package nachhilfe_verwaltungs;
import java.util.Date;

public abstract class Anmeldung {
    protected String anmeldeName;
    protected String anmeldeAdress;
  
}
