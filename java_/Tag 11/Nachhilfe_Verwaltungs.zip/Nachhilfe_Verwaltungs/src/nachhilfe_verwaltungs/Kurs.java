package nachhilfe_verwaltungs;

import nachhilfe_verwaltungs.Person;
import nachhilfe_verwaltungs.Lehre;
import nachhilfe_verwaltungs.Student;
import java.util.Date;
import java.time.LocalDate;

public class Kurs extends Person {

    private int kursId;
    private String kursName;
    private boolean gekundigt;
    private LocalDate anmeldeDatum;

    @Override
    public void personAnmeldung(LocalDate anmeldeDatum) {
        this.name = name;
        this.anmeldeDatum = anmeldeDatum;
        gekundigt = false;
    }

    public int getKursId() {
        return kursId;
    }

    public void setKursId(int kursId) {
        this.kursId = kursId;
    }

    public String getKursName() {
        return kursName;
    }

    public void setKursName(String kursName) {
        this.kursName = kursName;
    }

    public void NehmeKurs(String studentName, int kursId) {
        this.name = studentName;
        this.setKursId(kursId);

    }

    public void GehortKurs(String lehreName, int kursId) {
        this.name = lehreName;
        this.setKursId(kursId);

    }

    public boolean getGekundigt() {
        return gekundigt;
    }

    public void setGekundigt(boolean gekundigt) {
        this.gekundigt = gekundigt;
    }

}
