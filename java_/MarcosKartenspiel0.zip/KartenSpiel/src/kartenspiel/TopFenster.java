/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kartenspiel;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTabbedPane;

/**
 *
 * @author msauer2
 */
public class TopFenster extends JFrame {

    //private JButton tmp= new JButton("Temp");
    private JMenuBar leiste = new JMenuBar();

    private JMenu layout = new JMenu("Layout");//Draufklicken mit Dropdownmenu
    private JMenu andererKram = new JMenu("anderer Kram");

    private JMenuItem grid = new JMenuItem("Grid");
    private JMenuItem flow = new JMenuItem("Flow");
    private JMenuItem border = new JMenuItem("Border");

    //JTabbedPane realisiert Reiter, kann Buttons und so aufnehmen
    //Selbst erstellte Klasse, die nach Wunsch läuft
    private JTabbedPane karten = new Karten();

    public TopFenster() {
        this.setLayout(new BorderLayout(10, 10));
        menuErstellen();
        bauen();
    }

    private void menuErstellen() {
        //Klick auf das layout-dropdownmenu, folgende Inhalte:
        layout.add(grid);
        layout.add(flow);
        layout.add(border);

        //Klick auf Grid abfangen
        grid.addActionListener(ae -> {
            System.out.println("Grid wurde gewählt");
        });

        leiste.add(layout);
        leiste.add(andererKram);
        //leiste.add(this); //Fehler (adding a window to a container), compiler sieht das nicht

        this.setJMenuBar(leiste);
    }

    private void bauen() {
        JButton eins = new JButton("Eins");
        JButton zwei = new JButton("Zwei");

        karten.add(eins);
        karten.add(zwei);

        this.setSize(500, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //this.add(tmp, BorderLayout.NORTH);
        this.add(karten);

    }

}
