/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kartenspiel;

import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

/**
 *
 * @author msauer2
 */
//-JTabbedPane bringt direkt die Reiter mit
public class Karten extends JTabbedPane {

    private JPanel rot = new Fluss();
    private JPanel blau = new JPanel();
    private JPanel pink = new JPanel();
    private JPanel gelb = new JPanel();

    public Karten() {
        zusammenstellen();
    }

    private void zusammenstellen() {
        //man kann auch new Color( rgb farben) nutzen für alle Farben
        rot.setBackground(Color.red);
        this.add(rot);
        this.add("Blau", blau);
        blau.setBackground(Color.blue);
        this.add("Pink", pink);
        pink.setBackground(Color.PINK);
        this.add("Gelb", gelb);
        gelb.setBackground(Color.YELLOW);
        
    }
}
