/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kartenspiel;

import java.awt.FlowLayout;
import java.awt.Font;
import java.time.LocalDate;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author msauer2
 */
public class Fluss extends JPanel {

    //Parent aller Komponenten/funktionale Dinge
    JComponent[] enten = new JComponent[5];
    JLabel ueberschrift = new JLabel("Wochentage");

    public Fluss() {
        //Standard-Layout des JPanels
        //kein layout=flow layout default
        //"Siehe Javadoc", version, die ausrichtung mit annimmt (rechts, mittig, links...)
        this.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 10));

        bauen();
    }

    private void bauen() {

        //Javadoc: name, style und size
        //Font gehört zu awt
        ueberschrift.setFont(new Font("Helvetica", Font.BOLD, 22));
        LocalDate datum = LocalDate.now();

        for (int i = 0; i < enten.length; i++) {

            //arg= Beschriftung
            //toString() wäre das amerikanische Datum
            JButton knopf=new JButton(datum.plusDays(i).getDayOfWeek().toString());
            enten[i] = knopf;
 
            LocalDate wuff=datum.plusDays(i);
            
            knopf.addActionListener(ae -> {
                System.out.println("Ausgewählt: " + ae.getActionCommand());
                System.out.println(wuff);
            });
            this.add(knopf);
        }

    }
}
