
package nachhilfe_verwaltungs.logic;


     public interface Kundigen {
     public boolean getGekundigt();     
     public void setGekundigt(boolean p);
  
    
}
