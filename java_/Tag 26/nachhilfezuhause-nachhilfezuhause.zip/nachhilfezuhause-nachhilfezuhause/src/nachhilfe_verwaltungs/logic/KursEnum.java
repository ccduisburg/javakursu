/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nachhilfe_verwaltungs.logic;
import static nachhilfe_verwaltungs.logic.SchulTypeEnum.*;
/**
 *
 * @author CC-Student
 */
public enum KursEnum {
    MATHEMATIK,DEUTSCH,ENGLISH, TURKISH;
    
    /*
    private  SchulTypeEnum type;
    private  int klasse;
    
    private KursEnum(SchulTypeEnum type,int klasse){
        this.type=type;
        this.klasse=klasse;
    
    }
    */
  /*  @Override
    public String toString(){
    
    return"";
    }*/
}
