
package com.myGames.figuren;

public class SuperHexe extends Object{
    
}
