
package com.myGames.figuren;

public class Krieger extends GespielterCharakter{
   
    protected int koerperkraft;
    
    public Krieger(String spieler){
       super(spieler);
   }
    public Krieger(String spieler, int koerperkraft){
        this(spieler);
        this.koerperkraft = koerperkraft;
    }

    @Override
    public final void verwundetWerden(int schaden){//final: Diese Methode kann nicht überschrieben werden
        super.verwundetWerden(schaden);
        this.lebenspunkte+=this.koerperkraft;
        System.out.println("HUUUUUUUUUUUUUAAAAAAAAAAAAA");
    }
   /**
    * public: die Methode ist sichtbar im gesamten Projekt
    * protected: die Methode ist sichtbar im gesamten Package und in erbenden Klassen
    * "package friendly: wenn kein Modifier angegeben ist":sichtbar im gesamten Package
    * private: sichtbar nur in der Klasse selbst
    */
}
