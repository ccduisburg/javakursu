
package meinspiel;

import com.myGames.figuren.Charakter;
import com.myGames.figuren.Hexer;
import com.myGames.figuren.GespielterCharakter;
import com.myGames.figuren.Krieger;
import com.myGames.waffen.Schwert;
import ki.Oger;
import static com.myGames.waffen.Schwert.sovieleSchwerter;
import static java.lang.System.out;
import static java.lang.Math.PI;

public class Start {

    public static void main(String[] args) {
        int schwertZahl = Schwert.sovieleSchwerter();//statische Methoden werden über Klassenname aufgerufen
        System.out.println("Aktuelle Anzahl von Schwertern: "+schwertZahl);
        Oger hauDrauf = new Oger();
        Krieger ichRetteDieWelt = new Krieger("Justus Jonas");
        System.out.println("Oger: "+hauDrauf);
        System.out.println("Krieger: "+ichRetteDieWelt);
        hauDrauf.verwunden(ichRetteDieWelt);
        ichRetteDieWelt.verwunden(hauDrauf); 
        System.out.println(hauDrauf);
        System.out.println("Krieger: "+ichRetteDieWelt);
        out.println("blabla");
        Charakter figur = new Krieger("Peter Shaw");
        Object nurSo = new Krieger("Bob Andrews");
       
        Charakter refFuerNurSo = (Charakter)nurSo;
        System.out.println("Objekt:" + nurSo.toString());
        //nurSo.verwunden(hauDrauf);
        System.out.println("Das selbe Objekt mit neuer Referenz: " + refFuerNurSo);
        refFuerNurSo.verwunden(hauDrauf); 
        System.out.println(hauDrauf);
        if(ichRetteDieWelt.istNochDabei()){
            ichRetteDieWelt.verwunden(hauDrauf); 
        }
        Schwert exK  = new Schwert();
        exK.gebeSchwertAnNeuenBesitzer(ichRetteDieWelt);
        exK.gebeSchwertAnNeuenBesitzer(hauDrauf);
        
        Schwert eins = new Schwert();
        Schwert zwei = new Schwert();
        Schwert drei = new Schwert();
        schwertZahl = Schwert.sovieleSchwerter();//statische Methoden werden über Klassenname aufgerufen
        System.out.println("Aktuelle Anzahl von Schwertern: "+schwertZahl);
        //System.out.println("Auch ne Zahl..."+drei.sovieleSchwerter());//Funktioniert, aber!!!nicht nachmachen!!!
        Schwert vier = new Schwert();
        Schwert fuenf = new Schwert();
        Schwert sechs = new Schwert();
        System.out.println("Schwerter jetzt: "+sovieleSchwerter());
        System.out.println("Pi ist: "+Math.round(PI));
    }
    
}
