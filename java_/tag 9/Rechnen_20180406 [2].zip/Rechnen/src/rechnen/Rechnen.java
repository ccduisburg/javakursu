package rechnen;

public class Rechnen {

    public static void main(String[] args) {

        int i0 = 0;
        int i1 = 0;
        
        System.out.println("i0(1): " + i0);

        i0++;
        System.out.println("i0(2): " + i0);

        ++i0;
        System.out.println("i0(3): " + i0);

        i1 = i0++;
        System.out.println(" i0(4a): " + i0);
        System.out.println(" i1(4b): " + i1);
        
        i0 = i0++;
        System.out.println(" i0(5a): " + i0);
        System.out.println(" i1(5b): " + i1);

        i0 = ++i0;
        System.out.println("i0(6): " + i0);
        
        System.out.println(i0 + " / i0(7a): " + i0++);
        System.out.println(i0 + " / i0(7b): " + i0);
        
        System.out.println(i0 + " / i0(8a): " + ++i0);
        System.out.println(i0 + " / i0(8b): " + i0);
        
        System.out.println("i0(9): " + i0);
        
        i0 += 5;
        System.out.println("i0(10): " + i0);
        
        i0 =- 5;
        System.out.println("i0(11): " + i0);
        
        int i2 = 5, i3 = 7, i4 = 9;
        
        System.out.println("Summe i2+i3: " + i2+i3);
        System.out.println("Summe (i2+i3): " + (i2+i3) );
        
        System.out.println( (i2+i3) + " ist die Summe von (i2+i3)" );
        System.out.println( i2+i3 + " ist die Summe von i2+i3" );
    }

}
