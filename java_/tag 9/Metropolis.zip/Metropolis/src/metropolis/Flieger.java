
package metropolis;

public interface Flieger {
    void starten();//Alle Methoden des Interfaces sind public!
    void fliegen();
    void landen();
}
