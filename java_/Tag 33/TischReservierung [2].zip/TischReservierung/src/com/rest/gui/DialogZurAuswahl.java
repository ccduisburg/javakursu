/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rest.gui;

import com.rest.logic.BuchungsService;
import com.rest.logic.Tisch;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author Sanne
 */
public class DialogZurAuswahl extends JDialog{
    private JComboBox<Tisch> tischAnzeige = new JComboBox<>();
    private Tisch gewuenscht;
    private JLabel anzeige=new JLabel();
    public DialogZurAuswahl(List<Tisch> tische,BuchungsService bs){
        this.setLayout(new BorderLayout());
        for(Tisch s : tische){
            tischAnzeige.addItem(s);
        }
        this.setSize(new Dimension(400, 100));
        this.add(tischAnzeige);
        JButton wahl = new JButton("Wählen");
        this.add(wahl, BorderLayout.SOUTH);
        this.add(anzeige, BorderLayout.NORTH);
        wahl.addActionListener(ae->{
            
            gewuenscht=bs.buchenMitTischnummer(((Tisch)tischAnzeige.getSelectedItem()).getTischNr());
            anzeige.setText("Vielen Dank, Ihr Tisch ist: "+gewuenscht);
        });
        
   }
}
