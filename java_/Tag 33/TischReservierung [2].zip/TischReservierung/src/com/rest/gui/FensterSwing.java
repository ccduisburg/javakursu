/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rest.gui;

import com.rest.logic.BuchungsService;
import com.rest.logic.Tisch;
import com.rest.logic.TischeAuswahl;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author Sanne
 */
public class FensterSwing extends JFrame{
      private BuchungsService bs;
      private Tisch reserviert;
      
      public FensterSwing(BuchungsService bs){
          this.bs=bs;
          this.setLayout(new GridLayout(3,1));
          //***********neu in Version p(opt) *********//
          this.setLayout(new GridLayout(4,2));
          bauen();
      }

    private void bauen() {
        JLabel frage1 = new JLabel("Wieviele Personen?");
        this.add(frage1);
        JComboBox auswahl1 = new JComboBox(new Integer[]{1,2,3,4,5,6,7,8,9,10});
        this.add(auswahl1);
        
        JLabel frage2 = new JLabel("Wie gut?");
        this.add(frage2);
        JComboBox auswahl2 = new JComboBox(new Integer[]{1,2,3,4,5});
        this.add(auswahl2);
        //***********neu in Version p(opt) *********//
        JLabel frage3 = new JLabel("Welche Stadt?");
        this.add(frage3);
        JComboBox<String> auswahl3 = new JComboBox(new String[] {"München","Hamburg","Berlin","Krefeld","Münster"});
        this.add(auswahl3);
        
        JButton buchen = new JButton("anzeigen");
        this.add(buchen);
        buchen.addActionListener(ae->{
            //List<Tisch> richtigeTische=bs.tischListenAuswahl(TischeAuswahl.wieGutUndWieviel(auswahl1.getSelectedIndex()+1,auswahl2.getSelectedIndex()+1));
            //***********neu in Version p(opt) *********//
//            List<Tisch> richtigeTische=bs.tischListenAuswahl(TischeAuswahl.wieGutUndWievielundWo(
//                    auswahl1.getSelectedIndex()+1 , 
//                    auswahl2.getSelectedIndex()+1 ,
//                    (String)auswahl3.getSelectedItem())
//            );
        List<Tisch> richtigeTische= bs.tischListenAuswahl(TischeAuswahl.fuerVerliebte);
        richtigeTische = bs.tischListenAuswahl(TischeAuswahl.wieGutUndWieviel(2, 2));
        
        int i = Integer.parseInt("1");
        //Superman clark = Supeman.getInstance();
            JDialog tischAnwort = new DialogZurAuswahl(richtigeTische,bs);
            
            tischAnwort.setModal(true);
            tischAnwort.setVisible(true);
        });
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(300,300);
       
    }
}
