/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rest.model;

import com.rest.logic.Tisch;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * //********neu in Version p ***************** //
 * Klasse zur Erstellung zufälliger Tische um die Anwendung zu testen
 * @author Sanne
 */
public class TischMaker {
    private List<Tisch> alleTische = new ArrayList<Tisch>();
    //***********neu in Version p(opt) *********//
    private String[] orte = {"München","Hamburg","Berlin","Krefeld","Münster"};
    public TischMaker(int anzahlTische){
        for(int i=0;i<anzahlTische;i++){
            double bewertung=new Random().nextInt(5);
            int anzahlBewertungen = bewertung==0?0:1;
            //Tisch temp=new Tisch(new Random().nextInt(15),bewertung,anzahlBewertungen);
            
            //***********neu in Version p(opt) *********//
            Tisch temp=new Tisch(new Random().nextInt(15),bewertung,anzahlBewertungen,orte[new Random().nextInt(orte.length)]);
            temp.setTischNr(i+1);
            alleTische.add(temp);
        }
    }
    
    public List<Tisch> getAlleTische(){
        return alleTische;
    }
}
