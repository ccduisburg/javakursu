            /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rest.model;

import com.rest.logic.Tisch;
import java.util.List;

/**
 *
 * @author Sanne
 */
public class TischDaoDBImpl implements TischDao{

    @Override
    public List<Tisch> getAllTisch() {
        //SELECT * FROM rest_tables where status = registiert
        //Erstellen einer Liste
        //neuerTisch=new Tisch(spalte0, spalte4)
        //list.add(neuerTisch);
      
        return null;
    }

    @Override
    public void addTisch(Tisch t) {
       //INSERT 
    }

    @Override
    public void updateTisch(Tisch t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteTisch(Tisch t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
