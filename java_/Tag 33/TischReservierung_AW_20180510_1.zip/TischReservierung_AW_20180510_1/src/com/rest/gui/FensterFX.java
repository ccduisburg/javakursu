/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rest.gui;

import com.rest.logic.BuchungsService;
import com.rest.logic.Tisch;
import com.rest.model.TischAuswahl;
import com.rest.model.TischMaker;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 *
 * @author Sanne
 */
public class FensterFX extends Application implements EventHandler<ActionEvent>{

    private static BuchungsService bs;
    private Label lblPersonenZahl;
    private Button buchen;
    private TextField txtPersonenzahl;
    private Label buchungsAnzeige;
    private Label head;
    private Label ortsAnzeige;
    private ChoiceBox<String> ortsWahl;
    private Label artAnzeige;
    private ChoiceBox<String> artWahl;
    

    @Override
    public void start(Stage stage) throws Exception {
        System.out.println("welcher Buchungsservice " + this.bs);
        head = new Label("Buchungsservice");
        buchen = new Button("Buchen");
        txtPersonenzahl = new TextField();
        lblPersonenZahl = new Label("Wieviele Personen kommen?");
        ortsAnzeige = new Label("Wählen sie den Ort:");
        artAnzeige = new Label("Wählen sie die Art:");
        buchungsAnzeige = new Label();
        ortsWahl = new ChoiceBox<>();
        for (String ort : TischAuswahl.ort) {
            ortsWahl.getItems().add(ort);
            ortsWahl.setId("PullDownMenu");
        }
        ortsWahl.setMaxSize(150, 15);
        artWahl = new ChoiceBox<>();
        for (String art : TischAuswahl.typ) {
            artWahl.getItems().add(art);
            artWahl.setId("PullDownMenu");
        }
        artWahl.setMaxSize(150, 15);
        
        
        stage.setTitle("Unsere Tische");
        stage.setHeight(600);
        stage.setWidth(800);
        
        GridPane root = new GridPane();
        root.setMinHeight(600);        
        root.setAlignment(Pos.TOP_CENTER);
        root.setHgap(10);
        root.setVgap(20);
        
        GridPane.setHalignment(buchen, HPos.RIGHT);
        
                
        Insets grenzen = new Insets(30,22,40,20);
        root.setPadding(grenzen);
        head.getStyleClass().add("head");
        root.add(head,0,0);
        
        root.add(lblPersonenZahl,0,1);
        root.add(txtPersonenzahl, 1,1);
        
        root.add(ortsAnzeige,0,2);
        root.add(ortsWahl, 1,2);
        
        root.add(artAnzeige,0,3);
        root.add(artWahl, 1,3);
        
        
        root.add(buchen, 1, 4, 2, 1); // public void add(Node child, int columnIndex, int rowIndex, int colspan, int rowspan)
        root.add(buchungsAnzeige, 0,5,3,1);
        root.setId("ROOT");
        
        buchen.setOnAction(this); 
        
        Scene szene = new Scene(root,500,500);
        System.out.println(getClass().getResource("tischres.css"));
        szene.getStylesheets().add(getClass().getResource("tischres.css").toExternalForm());
        
        stage.setScene(szene);
        stage.show();
    }
    public void anzeigen(BuchungsService bs){
        FensterFX.bs = bs;
        launch();
    }

    @Override
    public void handle(ActionEvent t) {
        System.out.println("Event+ "+t);
        System.out.println("Buchungsservice"+bs);
        Tisch tisch = bs.buchen(4);
        System.out.println("Tisch "+tisch);
        buchungsAnzeige.setText(tisch.toString());
    }

}
