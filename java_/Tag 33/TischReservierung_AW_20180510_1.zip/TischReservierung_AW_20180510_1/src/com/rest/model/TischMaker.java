package com.rest.model;

import com.rest.logic.Tisch;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author André
 */
public class TischMaker{
    
    
    
    public TischMaker(int tischeAnzahl){
        for (int i = 0; i < tischeAnzahl; i++) {
            TischAuswahl.tische.add(
                    new Tisch(
                        TischAuswahl.stuehle[new Random().nextInt(TischAuswahl.stuehle.length)],          
                        (double) ((double)new Random().nextInt(50)/10),
                        TischAuswahl.typ[new Random().nextInt(TischAuswahl.typ.length)],
                        TischAuswahl.ort[new Random().nextInt(TischAuswahl.ort.length)]
                    )
            );
        }        
    }
    
    // Tisch(int stuehle, double bewertung, String typ)
    
    
    public List<Tisch> getTische() {
        return TischAuswahl.tische;
    }   
}
