package com.rest.model;

import com.rest.logic.Tisch;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 *
 * @author awiechens
 */
public abstract class TischAuswahl {
    
    // 
    public static List<Tisch> tische = new ArrayList<>();
    public static String[] typ= {"Italienisch", "Japanisch", "Spanisch", "Griechisch", "Chinesisch", "Portugiesisch", "Brasilianisch", "Amerikanisch", "Türkisch"};
    public static Integer[] stuehle = {2, 4, 6, 8};
    public static String[] ort= {"Hamburg", "München", "Berlin", "Hannover", "Köln", "Stuttgart", "Mainz", "Bonn", "Schwerin"};
       
    
    
    
    public static List<Tisch> tischAuswahl(List<Tisch> alleTische, Predicate<Tisch> tP) {
        List<Tisch> tischAuswahl = new ArrayList<>();
        alleTische.stream().filter((tisch) -> (tP.test(tisch))).forEachOrdered((tisch) -> {
            tischAuswahl.add(tisch);
        });
        return tischAuswahl;
    }
    
    //AUSWAHL: "Italienisch", "Japanisch", "Spanisch", "Griechisch", "Chinesisch", "Portugiesisch", "Brasilianisch", "Amerikanisch", "Türkisch"
    public static Predicate<Tisch> istItalienisch = t->t.getTyp().equals("Italienisch");
    public static Predicate<Tisch> istJapanisch = t->t.getTyp().equals("Japanisch");
    public static Predicate<Tisch> istSpanisch = t->t.getTyp().equals("Spanisch");
    public static Predicate<Tisch> istGriechisch = t->t.getTyp().equals("Griechisch");
    public static Predicate<Tisch> istChinesisch = t->t.getTyp().equals("Chinesisch");
    public static Predicate<Tisch> istPortugiesisch = t->t.getTyp().equals("Portugiesisch");
    public static Predicate<Tisch> istBrasilianisch = t->t.getTyp().equals("Brasilianisch");
    public static Predicate<Tisch> istAmerikanisch = t->t.getTyp().equals("Amerikanisch");
    public static Predicate<Tisch> istTuerkisch = t->t.getTyp().equals("Türkisch");
    
    //AUSWAHL: 2, 4, 6, 8
    public static Predicate<Tisch> getPlaetze2 = t->t.getPlaetze()==2;
    public static Predicate<Tisch> getPlaetze4 = t->t.getPlaetze()==4;
    public static Predicate<Tisch> getPlaetze6 = t->t.getPlaetze()==6;
    public static Predicate<Tisch> getPlaetze8 = t->t.getPlaetze()==8;
    
    //AUSWAHL: 0-5
    public static Predicate<Tisch> istBesser0 = t->t.getBewertung()>0;
    public static Predicate<Tisch> istBesser1 = t->t.getBewertung()>1;
    public static Predicate<Tisch> istBesser2 = t->t.getBewertung()>2;
    public static Predicate<Tisch> istBesser3 = t->t.getBewertung()>3;
    public static Predicate<Tisch> istBesser4 = t->t.getBewertung()>4;
    public static Predicate<Tisch> istBesster = t->t.getBewertung()==5;
    
    //AUSWAHL: "Hamburg", "München", "Berlin", "Hannover", "Köln", "Stuttgart", "Mainz", "Bonn", "Schwerin"
    public static Predicate<Tisch> inHamburg = t->t.getOrt().equals("Hamburg");
    public static Predicate<Tisch> inMuenchen = t->t.getOrt().equals("München");
    public static Predicate<Tisch> inBerlin = t->t.getOrt().equals("Berlin");
    public static Predicate<Tisch> inHannover = t->t.getOrt().equals("Hannover");
    public static Predicate<Tisch> inKoeln = t->t.getOrt().equals("Köln");
    public static Predicate<Tisch> inStuttgart = t->t.getOrt().equals("Stuttgart");
    public static Predicate<Tisch> inMainz = t->t.getOrt().equals("Mainz");
    public static Predicate<Tisch> inBonn = t->t.getOrt().equals("Bonn");
    public static Predicate<Tisch> inSchwerin = t->t.getOrt().equals("Schwerin");
    
    // Funktionen 
    public static Predicate<Tisch> minSterne_anzahlPersonen(int bewertung, int anzahl){
        return (Tisch t) -> t.getBewertung() >= bewertung && t.getPlaetze() >= anzahl;
    }
    
    public static Predicate<Tisch> minSterne_anzahlPersonen_Ort(int bewertung, int anzahl, String Ort){
        return (Tisch t) -> t.getBewertung() >= bewertung && t.getPlaetze() >= anzahl && t.getOrt().equals(Ort);
    }
    
}
