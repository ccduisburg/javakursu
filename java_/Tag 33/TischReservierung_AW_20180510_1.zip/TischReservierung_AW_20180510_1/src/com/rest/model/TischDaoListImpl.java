package com.rest.model;

import com.rest.logic.Tisch;
import java.util.ArrayList;
import java.util.List;

/**
 *Testdaten für den Buchungsservice. Daten sind nicht persistent
 * 
 * Data Access Object (DAO, englisch für Datenzugriffsobjekt) ist ein Entwurfsmuster, 
 * das den Zugriff auf unterschiedliche Arten von Datenquellen (z. B. Datenbanken, 
 * Dateisystem) so kapselt, dass die angesprochene Datenquelle ausgetauscht werden 
 * kann, ohne dass der aufrufende Code geändert werden muss. Dadurch soll die 
 * eigentliche Programmlogik von technischen Details der Datenspeicherung befreit 
 * werden und flexibler einsetzbar sein. DAO ist also ein Muster für die Gestaltung 
 * von Programmierschnittstellen (APIs). Wenn eine Programmiersprache keine Trennung 
 * von Schnittstellendefinition und -Implementierung ermöglicht, muss ein DAO die 
 * definierte Schnittstelle unmittelbar implementieren. 
 * 
 * @author André
 */
public class TischDaoListImpl implements TischDao{
    private List<Tisch> tische = new ArrayList<>();
    
    public TischDaoListImpl(){
        int nr=1;
        TischMaker dreissig = new TischMaker(30);
        tische = dreissig.getTische();
    }

    @Override
    public List<Tisch> getAllTisch() {
        return tische;
    }

    @Override
    public void addTisch(Tisch t) {
    }

    @Override
    public void updateTisch(Tisch t) {
    }

    @Override
    public void deleteTisch(Tisch t) {
    }
    
    
    
}
