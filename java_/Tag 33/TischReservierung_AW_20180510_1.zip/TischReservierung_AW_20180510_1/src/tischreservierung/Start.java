/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tischreservierung;


import com.rest.gui.FensterFX;

import com.rest.logic.BuchungsService;
import com.rest.logic.Tisch;
import com.rest.model.TischAuswahl;

import com.rest.model.TischDao;
import com.rest.model.TischDaoListImpl;
import java.util.List;

/**
 *
 * @author André
 */
public class Start {
    public static int k;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        k=0;
        TischDao tischDao = new TischDaoListImpl();
        BuchungsService bs = new BuchungsService(tischDao);
        for (Tisch tisch : tischDao.getAllTisch()) {
            System.out.println(tisch);
        }
        System.out.println("+++++ Nur Japaner: ++++++++++++++++");
        List<Tisch> japaner = TischAuswahl.tischAuswahl(tischDao.getAllTisch(), TischAuswahl.istJapanisch);
        for (Tisch tisch : japaner) {
            System.out.println(tisch);
        }
        
        
        
      //Konsole gui = new Konsole(bs);
//      Fenster gui = new Fenster(bs);
//     gui.setVisible(true);
        
       new FensterFX().anzeigen(bs); 
// 
    }
    /**
    * Tischreservierung:
    * 1) TischDaoListImpl: Tischerstellung in TischMaker auslagern
    * 2) Tischkonstruktor anpassen, so dass Tische zu Beginn schon ein Bewertung zwische 0 und 5 haben
    * 3) TischMaker: Tische estellen mit fälliger Personenzahl, Qualität
    * 4) Auswahlklasse: statische Methoden zur Auswahl von "geeigneten" Tischen
    * 5) Buchungsservice anpassen, so dass nach Listen mit vorgegebenen Kriterien gesucht werden kann
    * 6) Mindestens eine GUI Klasse anpssen umd den neuen Buchungsservice zu testen
    * 7) Erweitern der Tisch-Klasse um einen Restaurant-Typ zB Italiener, Chinese, ...
    */
    
}
