package abstrakteklassen;

public interface Knuddeltier {
    void knuddel_mich(); // Methodenrumpf / Sichtbarkeit: public
}
