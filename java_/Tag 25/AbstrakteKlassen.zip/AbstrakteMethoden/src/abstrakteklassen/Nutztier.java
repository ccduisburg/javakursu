package abstrakteklassen;

public interface Nutztier {
    void trage_last(); // Methodenrumpf / Sichtbarkeit: public
}
