package abstrakteklassen;

public abstract class Vierbeiner { // abstrakte Klasse

    public Vierbeiner() { // Konstruktor
    }

    public abstract void rennen(); // abstrakte Methode
    
    // Problem bei neuer abstrakter Methode:
    // Muss in jeder verwendeten Klasse überschrieben werden!!!
}
