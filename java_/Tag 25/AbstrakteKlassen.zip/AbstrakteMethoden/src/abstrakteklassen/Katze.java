package abstrakteklassen;

public class Katze extends Vierbeiner implements Knuddeltier, Jagdtier{ // Mehrfachvererbung!

    public Katze() {
    }

    @Override
    public void rennen() {
        System.out.println("Die Katze rennt!");
    }

    @Override
    public void knuddel_mich() {
        System.out.println("Knuddel, knuddel!");
    }

    @Override
    public void auf_zur_jagd() {
        System.out.println("Auf zur Jagd!");
    }
}
