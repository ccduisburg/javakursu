package abstrakteklassen;

public class Elefant extends Vierbeiner implements Nutztier{

    public Elefant() {
    }

    @Override
    public void rennen() {
        System.out.println("Der Elefant stampft los!");
    }

    @Override
    public void trage_last() {
        System.out.println("Schlepp, schlepp!");
    }
}
