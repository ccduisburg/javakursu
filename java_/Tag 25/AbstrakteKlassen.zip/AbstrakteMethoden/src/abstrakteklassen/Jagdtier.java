package abstrakteklassen;

public interface Jagdtier {
    void auf_zur_jagd(); // Methodenrumpf / Sichtbarkeit: public
}
