package abstrakteklassen;

public class DemoAbstrakteKlassen {

    public static void main(String[] args) {

        // Vierbeiner tier = new Vierbeiner(); // -> Fehler beim Kompilieren
        
        System.out.println("");
        
        Katze katze = new Katze();
        katze.rennen();
        katze.knuddel_mich();
        katze.auf_zur_jagd();

        System.out.println("");
        
        Elefant elefant = new Elefant();
        elefant.rennen();
        elefant.trage_last();
        
        System.out.println("");
    }

}
