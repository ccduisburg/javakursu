            /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rest.model;


import com.rest.logic.Tisch;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sanne
 */
public class TischDaoDBImpl implements TischDao{

    @Override
    public List<Tisch> getAllTisch() {
        List<Tisch> tische= new ArrayList<>();
        try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tischreservierung","root","");
                Statement stm= con.createStatement()){
             String sql = "SELECT * FROM tisch";
             ResultSet rs = stm.executeQuery(sql);
             while(rs.next()){
                 int id=rs.getInt(1);
                 int platz=rs.getInt(2);
                 double bewertung=rs.getDouble(3);
                 int anzahl=rs.getInt(4);
                 
                 Tisch tmp=new Tisch(platz, bewertung, anzahl);
                 tmp.setTischNr(id);
                 tische.add(tmp);
             }
            
        }catch(SQLException e){
            try {
                throw e;
            } catch (SQLException ex) {
                Logger.getLogger(TischDaoDBImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        //SELECT * FROM rest_tables where status = registiert
        //Erstellen einer Liste
        //neuerTisch=new Tisch(spalte0, spalte4)
        //list.add(neuerTisch);
        //tische.forEach(action);
        return tische;
    }

    @Override
    public void addTisch(Tisch t) {
       //INSERT 
    }

    @Override
    public void updateTisch(Tisch t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteTisch(Tisch t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
