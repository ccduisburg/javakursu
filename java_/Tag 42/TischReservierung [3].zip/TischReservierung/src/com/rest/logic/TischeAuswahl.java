/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rest.logic;

import java.util.function.Predicate;

/**
 *//********neu in Version p ***************** //
  * Helferklasse zur Auswahl geeignter Tische
 * @author Sanne
 */
public class TischeAuswahl {
     public static Predicate<Tisch> ist5SterneWert = t->t.getBewertung()==5;
     public static Predicate<Tisch> ist4SterneWert = t->t.getBewertung()>=4;
     public static Predicate<Tisch> ist3SterneWert = new Predicate<Tisch>() {
         @Override
         public boolean test(Tisch t) {
             return t.getBewertung()>=3;
         }
     };
     
    public static Predicate<Tisch> fuerVerliebte = t->t.getPlaetze()==2;
    public static Predicate<Tisch> fuerNormalFamilien = t->t.getPlaetze()>=4&&t.getPlaetze()<=6;
    public static Predicate<Tisch> fuerDieParty = t->t.getPlaetze()>10;
    
    public static Predicate<Tisch> wieGutUndWieviel(int quali, int anzahl){
        return     (Tisch t) -> t.getBewertung()>=quali&&t.getPlaetze()>=anzahl;
    }
     public static Predicate<Tisch> wieGutUndWievielundWo(int quali, int anzahl,String ort){
        return    new Predicate<Tisch>() {
            @Override
            public boolean test(Tisch t) {
                return t.getBewertung()>=quali && t.getPlaetze()>=anzahl && t.getOrt().equals(ort);
            }
        };
    }
         
}
 class Bla{}