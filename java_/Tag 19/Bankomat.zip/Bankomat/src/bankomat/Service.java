package bankomat;

import java.util.List;

public class Service {
    
    private List<Kunde> alleKunden;
    private KundeDAO kd;

    public Service(KundeDAO kd) { // Constructor
        alleKunden = kd.getAlleKunden();
        this.kd = kd;
        // System.out.println("this.kd: "+this.kd);
    }

    public Kunde sucheKunde(String name) {
        // System.out.println("alleKunden: " + alleKunden);
        for (Kunde k : alleKunden) {
            if (k.getName().equals(name)) {
                System.out.println("Kunden gefunden: "+k);
                return k;
            }else{
                // System.out.println("Kunde nicht gefunden!");
            }
        }
        return null;
    }
    /*
    public Tisch buchen(int person, double quali) {
        for (Tisch t : alleTische) {
            if (!t.isBelegt() && t.getPlaetze() >= person && t.getBewertung() >= quali) {
                // ggf. noch nach einem Tisch suchen, der so klein wie möglich ist
                t.setBelegt(true);
                return t;
            }
        }
        return null;
    }
*/
    public void anzeigenAlleKunden() {
        System.out.println("\n--- Übersicht über alle Kunden");
        for (Kunde k : alleKunden) {
            System.out.println(k);
        }
        System.out.println("---\n");
    }
}
