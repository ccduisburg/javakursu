package bankomat;

import java.util.ArrayList;
import java.util.List;

public class KundeDAOListImpl implements KundeDAO{

    private List<Kunde> kunden = new ArrayList<>();

    public KundeDAOListImpl() { // Konstructor

        kunden.add( new Kunde("Oliver" ,  "1234", 1000) );
        kunden.add( new Kunde("Thomas" ,  "2345", 2000) );
        kunden.add( new Kunde("Michael",  "3456", 3000) );
        kunden.add( new Kunde("Klaus"  ,  "4567", 4000) );
        kunden.add( new Kunde("Janine" ,  "5678", 5000) );
        kunden.add( new Kunde("Susanne" , "6789", 5000) );
    }
    
    @Override
    public List<Kunde> getAlleKunden() { return kunden; }
}
