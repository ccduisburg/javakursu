package bankomat;

import java.util.InputMismatchException;
import java.util.Scanner;
// @SuppressWarnings

public class Konsole {

    private Service s; // Attribute
    private Scanner scan;
    private int guthaben;
    private int betrag;
    private String pin;
    Kunde ich = new Kunde();

    public Konsole(Service s) { // Konstructor
        this.s = s;
        scan = new Scanner(System.in);
        navigation();
    }

    // Methoden
    private void navigation() {
        // Kunde ich = new Kunde();

        s.anzeigenAlleKunden();

        System.out.println("***** Willkommen, was können wir für Sie tun? *****\n"
                + "Bitte geben Sie Ihren Namen ein:");
        String name = scan.nextLine(); // Eingabe des Namens
        if (name.equals("")) {
            System.out.println("Kein Name eingegeben!");
        } else {
            System.out.println("Ihr eingegebener Name ist: " + name);

            ich = s.sucheKunde(name);
            if (ich == null) {
                System.out.println("Kunde: " + name + " im Kundenstamm nicht gefunden!");
            } else {

                // System.out.println("ich: " + ich);
                guthaben = ich.getGuthaben();
                pin = ich.getPin();
                // System.out.println("pin: " + pin);
                // System.out.println("guthaben: " + guthaben);

                boolean ok = EingabePin(pin);
                if (ok == true) {

                    betrag = EingabeBetrag(guthaben);
                    System.out.println("Es wurden " + betrag + " Euro ausbezahlt. Schönen Tag noch!");

                } else {
                    System.out.println("PIN-Eingabe war nicht korrekt - Abbruch!");
                }
            }
        }
    }

    private boolean EingabePin(String cPin) {
        this.pin = cPin;
        // System.out.println("pin: " + cPin);
        // System.out.println("this.pin: " + this.pin);

        String eingegebenePin;
        int versuch = 0;
        int versuche = 3;
        boolean EingabePinErfolgreich = false;

        PINEingabeFalschException PinFalsch = new PINEingabeFalschException();
        PINEingabeDreimalFalschException PinDreimalFalsch = new PINEingabeDreimalFalschException();

        do {
            System.out.println("" + (versuch + 1) + ". Versuch - Bitte geben Sie Ihre PIN ein: ");
            eingegebenePin = scan.nextLine();
            // System.out.println("eingegebene Pin: "+eingegebenePin);
            if (eingegebenePin.equals(this.pin)) {
                System.out.println("PIN-Eingabe korrekt");
                EingabePinErfolgreich = true;
                break;
            } else {
                versuch++;

                try {
                    throw PinFalsch;
                } catch (PINEingabeFalschException e) {
                    System.out.println("\nFehler: " + e.getMessage() + "\n");
                } finally {

                }
            }
        } while (versuch < versuche);

        if (versuch == versuche) {
            try {
                throw PinDreimalFalsch;
            } catch (PINEingabeDreimalFalschException e) {
                System.out.println("\nFehler: " + e.getMessage() + "\n");
            } finally {
            }
        }

        return EingabePinErfolgreich;
    }

    private int EingabeBetrag(int limit) {
        int eingegebenerBetrag = 0;

        BetragEingabeFehlerhaftException BetragFalsch = new BetragEingabeFehlerhaftException();

        do {
            try {
                System.out.println("Bitte geben Sie den gewünschten Betrag ein: ");
                eingegebenerBetrag = scan.nextInt();

            } catch (InputMismatchException ime) {
                try {
                    throw new BetragEingabeFehlerhaftException();
                } catch (BetragEingabeFehlerhaftException befe) {
                    System.out.println("ungültige Eingabe: " + scan.next());
                    System.out.println("\nFehler: " + befe.getMessage() + "\n");
                }

                //} catch (BetragEingabeFehlerhaftException befe) {
                //    System.out.println("ungültige Eingabe: " + scan.next());
                //    System.out.println("\nFehler: " + befe.getMessage() + "\n");
            } finally {
            }

            // System.out.println("Limit: " + limit);
            // System.out.println("Betrag: " + eingegebenerBetrag);
        } while (eingegebenerBetrag > limit);

        return eingegebenerBetrag;
    }

}
