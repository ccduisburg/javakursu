package bankomat;

public class Kunde {

    private String name; // = "default";
    private String pin; // = "1234";
    private int guthaben; // = 1000;

    public Kunde(){
    }
    
    public Kunde(String name , String pin, int guthaben) {
        this.name     = name;
        this.pin      = pin;
        this.guthaben = guthaben;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGuthaben() {
        return this.guthaben;
    }

    public void setGuthaben(int guthaben) {
        this.guthaben = guthaben;
    }

    public String getPin() {
        return this.pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }
    
    @Override
    public String toString(){
        return "Name: "+this.name + " / Pin: "+this.pin+" / Guthaben: "+this.guthaben;
    }

}
