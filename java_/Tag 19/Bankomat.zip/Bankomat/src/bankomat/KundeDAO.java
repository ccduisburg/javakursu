package bankomat;

import java.util.List;

public interface KundeDAO {
    
    public List<Kunde> getAlleKunden();
       
}
