package bankomat;

import java.util.InputMismatchException;

public class BetragEingabeFehlerhaftException extends InputMismatchException{
     
    public BetragEingabeFehlerhaftException() {
        super("Bitte geben Sie einen gültigen Betrag ein! ##### BetragEingabeFehlerhaftException().super()");
    }
    
}
