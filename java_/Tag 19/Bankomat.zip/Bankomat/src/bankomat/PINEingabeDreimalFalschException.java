package bankomat;

public class PINEingabeDreimalFalschException extends Exception {

    public PINEingabeDreimalFalschException() {
        super("PIN Eingabe dreimal falsch! ##### PINEingabeDreimalFalschException().super()");
    }
}
