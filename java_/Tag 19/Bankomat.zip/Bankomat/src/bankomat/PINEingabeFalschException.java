package bankomat;

public class PINEingabeFalschException extends Exception{
    
    public PINEingabeFalschException(){
        super("PIN Eingabe falsch! ##### PINEingabeFalschException().super()");
    }
    
}
