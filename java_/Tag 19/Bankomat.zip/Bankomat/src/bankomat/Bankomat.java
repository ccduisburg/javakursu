package bankomat;

import java.util.Scanner;

public class Bankomat {

    public static void main(String[] args) {
        
        KundeDAO kundeDAO = new KundeDAOListImpl();
        
        Service s = new Service( kundeDAO );
        
        Konsole gui = new Konsole( s );
        
        System.out.println("Programmende");
        
        
    }
    
}
